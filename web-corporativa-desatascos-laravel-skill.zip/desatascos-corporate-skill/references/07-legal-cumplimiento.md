# 07 · Cumplimiento legal (España)

> **Aviso importante**: esto es una guía técnica de qué apartados y mecánicas
> debe tener la web para acercarse al cumplimiento normativo español (LSSI-CE,
> RGPD/LOPDGDD, guía de cookies de la AEPD). No sustituye el asesoramiento de
> un abogado: antes de publicar la web con datos reales, un profesional debe
> revisar y adaptar los textos legales al caso concreto de la empresa.

## 1. Marco legal aplicable

- **LSSI-CE** (Ley de Servicios de la Sociedad de la Información) — obliga a
  tener un Aviso Legal con los datos identificativos del titular de la web.
- **RGPD** + **LOPDGDD** — regulan el tratamiento de datos personales
  (formularios de contacto/presupuesto, cookies analíticas, etc.).
- **Guía sobre el uso de las cookies de la AEPD** (versión vigente en 2026) —
  exige que rechazar cookies sea **igual de fácil** que aceptarlas.
- **Ley General de Publicidad** y normativa de consumidores — relevante para
  el tono de los reclamos comerciales (ver apartado 5).

## 2. Las 3 páginas legales obligatorias

### `/aviso-legal` — apartados mínimos

1. Identificación del titular: razón social (`legal_name`), NIF/CIF
   (`cif_nif`), domicilio social (`domicilio_social`), datos de inscripción
   registral si aplica (`registro_mercantil`), email de contacto.
2. Objeto y condiciones de uso del sitio web.
3. Propiedad intelectual e industrial (contenidos, marca, logotipo).
4. Exclusión de responsabilidad y enlaces a terceros.
5. Legislación aplicable y fuero (jurisdicción española).

### `/politica-de-privacidad` — apartados mínimos

1. Responsable del tratamiento (mismos datos que el aviso legal).
2. Finalidad del tratamiento (gestionar solicitudes de presupuesto/contacto,
   enviar comunicaciones si el usuario lo consiente, analítica web).
3. Legitimación (consentimiento del interesado al enviar el formulario,
   interés legítimo para analítica agregada si aplica).
4. Destinatarios de los datos (terceros como el proveedor de hosting/email,
   herramientas de analítica si se usan).
5. Plazo de conservación de los datos.
6. Derechos del interesado: acceso, rectificación, supresión, oposición,
   limitación y portabilidad (derechos ARCO-POL), y cómo ejercerlos
   (`dpo_email` o `email` de contacto).
7. Derecho a reclamar ante la AEPD.

### `/politica-de-cookies` — apartados mínimos

1. Qué es una cookie y para qué se usa en este sitio.
2. **Tabla de cookies** usadas, con columnas: nombre, finalidad, tipo
   (propia/tercero), duración, y si requiere consentimiento. Ejemplo de fila:

   | Cookie | Finalidad | Tipo | Duración | ¿Requiere consentimiento? |
   |---|---|---|---|---|
   | `laravel_session` | Sesión técnica del sitio | Propia | Sesión | No |
   | `_ga`, `_gid` | Analítica (Google Analytics) | Tercero | 13 meses / 24h | Sí |
   | `cookie_consent` | Recordar la preferencia de cookies del usuario | Propia | 12 meses | No (es la propia gestión del consentimiento) |

3. Cómo configurar o retirar el consentimiento en cualquier momento (enlace
   permanente en el footer, ver apartado 3).
4. Cómo eliminar cookies desde el navegador (enlace genérico a la ayuda de los
   navegadores más usados).

Todo el contenido de estas 3 páginas vive en `legal_pages.content` con
placeholders (`{{empresa.legal_name}}`, `{{empresa.cif_nif}}`, etc.) resueltos
al renderizar, de forma que si cambian los datos de la empresa en
`CompanySetting`, el texto legal se actualiza automáticamente sin tener que
reescribir la página.

## 3. Banner de consentimiento de cookies — especificación técnica

Conforme a la guía vigente de la AEPD, el banner debe:

- Mostrarse en **primera capa** con **tres acciones al mismo nivel visual y de
  facilidad de clic**:
  - "Aceptar todas"
  - "Rechazar todas"
  - "Configurar" (abre la segunda capa)
- **Nunca** usar "seguir navegando" como aceptación implícita, ni ocultar el
  botón de rechazo en un enlace secundario o de menor tamaño/contraste que el
  de aceptar (patrón oscuro sancionable).
- **Segunda capa** (panel de configuración): categorías de cookies
  (técnicas — bloqueadas activadas y sin poder desactivar, analíticas,
  marketing/publicidad) cada una con su interruptor, **desmarcadas por
  defecto** salvo las estrictamente técnicas.
- **Ningún script de terceros** (Google Analytics, Meta Pixel, mapas
  embebidos que planten cookies, etc.) se carga hasta que el usuario da
  consentimiento explícito para esa categoría. Los IDs de estas integraciones
  ya están centralizados en `CompanySetting` (ver `05-panel-administracion.md`)
  precisamente para poder controlar su carga condicional desde un único punto.
- Debe existir un enlace **permanente** (normalmente en el footer, tipo
  "Configurar cookies") que reabra el panel de configuración para que el
  usuario pueda **cambiar de opinión tan fácilmente como la dio**.
- Guardar la preferencia en una cookie propia (`cookie_consent`, ver tabla
  arriba) con fecha, para poder acreditar cuándo y qué se consintió.

## 4. Formularios (contacto / presupuesto / trabaja con nosotros)

- Casilla de consentimiento explícita (no premarcada) junto al botón de
  envío: *"He leído y acepto la [Política de Privacidad]"*, enlazando a la
  página real.
- No enviar el formulario sin esa casilla marcada (validación tanto en
  frontend como en el `FormRequest` de Laravel — nunca confiar solo en el
  cliente).
- Protección anti-spam (`spatie/laravel-honeypot` + reCAPTCHA v3 opcional) sin
  añadir fricción visible al usuario legítimo.

## 5. Reclamos publicitarios: qué evitar

La Ley General de Publicidad y la normativa de consumidores prohíben la
publicidad engañosa. En un sector con mucha competencia agresiva ("los más
baratos", "el único servicio real 24h"), conviene:

- Evitar superlativos absolutos no verificables: ~~"los más baratos de
  España"~~, ~~"garantizado al 100% siempre"~~.
- Sustituir por reclamos concretos y verificables, editables desde el admin
  con datos reales de cada empresa: "Presupuesto cerrado antes de empezar",
  "Garantía por escrito de X meses en la reparación", "Servicio 24 horas,
  365 días al año" (solo si es cierto).
- Cualquier cifra mostrada en el home (años de experiencia, avisos atendidos,
  tiempo medio de respuesta — ver Escena 4 del guion de scroll) debe
  corresponder a un dato real cargado en `CompanySetting`, nunca un número de
  relleno olvidado en producción.

## 6. Accesibilidad (buena práctica, no solo estética)

- Respetar siempre `prefers-reduced-motion: reduce` (ver
  `04-guion-animaciones-scroll.md`).
- Texto alternativo (`alt`) descriptivo en todas las imágenes con contenido
  informativo (no en las puramente decorativas, que llevan `alt=""`).
- Contraste de color suficiente entre texto y fondo (especialmente relevante
  porque los colores de marca son configurables desde el admin: conviene
  validar automáticamente el contraste del `color_primary` sobre blanco/negro
  antes de guardar, o al menos advertir al editor si el contraste es bajo).
- Foco visible (`:focus-visible`) en todos los elementos interactivos,
  especialmente en los botones de llamada/WhatsApp.
