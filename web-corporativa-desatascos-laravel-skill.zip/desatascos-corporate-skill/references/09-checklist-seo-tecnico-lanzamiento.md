# 09 · Checklist de lanzamiento SEO técnico

No dar el proyecto por terminado sin repasar esta lista completa.

## Rastreo e indexación
- [ ] `sitemap.xml` accesible y con todas las páginas publicadas (servicios,
      zonas, blog, páginas fijas), sin URLs 404 ni en borrador.
- [ ] `robots.txt` permite el rastreo de todo salvo `/admin` y rutas técnicas.
- [ ] Sitemap enviado a Google Search Console y Bing Webmaster Tools.
- [ ] Cada página tiene una única URL canónica (`<link rel="canonical">`), y
      un solo dominio indexable (`www` **o** sin `www`, nunca ambos).
- [ ] Página 404 personalizada devuelve código HTTP 404 real (no 200).

## Metadatos
- [ ] Cada página tiene `<title>` único (≤60 caracteres) y meta description
      única (≤155 caracteres) — ninguna copiada entre fichas de zona.
- [ ] Open Graph (`og:title`, `og:description`, `og:image`) y Twitter Card en
      todas las páginas relevantes (usan `og_image` de `CompanySetting` como
      fallback si la página no tiene imagen propia).
- [ ] Favicon configurado (desde `CompanySetting`).

## Encabezados y contenido
- [ ] 1 solo `<h1>` por página (verificado en el HTML renderizado, no solo en
      el Blade fuente).
- [ ] Jerarquía H1→H2→H3→H4 sin saltos, en todas las plantillas de
      `03-estructura-encabezados-hn.md`.
- [ ] Ninguna ficha de zona tiene un texto idéntico o casi idéntico a otra
      ficha de zona (contenido único, ver nota anti-duplicados).
- [ ] Todas las imágenes con contenido informativo llevan `alt` descriptivo.

## Datos estructurados
- [ ] `LocalBusiness` en home/contacto validado sin errores (Rich Results
      Test de Google).
- [ ] `Service` en cada ficha de servicio.
- [ ] `FAQPage` en `/preguntas-frecuentes` y en las páginas que muestran FAQ.
- [ ] `BreadcrumbList` en todas las páginas de contenido.
- [ ] `AggregateRating`/`Review` solo si hay valoraciones reales (nunca
      inventadas).

## Rendimiento (Core Web Vitals)
- [ ] Imágenes en WebP/AVIF, tamaño real, `loading="lazy"` salvo la del hero.
- [ ] GSAP/ScrollTrigger no bloquea el renderizado inicial (carga vía Vite,
      no en el `<head>` de forma síncrona).
- [ ] Caché de rutas/vistas/config activa en producción (`php artisan
      optimize`).
- [ ] Test en PageSpeed Insights / Lighthouse en verde (o cerca) tanto en
      móvil como en escritorio.

## SEO local
- [ ] NAP (nombre, dirección, teléfono) idéntico entre la web, el `LocalBusiness`
      schema y la ficha de Google Business Profile.
- [ ] Todas las `ServiceArea` reales de la empresa están dadas de alta y
      publicadas, con descripción propia.
- [ ] Mapa embebido correcto en `/contacto` y en las fichas de zona.
- [ ] Teléfono clicable (`tel:`) y WhatsApp (`https://wa.me/`) en todas las
      páginas, no solo en contacto.

## Legal
- [ ] Las 3 páginas legales existen, están enlazadas desde el footer y tienen
      los datos reales de la empresa (no placeholders sin rellenar).
- [ ] Banner de cookies con "Aceptar todas" / "Rechazar todas" / "Configurar"
      al mismo nivel, sin dark patterns, y enlace permanente para cambiar la
      preferencia.
- [ ] Ningún script de analítica/marketing se carga antes del consentimiento.
- [ ] Casilla de aceptación de la política de privacidad en los formularios,
      validada también en backend.
- [ ] Ninguna afirmación publicitaria absoluta no verificable en el copy
      final (ver `07-legal-cumplimiento.md`).

## Accesibilidad y UX
- [ ] `prefers-reduced-motion: reduce` respetado en todas las animaciones.
- [ ] Interruptor `animations_enabled` probado (con la opción desactivada, la
      web sigue siendo completamente usable).
- [ ] Botón de llamada/WhatsApp visible y accesible en móvil en todo momento
      tras el hero.
- [ ] Contraste de texto suficiente con los colores de marca configurados por
      defecto (y advertencia si un futuro editor pone colores de bajo
      contraste).

## Analítica y medición
- [ ] Google Analytics / GA4 y Search Console verificados con los IDs desde
      `CompanySetting`.
- [ ] Conversión de "llamada" y "envío de formulario" configurada como evento
      medible (aunque sea un evento simple de clic en el `tel:`/formulario).
