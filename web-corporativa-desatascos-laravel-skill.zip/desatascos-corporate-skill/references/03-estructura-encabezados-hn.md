# 03 · Estructura de encabezados (H1–H6)

Regla única e inquebrantable: **1 H1 por página**, y cada nivel siguiente solo
puede aparecer dentro de su padre inmediato (H3 solo dentro de un H2, H4 solo
dentro de un H3...). Nunca se salta de H2 a H4 directamente. Todos los textos de
abajo son **contenido de ejemplo** (datos por defecto de Desatascos EM); en el
admin son campos editables, no literales.

## 1. Home (`/`)

```
H1: Desatascos EM · Desatascos urgentes 24h en Cunit y toda la comarca
  H2: Servicios de desatascos
    H3: Desatasco de tuberías
    H3: Desatasco de WC y sanitarios
    H3: Desatasco de fregaderos y cocinas
    H3: Desatasco de bajantes y arquetas
    H3: Limpieza de fosas sépticas
    H3: Desatascos urgentes 24 horas
  H2: Zonas donde trabajamos
    H3: Cunit
    H3: Calafell
    H3: El Vendrell
    H3: Cubelles
    (resto de zonas destacadas — ver ficha de zona para el listado completo)
  H2: Por qué elegir a Desatascos EM
    H3: Servicio 24 horas, 365 días al año
    H3: Presupuesto claro antes de empezar
    H3: Técnicos propios, sin subcontratas
    H3: Garantía por escrito del trabajo realizado
  H2: Cómo trabajamos
    H3: 1. Nos llamas y nos cuentas el problema
    H3: 2. Diagnóstico en el momento
    H3: 3. Solución el mismo día
    H3: 4. Garantía y seguimiento
  H2: Opiniones de nuestros clientes
  H2: Preguntas frecuentes
    H3: (una H3 por cada pregunta destacada en home, máx. 4-5)
  H2: Últimos consejos del blog
  H2: ¿Tienes una urgencia ahora mismo?
```

## 2. Ficha de servicio (`/servicios/{servicio}`)

```
H1: Desatasco de tuberías en Cunit y alrededores
  H2: En qué consiste el desatasco de tuberías
  H2: Cuándo necesitas este servicio
    H3: Síntoma 1 — el agua baja muy lenta
    H3: Síntoma 2 — malos olores persistentes
    H3: Síntoma 3 — atascos que se repiten
  H2: Cómo trabajamos este servicio
    H3: Diagnóstico con videoinspección
    H3: Técnica de desatasco (varilla / hidrolimpieza / fresado)
    H3: Verificación final y garantía
  H2: Zonas donde ofrecemos este servicio
    H3: (lista de 3-6 ServiceArea relacionadas, cada una enlace a su ficha)
  H2: Preguntas frecuentes sobre este servicio
    H3: (una por FAQ mostrada)
  H2: Solicita presupuesto sin compromiso
```

## 3. Ficha de zona (`/zonas-de-servicio/{zona}`)

```
H1: Desatascos en Cunit
  H2: Empresa de desatascos en Cunit y municipios cercanos
  H2: Servicios disponibles en Cunit
    H3: (uno por cada Service ofrecido en esa zona, enlace a la ficha general)
  H2: Zonas cercanas a Cunit que también cubrimos
    H3: (lista de zonas colindantes, enlace cruzado)
  H2: Opiniones de clientes en Cunit
  H2: ¿Necesitas un desatasco urgente en Cunit?
```

> El contenido bajo cada H2 debe ser específico de esa población (mención a la
> comarca, a poblaciones colindantes reales, a cualquier particularidad —
> urbanizaciones, tipo de vivienda predominante, etc.) para evitar contenido
> duplicado entre fichas de zona. Ver nota en `01-sitemap-arquitectura.md`.

## 4. Artículo de blog (`/blog/{post}`)

```
H1: [Título del artículo — único, con la keyword objetivo]
  H2: [Subtema 1]
    H3: [si el subtema se divide en pasos o puntos]
  H2: [Subtema 2]
  H2: Cuándo llamar a un profesional
  H2: Servicios relacionados
```

## 5. Preguntas frecuentes (`/preguntas-frecuentes`)

```
H1: Preguntas frecuentes sobre nuestros servicios de desatascos
  H2: Precios y presupuestos
    H3: (una por pregunta de esa categoría)
  H2: Urgencias y disponibilidad
    H3: (una por pregunta)
  H2: Sobre el servicio técnico
    H3: (una por pregunta)
```

Agrupar las FAQ por categoría (campo `category` en el modelo `Faq`) evita un
único H2 con 20 H3 seguidas, que es peor tanto para el usuario como para la
forma en que Google interpreta la estructura temática de la página.

## 6. Contacto (`/contacto`) y Presupuesto (`/presupuesto`)

```
H1: Contacta con Desatascos EM
  H2: Nuestros datos de contacto
  H2: Formulario de contacto
  H2: Dónde estamos y zonas que cubrimos
```

## 7. Páginas legales

```
H1: Aviso legal   /   H1: Política de privacidad   /   H1: Política de cookies
  H2: (un H2 por cada apartado obligatorio — ver 07-legal-cumplimiento.md)
```

## 8. Checklist de validación por página (antes de dar por cerrada una plantilla)

- [ ] ¿Hay exactamente un `<h1>` en el HTML renderizado (inspeccionar, no solo
      el Blade — cuidado con componentes que dupliquen el H1 del layout)?
- [ ] ¿Todos los H2 están en el nivel de anidación correcto en el DOM (no
      importa el orden visual/CSS, importa el orden en el HTML)?
- [ ] ¿El H1 contiene la keyword principal de la página de forma natural?
- [ ] ¿Ningún H2/H3 está vacío o es puramente decorativo ("Sección 1")?
