# 08 · Stack técnico: instalación paso a paso

> Ejecutar dentro del proyecto Laravel ya creado. Ajustar versiones si el
> propio Composer/npm resuelve una más reciente compatible en el momento de
> ejecutar esto — usar siempre la última estable de cada paquete.

## 1. Panel de administración

```bash
composer require filament/filament:"^4.0"
php artisan filament:install --panels
php artisan make:filament-user   # crea el primer usuario admin
```

## 2. SEO técnico

```bash
composer require spatie/laravel-sitemap
composer require spatie/laravel-sluggable
composer require ralphjsmit/laravel-seo
# alternativa a laravel-seo: composer require artesaos/seotools
composer require spatie/schema-org
```

- `laravel-sitemap`: generar el `sitemap.xml` con un comando `artisan` propio
  (`app/Console/Commands/GenerateSitemap.php`) programado en el scheduler
  (`php artisan schedule:run` diario) que recorra `Service`, `ServiceArea` y
  `Post` publicados.
- `laravel-sluggable`: trait `HasSlug` en los modelos con slug, configurado
  para generar el slug desde `name`/`title` y garantizar unicidad.

## 3. Media e imágenes

```bash
composer require spatie/laravel-medialibrary
php artisan vendor:publish --provider="Spatie\MediaLibrary\MediaLibraryServiceProvider" --tag="medialibrary-migrations"
php artisan migrate
composer require spatie/image-optimizer
```

Definir conversiones WebP en cada modelo con media (`registerMediaConversions`)
para servir siempre la imagen en el tamaño y formato óptimos.

## 4. Formularios y anti-spam

```bash
composer require spatie/laravel-honeypot
php artisan vendor:publish --provider="Spatie\Honeypot\HoneypotServiceProvider"
```

Añadir `<x-honeypot />` en los formularios de contacto/presupuesto y el
middleware `ProtectAgainstSpam` a esas rutas POST.

## 5. Animaciones de scroll (frontend)

```bash
npm install gsap lenis
```

```js
// resources/js/app.js
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Lenis from "lenis";

gsap.registerPlugin(ScrollTrigger);

const lenis = new Lenis();
lenis.on("scroll", ScrollTrigger.update);
gsap.ticker.add((time) => lenis.raf(time * 1000));
gsap.ticker.lagSmoothing(0);
```

GSAP es 100% gratis desde 2025 (Webflow lo adquirió y liberó todos los plugins,
incluidos `SplitText`, `Draggable`, `MorphSVG`, etc.), así que no hace falta
ninguna licencia "Club GreenSock" ni clave de acceso: basta con el `npm
install`.

## 6. Compilación de assets

Laravel ya trae Vite + Tailwind CSS + Alpine.js por defecto en una instalación
nueva; no añadir nada más salvo que el proyecto real diga lo contrario. Verificar
en `vite.config.js` que `resources/js/app.js` y `resources/css/app.css` están
enlazados, y usar `@vite([...])` en el layout Blade.

## 7. Base de datos y entorno

```bash
php artisan migrate
php artisan db:seed --class=DesatascosEmSeeder
```

(El contenido exacto del seeder está en `assets/seed-data-desatascos-em.md`.)

## 8. Producción / rendimiento

```bash
php artisan optimize
php artisan icons:cache   # si se usa un paquete de iconos con cache, p.ej. blade-icons
npm run build
```

Forzar HTTPS (`APP_URL` con `https://`, middleware `ForceHttps` o
configuración a nivel de servidor/CDN) y decidir un único dominio canónico
(`www` o sin `www`) con redirección 301 del otro.
