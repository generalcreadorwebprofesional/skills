# 02 · Estrategia SEO y palabras clave

## 1. Los tres tipos de intención que hay que cubrir

| Tipo | Ejemplo de búsqueda | Página que debe posicionar | Objetivo |
|---|---|---|---|
| **Transaccional urgente** | "desatascos urgentes Cunit", "fontanero 24 horas cerca de mí" | `/urgencias-24-horas`, home, ficha de zona | Llamada inmediata |
| **Transaccional de servicio** | "desatasco de tuberías", "empresa de desatascos", "desatascos económicos" | `/servicios`, ficha de servicio, ficha de zona | Presupuesto o llamada |
| **Informativa** | "por qué se atasca la tubería", "cómo destapar un desagüe" | `/blog/{post}` | Captar tráfico top-of-funnel, generar autoridad temática (topical authority) y enlazar hacia servicios |

## 2. Clusters de palabras clave (usar como campo `focus_keyword` en admin)

### Cluster A — Marca + genéricas de conversión
- desatascos [nombre de la empresa]
- empresa de desatascos
- desatascos urgentes
- desatascos 24 horas
- desatascos económicos / desatascos baratos
- fontanero desatascos
- desatascos comunidad de vecinos

### Cluster B — Por tipo de servicio (una ficha `Service` por cada uno)
- desatasco de tuberías
- desatasco de wc / desatascar inodoro
- desatasco de fregadero / cocina
- desatasco de bajantes y arquetas
- desatasco de alcantarillado / colector
- limpieza de fosas sépticas
- videoinspección de tuberías / inspección con cámara
- detección de fugas de agua sin obras
- reparación de tuberías sin obras (trenchless)
- mantenimiento preventivo de tuberías en comunidades

### Cluster C — Local (combinar SIEMPRE nombre de población + palabra genérica)
Para cada `ServiceArea` (ver lista completa en `assets/seed-data-desatascos-em.md`):
- desatascos + [población] (ej. *desatascos Cunit*, *desatascos Calafell*)
- desatascos urgentes + [población]
- fontanero + [población]
- desatascos + [comarca] (*desatascos Baix Penedès*, *desatascos Garraf*)
- desatascos + "cerca de mí" (optimizar para intención "near me", clave en móvil)

### Cluster D — Informativas para el blog (top of funnel)
Ideas de artículo → keyword objetivo:

1. "¿Por qué se atasca una tubería? Las 7 causas más comunes" → *por qué se atasca la tubería*
2. "Cómo destapar un desagüe casero paso a paso" → *cómo destapar un desagüe*
3. "¿Cuánto cuesta un desatasco? Guía de precios 2026" → *cuánto cuesta un desatasco*
4. "Bicarbonato y vinagre para desatascar: qué funciona y qué es un mito" → *desatascar con bicarbonato*
5. "Mi WC no traga bien pero no está atascado: posibles causas" → *el wc no traga bien*
6. "Malos olores en el desagüe: por qué pasa y cómo solucionarlo" → *malos olores desagüe*
7. "Videoinspección de tuberías: qué es y cuándo la necesitas" → *videoinspección tuberías*
8. "Mantenimiento de tuberías en comunidades de vecinos: guía para administradores de fincas" → *mantenimiento tuberías comunidad*
9. "Fosas sépticas: cada cuánto hay que vaciarlas" → *limpieza fosa séptica cada cuánto*
10. "Reparar una tubería sin obras: en qué consiste la técnica sin zanja" → *reparación tuberías sin obras*
11. "Qué hacer ante una inundación por atasco mientras llega el técnico" → *qué hacer inundación atasco*
12. "Desatascos en comunidades vs. viviendas particulares: diferencias" → contenido de enlace interno hacia servicios

> Nota: estos títulos son orientativos y deben poder editarse/ampliarse desde el
> propio `PostResource` del admin — no se hardcodean en el frontend.

## 3. Plantillas de metadatos (title / meta description)

Definir estas plantillas en el `SEO Tools`/`seotools` config o en los campos
`meta_title` / `meta_description` de cada modelo, con placeholders resueltos en
el controlador o en un Observer:

| Tipo de página | Plantilla `<title>` (≤60 car.) | Plantilla meta description (≤155 car.) |
|---|---|---|
| Home | `{{empresa}} · Desatascos urgentes 24h en {{zona_principal}} y alrededores` | `¿Tubería o WC atascado? {{empresa}} resuelve tu urgencia en {{zona_principal}} y {{comarca}}. Presupuesto sin compromiso. Llama ahora.` |
| Servicio | `{{servicio}} en {{zona_principal}} · {{empresa}}` | `{{servicio}} rápido y garantizado en {{zona_principal}} y alrededores. Técnicos propios, presupuesto claro. Llama al {{telefono}}.` |
| Zona | `Desatascos en {{zona}} · {{empresa}}` | `Empresa de desatascos en {{zona}}: tuberías, WC, bajantes y urgencias 24h. Respuesta rápida en {{zona}} y pueblos cercanos.` |
| Blog | `{{titulo_post}} · Blog de {{empresa}}` | `{{extracto_post}}` (recortado a 155 car.) |
| Urgencias 24h | `Desatascos urgentes 24 horas en {{zona_principal}} · {{empresa}}` | `Atasco ahora mismo? Te atendemos las 24 horas en {{zona_principal}} y alrededores. Llama directamente, sin esperas.` |

Reglas:
- Meta description única por página, nunca copiada entre fichas de zona (aunque
  compartan estructura, el texto libre de cada `ServiceArea.description` debe
  ser distinto).
- Cada página fija una **canonical** a su propia URL (`<link rel="canonical">`)
  para evitar contenido duplicado por parámetros de tracking (`utm_*`, etc.).
- Un único dominio canónico: decidir `https://www.dominio.com` o
  `https://dominio.com` y redirigir 301 el otro (nunca dejar ambos indexables).

## 4. Datos estructurados (schema.org / JSON-LD)

Usar `spatie/schemaorg` para construir el JSON-LD en cada plantilla:

| Página | Schema principal | Notas |
|---|---|---|
| Home / Contacto | `LocalBusiness` (o el subtipo `Plumber` si el buscador lo soporta bien; si no, `LocalBusiness` + `additionalType`) | Incluir `name`, `telephone`, `address` (PostalAddress), `geo` (GeoCoordinates), `openingHoursSpecification`, `areaServed` (array con todas las `ServiceArea`), `image`, `priceRange` |
| Ficha de servicio | `Service` | `serviceType`, `areaServed`, `provider` (referencia al `LocalBusiness`), `description` |
| Ficha de zona | `LocalBusiness` con `areaServed` acotado a esa población, o `Service` + `areaServed` puntual | Evitar duplicar exactamente el mismo bloque que el home |
| FAQ | `FAQPage` | Un `Question`/`acceptedAnswer` por cada `Faq` mostrada en la página |
| Todas las páginas de contenido | `BreadcrumbList` | Refleja la ruta de navegación (Home > Servicios > Desatasco de tuberías) |
| Opiniones (si hay valoración numérica) | `AggregateRating` dentro del `LocalBusiness` | Solo si los testimonios incluyen `rating` real, nunca inventar cifras |
| Blog post | `Article` o `BlogPosting` | `datePublished`, `author`, `image` |

Todos estos campos deben poder resolverse dinámicamente desde `CompanySetting`
y los modelos correspondientes — nunca escribir valores fijos en el JSON-LD.

## 5. SEO local (más allá de la propia web)

- **Google Business Profile**: el NAP (Nombre, Dirección, Teléfono) que se
  muestre en la ficha de Google debe ser **idéntico, carácter a carácter**, al
  que aparece en `/contacto` y en el `LocalBusiness` schema. Cualquier
  inconsistencia (ej. "Cunit" vs "Cunit (Tarragona)") diluye la señal de
  confianza local.
- Categoría principal en Google Business Profile: "Servicio de desatascos" /
  "Plumber" (adaptar a las categorías reales disponibles).
- Reseñas: enlazar desde `/opiniones` al perfil real de Google para fomentar
  nuevas reseñas (más señal local que los testimonios solo en la propia web).
- Mapa embebido en `/contacto` y en cada ficha de zona mostrando el radio de
  cobertura (o el punto exacto si hay local físico).
- Enlaces de vuelta (backlinks) locales: directorios de empresas locales,
  asociaciones de comercio de Cunit/Baix Penedès, prensa local — fuera del
  alcance de esta skill (es trabajo de off-page), pero la web debe estar
  preparada para recibirlos (URLs limpias y estables, sin romper enlaces al
  cambiar de servidor).

## 6. Rendimiento como factor SEO (Core Web Vitals)

- Imágenes servidas en WebP/AVIF y en el tamaño real necesario (usar
  conversions de `spatie/laravel-medialibrary`).
- Lazy-load de imágenes bajo el pliegue (`loading="lazy"`), pero **no** en la
  imagen del hero (debe cargar con prioridad, `fetchpriority="high"`).
- GSAP/ScrollTrigger cargado de forma diferida (defer) y sin bloquear el
  render inicial; usar `IntersectionObserver`/`ScrollTrigger` en vez de
  listeners de `scroll` sin optimizar.
- CSS crítico del hero inline si el proyecto lo permite; el resto vía Vite
  con `@vite`.
- Cache de vistas/rutas/config en producción (`php artisan optimize`).
