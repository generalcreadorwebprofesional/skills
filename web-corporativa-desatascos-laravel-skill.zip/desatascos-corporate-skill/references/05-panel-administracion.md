# 05 · Panel de administración (Filament)

Principio: **si algo se ve en la web, se edita aquí**. El objetivo final es que
esta misma plataforma sirva para "Desatascos EM" o para cualquier otra empresa
de desatascos con solo tocar el panel — cero despliegues de código para
cambiar marca, textos o colores.

## 1. Ajustes de la empresa — `CompanySetting` (página singleton de Filament)

Página tipo "Settings" (`Filament\Pages\Page` con formulario, no un
`Resource` con listado — solo existe **una** fila).

| Sección del formulario | Campos |
|---|---|
| Identidad | `site_name`, `legal_name` (razón social), `logo` (media), `favicon` (media), `tagline`/eslogan |
| Contacto | `phone_main`, `phone_emergency`, `whatsapp_number`, `email`, `address`, `postal_code`, `lat`, `lng` |
| Horario | Repeater con 7 filas (día de la semana, hora apertura, hora cierre, `is_24h` bool) — alimenta `openingHoursSpecification` del schema.org |
| Redes sociales | `facebook_url`, `instagram_url`, `google_business_url`, etc. |
| Legal | `cif_nif`, `registro_mercantil`, `domicilio_social` (si difiere del de contacto), `dpo_email` (opcional) |
| Marca / tema visual | `color_primary`, `color_secondary`, `color_accent` (Filament `ColorPicker`), `font_heading`, `font_body` (select de Google Fonts soportadas), `animations_enabled` (toggle) |
| SEO por defecto | `default_meta_title`, `default_meta_description`, `og_image` |
| Integraciones | `google_analytics_id`, `google_tag_manager_id`, `meta_pixel_id`, `google_maps_api_key`, `google_search_console_code`, `recaptcha_site_key` / `recaptcha_secret_key` |
| Métricas mostradas en el home | `years_experience`, `jobs_completed`, `avg_response_minutes` (alimentan los contadores de la Escena 4 del guion de scroll) |
| Zona principal | `main_service_area_id` (FK a `ServiceArea`, referencia para "zona principal" en textos tipo "en {{zona_principal}}") |

**Implementación del tema editable:** los colores/tipografías guardados aquí se
inyectan como **CSS custom properties** en el `<head>` del layout principal:

```blade
<style>
  :root {
    --color-primary: {{ $settings->color_primary }};
    --color-secondary: {{ $settings->color_secondary }};
    --color-accent: {{ $settings->color_accent }};
    --font-heading: '{{ $settings->font_heading }}', sans-serif;
    --font-body: '{{ $settings->font_body }}', sans-serif;
  }
</style>
```

Y en Tailwind se referencian con la sintaxis de valor arbitrario:
`class="bg-[var(--color-primary)] text-white"`. Así, cambiar de marca no
requiere tocar ni una clase Blade, solo los campos del admin.

## 2. Servicios — `ServiceResource`

- **Tabla**: nombre, icono (miniatura), zonas relacionadas (badge count),
  destacado (icono check/cruz), orden, publicado.
- **Formulario**: `name`, `slug` (auto desde `name` con `spatie/laravel-sluggable`,
  editable manualmente), `icon` (selector de icono o media), `featured_image`,
  `short_description` (textarea corta, se usa en tarjetas/listados),
  `description` (rich editor, contenido completo de la ficha), `is_emergency`
  (bool — marca si aparece en `/urgencias-24-horas`), `is_featured` (bool —
  aparece en el home), `order` (integer, drag&drop reorder en la tabla),
  relación `belongsToMany(ServiceArea::class)`, sección SEO
  (`meta_title`, `meta_description`, `focus_keyword`), estado
  `published`/`draft`.
- Relación con `Faq` (uno a muchos, FAQ específicas de este servicio).

## 3. Zonas de servicio — `ServiceAreaResource`

- **Tabla**: nombre, comarca/provincia, destacada, sede principal (badge),
  orden, publicado.
- **Formulario**: `name`, `slug`, `comarca`, `province`, `lat`, `lng` (con un
  mapa de selección si el paquete de Filament usado lo soporta, o campos
  numéricos simples), `description` (rich editor — **contenido único por
  población**, ver nota anti-duplicados en `01-sitemap-arquitectura.md`),
  `is_headquarters` (bool, solo una zona debería marcarse como sede),
  `is_featured` (bool), `order`, relación `belongsToMany(Service::class)`,
  sección SEO (`meta_title`, `meta_description`).
- Campo de ayuda en el formulario (texto de admin, no en frontend): recordar al
  editor que rellene una descripción distinta para cada zona, con un mínimo de
  palabras recomendado.

## 4. Testimonios — `TestimonialResource`

- `client_name`, `rating` (1-5, componente de estrellas), `content` (textarea),
  `photo` (opcional), `service_id` (nullable, FK), `service_area_id` (nullable,
  FK), `published_at`, `is_published`.
- Campo de ayuda: recordar que el `rating` debe ser real (ver
  `07-legal-cumplimiento.md`, prohibido inventar valoraciones).

## 5. Blog — `PostCategoryResource` + `PostResource`

- Categoría: `name`, `slug`.
- Post: `category_id`, `title`, `slug`, `excerpt`, `content` (rich editor),
  `featured_image`, `author_name`, `published_at`, `status` (`draft`/
  `published`), sección SEO (`meta_title`, `meta_description`,
  `focus_keyword`), relación `belongsToMany(Service::class)` para el
  enlazado interno automático "servicios relacionados".

## 6. FAQ — `FaqResource`

- `question`, `answer` (rich editor), `category` (select libre o FK a una
  tabla de categorías simple: Precios, Urgencias, Servicio técnico...),
  `service_id` (nullable, FK — si es específica de un servicio),
  `is_featured_on_home` (bool), `order`.

## 7. Leads — `LeadResource`

Un único modelo `Lead` con `type` (`presupuesto` / `contacto` /
`trabaja-con-nosotros`) en vez de tres tablas distintas, para tener un único
bandeja de entrada en el admin.

- **Tabla**: fecha, tipo, nombre, teléfono, zona/servicio de interés, estado
  (badge de color), acciones rápidas (marcar como contactado/cerrado, llamar —
  `tel:` link, WhatsApp — `https://wa.me/` link).
- **Formulario (solo lectura de los datos enviados + edición del estado)**:
  `name`, `phone`, `email`, `service_id` (nullable), `service_area_id`
  (nullable), `message`, `source_page` (URL desde la que se envió),
  `status` (`nuevo` → `contactado` → `presupuestado` → `cerrado` / `descartado`).
- **Notificaciones**: al crearse un `Lead`, disparar una `Notification` de
  Laravel (email al `CompanySetting->email`, y opcionalmente webhook a
  WhatsApp Business API si el proyecto lo integra) — así nadie tiene que estar
  mirando el panel para enterarse de una urgencia entrante.
- Exportación CSV desde la tabla (acción bulk de Filament).
- Protección anti-spam en el formulario público con `spatie/laravel-honeypot`
  (campo trampa invisible) +, opcionalmente, reCAPTCHA v3 con la clave
  guardada en `CompanySetting`.

## 8. Páginas legales — `LegalPageResource`

- Solo 3 registros posibles (`aviso-legal`, `privacidad`, `cookies`), campo
  `type` bloqueado a esos 3 valores, `content` (rich editor con placeholders
  tipo `{{empresa.nombre}}`, `{{empresa.cif}}`, `{{empresa.direccion}}` que se
  resuelven al renderizar — así el texto legal se actualiza solo si cambian
  los datos de la empresa en `CompanySetting`), `updated_at` visible (para
  poder acreditar la fecha de última revisión).
- Ver plantillas de contenido de partida en `07-legal-cumplimiento.md`.

## 9. Redirecciones — `RedirectResource`

- `from_path`, `to_path`, `type` (301/302), `is_active`. Middleware que
  consulta esta tabla antes de lanzar un 404 real.

## 10. Usuarios y roles

- `UserResource` estándar de Filament + (opcional) `filament/spatie-laravel-permission`
  o `filament-shield` para roles (`admin`, `editor`) si más de una persona va a
  usar el panel — el `editor` no debería poder tocar `CompanySetting` ni
  `LegalPageResource`, solo contenido (servicios, zonas, blog, FAQ, leads).

## 11. Dashboard

Widgets de Filament con: nº de leads nuevos (últimos 7 días), gráfico de leads
por semana, últimos 5 leads sin contactar (con acceso directo a llamar/
WhatsApp), servicios y zonas publicados vs. en borrador.

## 12. Extras recomendados (no bloqueantes para el MVP)

- Orden de secciones del home configurable (Repeater con un `select` de
  "tipo de sección" + orden) — solo si hay tiempo, el orden fijo descrito en
  `04-guion-animaciones-scroll.md` es perfectamente válido para el lanzamiento.
- Vista previa ("Preview") del cambio de colores antes de guardar, usando un
  iframe con los CSS variables aplicados vía JS.
