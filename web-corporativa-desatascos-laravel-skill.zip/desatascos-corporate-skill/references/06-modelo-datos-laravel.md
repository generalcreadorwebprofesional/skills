# 06 · Modelo de datos (Eloquent)

## 1. `company_settings` (tabla de una sola fila — patrón singleton)

| Campo | Tipo | Notas |
|---|---|---|
| site_name | string | Nombre comercial mostrado en la web |
| legal_name | string | Razón social |
| tagline | string | Eslogan corto |
| logo, favicon | string (path media) | Via medialibrary |
| phone_main, phone_emergency, whatsapp_number | string | |
| email | string | |
| address, postal_code | string | |
| lat, lng | decimal(10,7) | |
| opening_hours | json | Array de 7 días `{day, opens, closes, is_24h}` |
| facebook_url, instagram_url, google_business_url | string, nullable | |
| cif_nif, registro_mercantil, domicilio_social, dpo_email | string, nullable | Uso en páginas legales |
| color_primary, color_secondary, color_accent | string (hex) | |
| font_heading, font_body | string | |
| animations_enabled | boolean, default true | |
| default_meta_title, default_meta_description | string/text | |
| og_image | string (path media) | |
| google_analytics_id, google_tag_manager_id, meta_pixel_id, google_maps_api_key, google_search_console_code | string, nullable | |
| recaptcha_site_key, recaptcha_secret_key | string, nullable | |
| years_experience, jobs_completed, avg_response_minutes | integer | Alimentan contadores del home |
| main_service_area_id | foreignId → service_areas | |

## 2. `services`

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| name | string |
| slug | string, unique |
| icon | string, nullable |
| featured_image | string, nullable |
| short_description | string |
| description | longText (HTML) |
| is_emergency | boolean, default false |
| is_featured | boolean, default false |
| order | integer, default 0 |
| meta_title, meta_description, focus_keyword | string, nullable |
| published | boolean, default true |
| timestamps | |

Ejemplo de migración (patrón a replicar en el resto de modelos):

```php
Schema::create('services', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('slug')->unique();
    $table->string('icon')->nullable();
    $table->string('featured_image')->nullable();
    $table->string('short_description');
    $table->longText('description');
    $table->boolean('is_emergency')->default(false);
    $table->boolean('is_featured')->default(false);
    $table->unsignedInteger('order')->default(0);
    $table->string('meta_title')->nullable();
    $table->string('meta_description')->nullable();
    $table->string('focus_keyword')->nullable();
    $table->boolean('published')->default(true);
    $table->timestamps();
});
```

## 3. `service_areas`

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| name | string |
| slug | string, unique |
| comarca | string, nullable |
| province | string, nullable |
| lat, lng | decimal(10,7), nullable |
| description | longText (HTML) |
| is_headquarters | boolean, default false |
| is_featured | boolean, default false |
| order | integer, default 0 |
| meta_title, meta_description | string, nullable |
| published | boolean, default true |
| timestamps | |

## 4. `service_service_area` (pivote muchos a muchos)

| Campo | Tipo |
|---|---|
| service_id | foreignId → services |
| service_area_id | foreignId → service_areas |

## 5. `testimonials`

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| client_name | string |
| rating | unsignedTinyInteger (1-5) |
| content | text |
| photo | string, nullable |
| service_id | foreignId nullable → services |
| service_area_id | foreignId nullable → service_areas |
| published_at | timestamp, nullable |
| is_published | boolean, default true |
| timestamps | |

## 6. `post_categories`

| Campo | Tipo |
|---|---|
| id, name, slug | |

## 7. `posts`

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| post_category_id | foreignId nullable |
| title | string |
| slug | string, unique |
| excerpt | string |
| content | longText (HTML) |
| featured_image | string, nullable |
| author_name | string, nullable |
| published_at | timestamp, nullable |
| status | enum('draft','published') |
| meta_title, meta_description, focus_keyword | string, nullable |
| timestamps | |

`post_service` (pivote muchos a muchos, posts ↔ services, para "servicios
relacionados").

## 8. `faqs`

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| question | string |
| answer | longText (HTML) |
| category | string, nullable |
| service_id | foreignId nullable → services |
| is_featured_on_home | boolean, default false |
| order | integer, default 0 |
| timestamps | |

## 9. `leads`

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| type | enum('presupuesto','contacto','trabaja-con-nosotros') |
| name | string |
| phone | string |
| email | string, nullable |
| service_id | foreignId nullable → services |
| service_area_id | foreignId nullable → service_areas |
| message | text, nullable |
| source_page | string, nullable |
| status | enum('nuevo','contactado','presupuestado','cerrado','descartado'), default 'nuevo' |
| timestamps | |

## 10. `legal_pages`

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| type | enum('aviso-legal','privacidad','cookies'), unique |
| content | longText (HTML con placeholders `{{empresa.*}}`) |
| timestamps | |

## 11. `redirects`

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| from_path | string, unique |
| to_path | string |
| type | unsignedSmallInteger (301/302) |
| is_active | boolean, default true |
| timestamps | |

## 12. Relaciones Eloquent (resumen)

```php
// Service
public function serviceAreas(): BelongsToMany { return $this->belongsToMany(ServiceArea::class); }
public function faqs(): HasMany { return $this->hasMany(Faq::class); }
public function testimonials(): HasMany { return $this->hasMany(Testimonial::class); }
public function posts(): BelongsToMany { return $this->belongsToMany(Post::class); }

// ServiceArea
public function services(): BelongsToMany { return $this->belongsToMany(Service::class); }
public function testimonials(): HasMany { return $this->hasMany(Testimonial::class); }

// Route model binding por slug en TODOS los modelos con slug:
public function getRouteKeyName(): string { return 'slug'; }
```

## 13. CompanySetting como singleton

Patrón recomendado: un modelo `CompanySetting extends Model` con un accessor
estático `CompanySetting::current()` que hace `firstOrCreate([], [...valores
por defecto de Desatascos EM...])`, cacheado con `Cache::rememberForever()` e
invalidado en el `saved` event del modelo. Así en cualquier Blade/controlador
basta `CompanySetting::current()->phone_main` sin preocuparse de si existe la
fila.
