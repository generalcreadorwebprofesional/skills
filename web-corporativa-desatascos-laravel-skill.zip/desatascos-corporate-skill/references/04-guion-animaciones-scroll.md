# 04 · Guion de animaciones de scroll y copy de venta

Objetivo del documento: dar una **pauta escena a escena** (storytelling por
scroll) para el home, con el **copy exacto de ejemplo** y la técnica de
animación recomendada, todo orientado a un único resultado: que quien tiene un
atasco **coja el teléfono**. El texto de ejemplo es el contenido por defecto de
"Desatascos EM"; en producción sale de `CompanySetting`, `Service` y
`ServiceArea`, nunca hardcodeado.

## 0. Base técnica común a todas las escenas

- Librerías: `gsap`, `gsap/ScrollTrigger` (npm, 100% gratis incluido uso
  comercial) + `lenis` para scroll suave con inercia.
- Registrar plugin una vez: `gsap.registerPlugin(ScrollTrigger)`.
- **Accesibilidad obligatoria**: envolver todas las animaciones "grandes"
  (pines, parallax, timelines largas) en:
  ```js
  let mm = gsap.matchMedia();
  mm.add("(prefers-reduced-motion: no-preference)", () => {
    // animaciones GSAP aquí
  });
  // Si el usuario tiene reduced-motion activado, el contenido se muestra
  // directamente sin animar (opacity:1, transform:none por defecto en CSS).
  ```
- Además, el admin debe tener un interruptor global `animations_enabled`
  (booleano en `CompanySetting`) que, si está desactivado, hace que el layout
  no cargue el bundle de GSAP en absoluto (mejor rendimiento en según qué
  hosting/cliente).
- En móvil (`matchMedia` `(max-width: 768px)`), sustituir los `pin: true`
  (seccionado fijo) por animaciones más ligeras de aparición simple —el pin de
  secciones completas en pantallas pequeñas suele generar más fricción que
  valor.
- Botón de llamada **sticky**: fuera de la lógica de ScrollTrigger de las
  escenas, un componente aparte (`position: fixed`) que aparece con un simple
  fade tras pasar el hero (`ScrollTrigger` con `start: "bottom top"` sobre la
  sección hero) y se queda visible el resto del scroll, en escritorio como
  barra superior/lateral y en móvil como botón de llamada + WhatsApp flotante
  en la esquina inferior.

---

## Escena 0 — Hero (0–100vh)

**Elemento:** Fondo con ilustración/foto sutil de tubería o técnico trabajando,
H1, subtítulo, botón de llamada grande y pulsante, 2-3 badges de confianza
(años de experiencia, "24h", zona de cobertura).

**Copy de ejemplo:**
> H1: **¿Tubería o WC atascado ahora mismo?**
> Subtítulo: Técnicos en Cunit y alrededores listos para salir. Diagnóstico y
> presupuesto antes de tocar nada.
> Botón principal: **Llamar ahora · 977 000 000**
> Botón secundario: Pedir presupuesto sin urgencia

**Animación:** Entrada en cascada (stagger) del H1 (`SplitText` por líneas),
subtítulo y botones con `gsap.timeline()` al cargar la página (no ligada a
scroll, es la primera impresión). El botón de llamada tiene un pulso suave en
bucle (`scale` 1 → 1.04 → 1, `yoyo: true`, `repeat: -1`, duración larga para
que no resulte molesto).

**Por qué funciona:** Resuelve en 2 segundos la pregunta "¿es esto lo que
busco?" y pone el teléfono como acción nº 1, no como algo escondido al final.

---

## Escena 1 — Agitación del problema (100–180vh)

**Elemento:** 3-4 iconos/frases de dolor apareciendo uno a uno mientras se
hace scroll (mal olor, agua que no baja, riesgo de inundación, olor que
preocupa a la familia/vecinos).

**Copy de ejemplo:**
> H2 (o texto de apoyo, no headline SEO): "Un atasco no avisa ni espera"
> - El agua sube en vez de bajar
> - El mal olor no se va por mucho que limpies
> - Cada hora que pasa, el problema puede ir a más

**Animación:** `ScrollTrigger` con `scrub: true` ligado a un `timeline` que va
revelando cada bloque con `opacity` + `y: 40 → 0`, ligeramente escalonado
(stagger 0.15s). Opcional: parallax muy sutil del icono de fondo (agua) con
`yPercent` distinto al del texto.

**Por qué funciona:** Antes de vender la solución, se nombra el dolor real —
técnica clásica de copywriting de urgencia, aquí traducida a movimiento: cada
frase "pesa" un poco más al aparecer.

---

## Escena 2 — Cómo trabajamos (180–260vh)

**Elemento:** Línea de tiempo horizontal de 4 pasos ("Llamas" → "Diagnóstico" →
"Solución el mismo día" → "Garantía"), con iconos que se dibujan con un trazo
SVG a medida que se hace scroll.

**Copy de ejemplo:**
> H2: Cómo trabajamos
> H3 1: Nos llamas y nos cuentas el problema
> H3 2: Diagnóstico en el momento, presupuesto cerrado
> H3 3: Solución el mismo día en la mayoría de los casos
> H3 4: Garantía por escrito del trabajo

**Animación:** `ScrollTrigger` con `pin: true` sobre la sección mientras se
recorre la timeline horizontal (`xPercent` del contenedor de pasos ligado a
`scrub`), y cada icono usa `strokeDasharray`/`strokeDashoffset` animado
(SplitText/DrawSVG-style, ya incluido gratis en GSAP) para dar sensación de
"dibujado en vivo" al entrar cada paso en el viewport.

**Por qué funciona:** Quita la incertidumbre ("¿qué pasa si llamo?") mostrando
el proceso completo antes de que lo pregunten — reduce la fricción para
descolgar el teléfono.

---

## Escena 3 — Servicios (260–340vh)

**Elemento:** Grid de tarjetas de servicio (una por `Service` destacado).

**Copy de ejemplo (tarjeta tipo):**
> Icono + "Desatasco de tuberías" + "Detectamos y resolvemos el atasco sin
> romper donde no hace falta." + enlace "Ver servicio →"

**Animación:** `ScrollTrigger.batch()` para animar cada tarjeta con
fade + `y: 30 → 0` en cuanto entra en el viewport, con pequeño stagger entre
tarjetas del mismo lote (evita animar las 8-10 tarjetas todas a la vez de golpe
si el usuario hace scroll rápido).

---

## Escena 4 — Cobertura / zonas (340–420vh)

**Elemento:** Mapa estilizado o ilustración de la comarca con "pines" en cada
población, y contadores animados (años de experiencia, avisos atendidos,
tiempo medio de respuesta).

**Copy de ejemplo:**
> H2: Cunit, Calafell, El Vendrell, Cubelles y toda la comarca
> Contador 1: **+[X] años** de experiencia
> Contador 2: **+[X]** avisos atendidos
> Contador 3: **< 60 min** tiempo medio de respuesta en zona

**Animación:** Los pines aparecen con un `stagger` tipo "rebote" (`ease:
back.out`) según el usuario hace scroll; los números usan un *count-up* con
`gsap.to({val:0}, {val:XX, duration:1.5, onUpdate: ...})` disparado una sola
vez al entrar en viewport (`once: true` en el ScrollTrigger).

**Nota legal:** las cifras (años, avisos, tiempo de respuesta) deben ser
**reales y editables desde el admin** (`CompanySetting`), nunca un número de
relleno que se quede así en producción — ver `07-legal-cumplimiento.md`.

---

## Escena 5 — Por qué elegirnos (420–480vh)

**Elemento:** 4 tarjetas que giran/se revelan (flip) mostrando cada motivo de
confianza.

**Copy de ejemplo:** Servicio 24h · Presupuesto claro sin sorpresas · Técnicos
propios (sin subcontratas) · Garantía por escrito.

**Animación:** `rotateY` con `transform-style: preserve-3d` disparado al
entrar en viewport, o alternativa más ligera en móvil: simple fade + scale.

---

## Escena 6 — Opiniones (480–540vh)

**Elemento:** Carrusel/slider de testimonios (`Testimonial`).

**Animación:** Scroll-snap horizontal nativo (`scroll-snap-type`) combinado
con un indicador animado por GSAP; en desktop puede ser drag-to-scroll con el
plugin `Draggable` (también gratis).

---

## Escena 7 — FAQ (540–600vh)

**Elemento:** Acordeón (las FAQ destacadas, no las 30 completas — enlace
"Ver todas las preguntas" hacia `/preguntas-frecuentes`).

**Animación:** Apertura/cierre con `gsap.to(altura, {height: 'auto'})` vía
medición de `scrollHeight` (más fiable que animar `height:auto` directamente),
sin ligar esto a scroll, es interacción de click.

---

## Escena 8 — CTA final (600vh–fin)

**Elemento:** Banner de ancho completo, alto contraste, con el teléfono en
grande y un segundo CTA de WhatsApp.

**Copy de ejemplo:**
> H2: ¿Tienes una urgencia ahora mismo?
> "Cada minuto cuenta cuando hay agua de por medio. Llámanos y en menos de
> [X] minutos tienes un técnico de camino."
> Botón: **Llamar ahora · 977 000 000**   Botón: **Escribir por WhatsApp**

**Animación:** Entrada simple con fade/scale al llegar al final del scroll;
aquí se evita cualquier animación compleja — es el cierre, tiene que ser
inmediato y sin fricción visual.

---

## Patrón resumido para páginas de servicio y de zona

No repiten las 9 escenas del home (serían demasiado largas y diluirían la
keyword principal). Usan una versión corta:

1. Hero específico (H1 + CTA + 1 imagen)
2. Bloque de "cuándo lo necesitas" (agitación breve, sin tanto scroll)
3. Bloque de proceso (versión resumida de la timeline del home)
4. Bloque de zonas o servicios relacionados (grid simple con fade-in)
5. FAQ del servicio/zona
6. CTA final idéntico al del home (mismo componente Blade reutilizado)

## Resumen de técnicas GSAP usadas (referencia rápida)

| Efecto | API de GSAP |
|---|---|
| Aparición en cascada | `gsap.timeline()` + `stagger` |
| Ligado al scroll (scrubbing) | `ScrollTrigger` con `scrub: true` |
| Sección fija mientras ocurre algo | `ScrollTrigger` con `pin: true` |
| Animar muchos elementos según entran en viewport | `ScrollTrigger.batch()` |
| Icono "dibujándose" | `strokeDasharray` / `strokeDashoffset` animado |
| Contador numérico | tween de un objeto plano + `onUpdate` |
| Texto letra a letra / línea a línea | `SplitText` (gratis desde 2025) |
| Scroll suave con inercia | `Lenis` sincronizado con `ScrollTrigger.update` |
| Arrastrar carrusel | `Draggable` (gratis desde 2025) |
