# 01 · Sitemap y arquitectura de páginas

Objetivo: que cualquier búsqueda razonable en Google relacionada con desatascos
en la zona de servicio tenga una página propia, indexable y enlazada desde el
menú, el footer o el mapa de zonas — nunca "huérfana".

## 1. Páginas fijas (estructurales)

| Página | URL | Intención de búsqueda que cubre | Contenido mínimo obligatorio |
|---|---|---|---|
| Home | `/` | Marca + "desatascos [zona principal]", "empresa de desatascos" | H1 único, resumen scrollable de servicios, zonas, por qué elegirnos, testimonios, FAQ, CTA final. Ver guion en `04-guion-animaciones-scroll.md` |
| Sobre nosotros | `/sobre-nosotros` | "quién es [empresa]", confianza/experiencia (E-E-A-T) | Historia, años de experiencia, equipo, seguros/licencias, zona de cobertura |
| Índice de servicios | `/servicios` | "servicios de desatascos", "qué hace una empresa de desatascos" | Listado de todos los `Service`, cada uno enlazando a su ficha |
| Ficha de servicio | `/servicios/{servicio:slug}` | "desatasco de tuberías", "desatasco de wc", etc. | Descripción del servicio, proceso, precio orientativo/"presupuesto sin compromiso", zonas donde se presta, FAQ del servicio, CTA |
| Urgencias 24h | `/urgencias-24-horas` | "desatascos urgentes", "fontanero urgencias 24 horas", "desatascos ahora" | Landing de máxima intención comercial: tiempo de respuesta, teléfono directo, qué hacer mientras llega el técnico |
| Índice de zonas | `/zonas-de-servicio` | "zonas donde trabajamos", "¿trabajáis en mi pueblo?" | Mapa + listado de todas las `ServiceArea`, cada una enlazando a su ficha |
| Ficha de zona | `/zonas-de-servicio/{zona:slug}` | "desatascos en Cunit", "desatascos Calafell", "fontanero El Vendrell"... | Ver plantilla en `03-estructura-encabezados-hn.md`. Contenido único por población (no plantilla vacía con solo el nombre cambiado) |
| Trabajos realizados | `/trabajos-realizados` (opcional pero recomendado) | Prueba social visual, señal de experiencia real para Google | Galería antes/después, breve descripción de cada intervención, zona y servicio relacionados |
| Opiniones | `/opiniones` | "opiniones [empresa]", confianza | Listado completo de `Testimonial` con `AggregateRating` |
| Blog / consejos | `/blog` | Búsquedas informativas de la parte alta del embudo | Índice de `Post` |
| Artículo de blog | `/blog/{post:slug}` | "por qué se atasca la tubería", "cómo destapar un desagüe", etc. | Ver ideas de contenido en `02-seo-estrategia-keywords.md` |
| Preguntas frecuentes | `/preguntas-frecuentes` | "cuánto cuesta un desatasco", dudas pre-compra | Acordeón con `FAQPage` schema |
| Solicitar presupuesto | `/presupuesto` | Conversión (lead principal, no urgente) | Formulario corto (nombre, teléfono, zona, servicio, mensaje) |
| Contacto | `/contacto` | Conversión + NAP | Teléfono, WhatsApp, email, dirección, horario, mapa embebido, formulario |
| Trabaja con nosotros | `/trabaja-con-nosotros` (opcional) | Captación de personal | Formulario simple |
| Aviso legal | `/aviso-legal` | Obligatorio legal | Ver `07-legal-cumplimiento.md` |
| Política de privacidad | `/politica-de-privacidad` | Obligatorio legal | Ver `07-legal-cumplimiento.md` |
| Política de cookies | `/politica-de-cookies` | Obligatorio legal | Ver `07-legal-cumplimiento.md` |
| 404 personalizada | — | UX + no perder al usuario | Buscador + enlaces a servicios/zonas destacadas + teléfono |

## 2. Páginas técnicas (no navegables, pero obligatorias)

- `/sitemap.xml` — generado con `spatie/laravel-sitemap`, incluye todas las
  fichas de servicio, zona y blog con su `lastmod`.
- `/robots.txt` — editable desde `/admin` (bloque de texto libre con valor por
  defecto que permite el rastreo completo salvo `/admin`).
- Redirecciones 301 gestionadas desde una tabla `redirects` (ver
  `06-modelo-datos-laravel.md`) para cuando cambien slugs de servicios o zonas.

## 3. Rutas Laravel (patrón)

```php
// routes/web.php

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/sobre-nosotros', [PageController::class, 'about'])->name('about');

Route::get('/servicios', [ServiceController::class, 'index'])->name('services.index');
Route::get('/servicios/{service:slug}', [ServiceController::class, 'show'])->name('services.show');

Route::get('/zonas-de-servicio', [ServiceAreaController::class, 'index'])->name('areas.index');
Route::get('/zonas-de-servicio/{serviceArea:slug}', [ServiceAreaController::class, 'show'])->name('areas.show');

Route::get('/urgencias-24-horas', [PageController::class, 'emergency'])->name('emergency');
Route::get('/trabajos-realizados', [CaseStudyController::class, 'index'])->name('cases.index');
Route::get('/opiniones', [TestimonialController::class, 'index'])->name('testimonials.index');

Route::get('/blog', [PostController::class, 'index'])->name('blog.index');
Route::get('/blog/{post:slug}', [PostController::class, 'show'])->name('blog.show');

Route::get('/preguntas-frecuentes', [FaqController::class, 'index'])->name('faq.index');

Route::get('/presupuesto', [LeadController::class, 'createQuote'])->name('quote.create');
Route::post('/presupuesto', [LeadController::class, 'storeQuote'])->name('quote.store');
Route::get('/contacto', [LeadController::class, 'createContact'])->name('contact.create');
Route::post('/contacto', [LeadController::class, 'storeContact'])->name('contact.store');

Route::get('/aviso-legal', [LegalController::class, 'show'])->defaults('type', 'aviso-legal')->name('legal.notice');
Route::get('/politica-de-privacidad', [LegalController::class, 'show'])->defaults('type', 'privacidad')->name('legal.privacy');
Route::get('/politica-de-cookies', [LegalController::class, 'show'])->defaults('type', 'cookies')->name('legal.cookies');

// Fallback 404 usa resources/views/errors/404.blade.php
```

Usa **route model binding** por `slug` (implementando `getRouteKeyName()` en cada
modelo) para que las URL sean siempre limpias: `/servicios/desatasco-de-tuberias`,
`/zonas-de-servicio/cunit`, nunca `?id=12`.

## 4. Nota importante anti contenido duplicado/fino (thin content)

Es tentador generar automáticamente una página por cada combinación
"servicio × zona" (p. ej. `/servicios/desatasco-tuberias/cunit`,
`/servicios/desatasco-tuberias/calafell`...) para intentar capturar aún más
long-tail. **No lo hagas de forma automática/spinneada**: Google penaliza el
contenido duplicado o "programáticamente generado sin valor añadido".

Reglas si se implementa esta capa (opcional, fase 2 del proyecto):

1. Solo para las combinaciones de mayor volumen de búsqueda real (los 2-3
   servicios estrella × las 3-4 zonas principales), nunca todas contra todas.
2. Cada página combinada debe tener **como mínimo 250-300 palabras
   verdaderamente específicas** de esa combinación (ejemplos reales de
   intervenciones en esa zona, referencias a calles/urbanizaciones si procede,
   testimonios filtrados por esa zona+servicio).
3. Si no se puede garantizar ese contenido único, es preferible **no crear la
   página** y dejar que la ficha de zona (`/zonas-de-servicio/{zona}`) liste
   todos los servicios disponibles ahí, enlazando cada uno a su ficha general
   de servicio. Menos páginas, pero todas fuertes, es mejor estrategia SEO que
   muchas páginas débiles.

## 5. Enlazado interno mínimo obligatorio

- Home enlaza a: todos los servicios destacados, todas las zonas destacadas,
  urgencias 24h, presupuesto, blog.
- Cada ficha de **servicio** enlaza a: 3-5 zonas donde se presta ese servicio,
  FAQ relacionadas, 1-2 artículos de blog relacionados, CTA de presupuesto.
- Cada ficha de **zona** enlaza a: todos los servicios disponibles ahí,
  testimonios de esa zona (si existen), zonas colindantes.
- Cada **artículo de blog** enlaza a 1-2 servicios relacionados (contenido →
  transacción) y viceversa cuando tenga sentido.
- El footer enlaza siempre a: todas las zonas, todos los servicios, las 3
  páginas legales, contacto y presupuesto (footer = mapa del sitio permanente).
