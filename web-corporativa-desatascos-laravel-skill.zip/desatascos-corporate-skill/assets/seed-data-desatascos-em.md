# Datos de ejemplo para el seeder — "Desatascos EM"

Todos los valores de este archivo son **de ejemplo/ficticios** (teléfono, CIF,
cifras) y deben sustituirse por datos reales antes de publicar la web con una
empresa real. Sirven para que el proyecto arranque con contenido completo y
creíble en lugar de campos vacíos tipo "Lorem ipsum".

## 1. `CompanySetting` (fila única)

```
site_name: Desatascos EM
legal_name: Desatascos EM, S.L.
tagline: Tu urgencia, resuelta hoy
phone_main: 977 000 000
phone_emergency: 600 000 000
whatsapp_number: 34600000000
email: info@desatascosem.example
address: Carrer Major, 1, 43881 Cunit (Tarragona)
postal_code: 43881
lat: 41.1990
lng: 1.6408
opening_hours:
  - {day: Lunes,     opens: "08:00", closes: "20:00", is_24h: false}
  - {day: Martes,    opens: "08:00", closes: "20:00", is_24h: false}
  - {day: Miércoles, opens: "08:00", closes: "20:00", is_24h: false}
  - {day: Jueves,    opens: "08:00", closes: "20:00", is_24h: false}
  - {day: Viernes,   opens: "08:00", closes: "20:00", is_24h: false}
  - {day: Sábado,    opens: "09:00", closes: "14:00", is_24h: false}
  - {day: Domingo (urgencias), opens: "00:00", closes: "23:59", is_24h: true}
cif_nif: B00000000
registro_mercantil: Registro Mercantil de Tarragona, Tomo 0, Folio 0, Hoja T-00000
color_primary: "#0B6E99"
color_secondary: "#0D3B4F"
color_accent: "#F2A93B"
font_heading: Poppins
font_body: Inter
animations_enabled: true
years_experience: 12
jobs_completed: 4800
avg_response_minutes: 45
main_service_area_id: → Cunit
```

## 2. Servicios (`services`) — 10 registros

| name | short_description | is_emergency | is_featured |
|---|---|---|---|
| Desatasco de tuberías | Localizamos y eliminamos el atasco sin romper donde no hace falta. | Sí | Sí |
| Desatasco de WC y sanitarios | Inodoros, bidés y lavabos que no tragan bien, resueltos el mismo día. | Sí | Sí |
| Desatasco de fregaderos y cocinas | Grasas y restos acumulados en la tubería de cocina. | No | Sí |
| Desatasco de bajantes y arquetas | Bajantes comunitarias y arquetas exteriores obstruidas. | Sí | Sí |
| Desatasco de alcantarillado | Intervención en colectores y redes de saneamiento. | Sí | No |
| Limpieza de fosas sépticas | Vaciado y limpieza periódica de fosas y pozos negros. | No | Sí |
| Videoinspección de tuberías | Cámara de inspección para localizar el problema exacto sin obras. | No | Sí |
| Detección de fugas de agua | Localización de fugas sin necesidad de levantar suelos o paredes. | No | No |
| Reparación de tuberías sin obras | Técnica sin zanja para reparar tramos dañados. | No | No |
| Mantenimiento preventivo para comunidades | Revisiones periódicas de la red de saneamiento en comunidades de vecinos. | No | No |

## 3. Zonas de servicio (`service_areas`) — 14 registros

Basadas en la comarca real del Baix Penedès y su entorno (Garraf), con Cunit
como sede:

| name | comarca | is_headquarters | is_featured |
|---|---|---|---|
| Cunit | Baix Penedès | Sí | Sí |
| Calafell | Baix Penedès | No | Sí |
| Segur de Calafell | Baix Penedès | No | Sí |
| El Vendrell | Baix Penedès | No | Sí |
| Coma-ruga | Baix Penedès | No | No |
| Cubelles | Garraf | No | Sí |
| Bellvei | Baix Penedès | No | No |
| Banyeres del Penedès | Baix Penedès | No | No |
| L'Arboç | Baix Penedès | No | No |
| Sant Jaume dels Domenys | Baix Penedès | No | No |
| Santa Oliva | Baix Penedès | No | No |
| Albinyana | Baix Penedès | No | No |
| Vilanova i la Geltrú | Garraf | No | Sí |
| Sitges | Garraf | No | No |

> Cada una debe llevar su propia `description` redactada a mano (no
> plantillada) mencionando su relación real con Cunit (distancia aproximada,
> comarca, alguna referencia local), tal y como exige
> `01-sitemap-arquitectura.md` para evitar contenido duplicado.

## 4. Testimonios (`testimonials`) — 6 registros de ejemplo

1. **Marta S. (Cunit)** — ★5 — "Vinieron en menos de una hora un domingo por
   la noche. Problema resuelto y precio tal cual el presupuesto."
2. **Josep R. (Calafell)** — ★5 — "Muy profesionales con la videoinspección,
   nos enseñaron el vídeo del interior de la tubería antes de actuar."
3. **Comunidad de propietarios, El Vendrell** — ★4 — "Contrato de
   mantenimiento anual para la bajante comunitaria, cero incidencias desde
   entonces."
4. **Anna P. (Cubelles)** — ★5 — "Rapidísimos con la fuga de agua, la
   encontraron sin levantar ni una baldosa."
5. **Ferran M. (Vilanova i la Geltrú)** — ★4 — "Buen trato por teléfono y
   puntuales en la hora acordada."
6. **Núria G. (Segur de Calafell)** — ★5 — "Fosa séptica limpiada sin
   olores ni sorpresas en el precio."

## 5. FAQ (`faqs`) — 8 registros de ejemplo

| category | question |
|---|---|
| Precios | ¿Cuánto cuesta un desatasco? |
| Precios | ¿El presupuesto es gratuito? |
| Urgencias | ¿Atendéis urgencias fuera de horario? |
| Urgencias | ¿Cuánto tardáis en llegar? |
| Servicio técnico | ¿Rompéis paredes o suelos para desatascar? |
| Servicio técnico | ¿Qué es la videoinspección y cuándo la recomendáis? |
| Servicio técnico | ¿Dais garantía del trabajo realizado? |
| Zonas | ¿Trabajáis en mi pueblo aunque no aparezca en la lista? |

## 6. Ideas de blog (`posts`) — 3 de partida (ampliar con las de `02-seo-estrategia-keywords.md`)

1. "¿Por qué se atasca una tubería? Las 7 causas más comunes" (categoría:
   Consejos de mantenimiento)
2. "¿Cuánto cuesta un desatasco? Guía de precios 2026" (categoría: Precios)
3. "Qué hacer ante una inundación por atasco mientras llega el técnico"
   (categoría: Urgencias)
