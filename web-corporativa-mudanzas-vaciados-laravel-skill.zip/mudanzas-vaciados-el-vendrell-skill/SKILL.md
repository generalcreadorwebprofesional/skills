---
name: web-corporativa-mudanzas-vaciados-laravel
description: >
  Genera desde cero (o completa) una web corporativa en Laravel para una
  empresa de mudanzas y vaciados (pisos, casas, trasteros, oficinas,
  herencias), con panel de administración (Filament) totalmente editable y
  "white-label" (marca, textos, colores, servicios, zonas y datos legales
  configurables, con datos de ejemplo de "Mudanzas Penedès" precargados por
  defecto), arquitectura completa de páginas para SEO local (home, servicios,
  zonas de servicio, blog, legal, contacto/presupuesto), jerarquía de
  encabezados H1-H6 estrictamente correcta, capa técnica de SEO avanzada
  orientada a conseguir un flujo constante y sostenido de leads orgánicos
  (no una promesa de resultado, sino la base técnica más completa posible)
  para "mudanzas"/"vaciados" y variantes locales en la zona de El Vendrell y
  alrededores (Baix Penedès), animaciones de scroll modernas, y cumplimiento
  legal específico del sector (Ley de Ordenación de los Transportes
  Terrestres, tarjeta de transporte, seguro de mercancías, contrato-tipo de
  mudanza, gestión de residuos voluminosos en los vaciados). Usa esta skill
  siempre que el usuario pida crear, planificar, ampliar o auditar una web de
  mudanzas, transportes, guardamuebles, vaciado de pisos/casas/trasteros o
  negocios similares en Laravel, o cuando pida SEO local para ese tipo de
  negocio, panel admin editable, o animaciones de scroll para este tipo de
  proyecto.
---

# Web corporativa de Mudanzas y Vaciados en Laravel — Skill completa

## 0. Antes de nada: sobre "SEO garantizada"

Ninguna estrategia de SEO legítima puede **garantizar** clientes de forma
automática — depende del algoritmo de Google, de la competencia local y de
que el contenido se mantenga vivo en el tiempo, no de un ajuste técnico
puntual. Lo que sí puedo darte, y es lo que hace esta skill, es **la base
técnica y de contenido más completa posible** para maximizar las
probabilidades de un flujo constante de leads: arquitectura de páginas
correcta, palabras clave bien elegidas, velocidad, señales de confianza
local y un ritmo de contenido sostenido en el tiempo (no un lanzamiento
único). La constancia después del lanzamiento (reseñas nuevas, contenido
nuevo, mantenimiento técnico) pesa tanto como la propia construcción inicial
— eso está detallado en `02-seo-estrategia-keywords.md`, apartado 6.

## 1. Qué construye esta skill

1. **Panel de administración** (Filament) desde el que se edita el 100% del
   contenido, marca, colores/diseño, servicios, zonas, blog, opiniones, FAQ,
   textos legales y los leads recibidos. Sale de fábrica con los datos de
   ejemplo de **"Mudanzas Penedès"**, pero sirve para cualquier empresa de
   mudanzas/vaciados con solo cambiar esos datos.
2. **Arquitectura de páginas orientada a SEO local y de intención amplia**:
   páginas hiperlocales por población cercana + páginas de alcance amplio
   (mudanzas nacionales, mudanzas a Barcelona/Tarragona, mudanzas
   internacionales) sin caer en contenido duplicado.
3. **Jerarquía de encabezados perfecta** (1 solo `<h1>` por página, H2/H3/H4
   en cascada sin saltos).
4. **Animaciones de scroll modernas** con un hilo narrativo propio del
   sector: el recorrido "de tu casa antigua a la nueva" (ver
   `04-guion-animaciones-scroll.md`).
5. **Cumplimiento legal específico del sector**: LSSI/RGPD/cookies (igual
   que en las skills anteriores) **más** lo propio de mudanzas y vaciados —
   tarjeta de transporte (LOTT), seguro de responsabilidad civil y de
   mercancías, contrato-tipo de mudanza, y gestión de residuos voluminosos
   para el servicio de vaciados.
6. **Zona de servicio real de referencia**: **El Vendrell y alrededores**
   (Cunit, Calafell, Segur de Calafell, Coma-ruga, Cubelles, Bellvei,
   Banyeres del Penedès, L'Arboç, Sant Jaume dels Domenys, Santa Oliva,
   Albinyana, Vilanova i la Geltrú, Sitges) para el negocio local, más
   páginas de alcance amplio para mudanzas de larga distancia — de nuevo,
   editable: cualquier empresa puede sustituir estas poblaciones por las
   suyas.

## 2. Principio rector (idéntico al de las skills anteriores)

Cero contenido "hardcodeado": nombre de la empresa, teléfono, colores,
servicios, poblaciones y precios orientativos viven en base de datos y se
editan desde `/admin`. Las vistas Blade son plantillas, nunca contenido fijo.

## 3. Stack técnico recomendado

| Capa | Elección | Notas |
|---|---|---|
| Backend | Laravel 12/13 (PHP 8.3+) | — |
| Admin | Filament (última v4/v5) | — |
| Frontend | Blade + Tailwind + Alpine.js | — |
| Animaciones scroll | GSAP + ScrollTrigger + Lenis (100% gratis desde 2025) | Nivel "Lite" en SVG, suficiente para este proyecto — no hace falta 3D aquí |
| SEO técnico | spatie/laravel-sitemap, laravel-sluggable, ralphjsmit/laravel-seo, spatie/schema-org | — |
| Media | spatie/laravel-medialibrary + WebP/AVIF | — |
| Formularios | spatie/laravel-honeypot + reCAPTCHA v3 | El formulario de presupuesto es el activo más importante de toda la web — ver `02-...md`, apartado 5 (velocidad de respuesta al lead) |

## 4. Orden de ejecución recomendado

1. Instala el stack base y monta Filament en `/admin` → `08-stack-tecnico-paquetes.md`
2. Migra el modelo de datos → `06-modelo-datos-laravel.md`
3. Construye los recursos del panel admin → `05-panel-administracion.md`
4. Ejecuta el seeder de ejemplo **Mudanzas Penedès** → `assets/seed-data-mudanzas-penedes.md`
5. Construye el sitemap de páginas públicas (hiperlocal + alcance amplio)
   → `01-sitemap-arquitectura.md`
6. Aplica la jerarquía de encabezados obligatoria → `03-estructura-encabezados-hn.md`
7. Implementa la capa SEO (keywords, metadatos, schema.org, reseñas,
   contenido continuo) → `02-seo-estrategia-keywords.md`
8. Maqueta el home con el guion de animaciones de scroll
   → `04-guion-animaciones-scroll.md`
9. Redacta e inserta las páginas legales + el contrato-tipo de mudanza
   → `07-legal-cumplimiento.md`
10. Pasa el checklist final → `09-checklist-seo-tecnico-lanzamiento.md`

## 5. Reglas de oro

- [ ] 1 solo `<h1>` por página, jerarquía H1→H2→H3→H4 sin saltos.
- [ ] Cero marca/teléfono/color "quemado" en Blade.
- [ ] Botón de llamada y WhatsApp sticky tras el hero en móvil.
- [ ] El formulario de presupuesto pide lo mínimo imprescindible (menos
      campos = más conversiones) y dispara una notificación inmediata al
      equipo — ver `02-seo-estrategia-keywords.md`, apartado 5.
- [ ] Cero reclamos publicitarios absolutos no verificables
      ("los más baratos", "presupuesto garantizado sin ver la casa").
- [ ] `robots.txt`, `sitemap.xml` y las páginas legales desde el primer commit.
- [ ] Ninguna página combinada servicio×zona sin contenido realmente único
      (mismo criterio anti contenido duplicado de las skills anteriores).
- [ ] El contrato-tipo de mudanza y la información de la tarjeta de
      transporte están accesibles públicamente (no solo internamente) — es
      señal de confianza y, en algunas comunidades autónomas, obligación
      informativa.

## 6. Mapa de archivos de esta skill

| Archivo | Contenido |
|---|---|
| `references/01-sitemap-arquitectura.md` | Páginas hiperlocales + de alcance amplio, URLs e intención de búsqueda |
| `references/02-seo-estrategia-keywords.md` | Keywords, estacionalidad del sector, reseñas, velocidad de respuesta, contenido continuo |
| `references/03-estructura-encabezados-hn.md` | Esquema H1-H6 por tipo de página |
| `references/04-guion-animaciones-scroll.md` | Guion de scroll storytelling: "de tu casa antigua a la nueva" |
| `references/05-panel-administracion.md` | Especificación de recursos Filament |
| `references/06-modelo-datos-laravel.md` | Tablas y relaciones Eloquent |
| `references/07-legal-cumplimiento.md` | LSSI/RGPD/cookies + LOTT, tarjeta de transporte, seguros, contrato-tipo, residuos de los vaciados |
| `references/08-stack-tecnico-paquetes.md` | Comandos de instalación |
| `references/09-checklist-seo-tecnico-lanzamiento.md` | Checklist final |
| `assets/seed-data-mudanzas-penedes.md` | Datos de ejemplo: empresa, servicios, zonas, testimonios, FAQs, blog |
