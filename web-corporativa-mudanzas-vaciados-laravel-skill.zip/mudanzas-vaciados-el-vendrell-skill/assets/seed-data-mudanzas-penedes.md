# Datos de ejemplo para el seeder — "Mudanzas Penedès"

Todos los valores son **de ejemplo/ficticios** (teléfono, CIF, tarjeta de
transporte, cifras) y deben sustituirse por datos reales antes de publicar la
web con una empresa real.

## 1. `CompanySetting` (fila única)

```
site_name: Mudanzas Penedès
legal_name: Mudanzas Penedès, S.L.
tagline: Tu mudanza, sin que tengas que preocuparte de nada
phone_main: 977 200 200
whatsapp_number: 34600200200
email: info@mudanzaspenedes.example
address: Carrer del Mar, 12, 43700 El Vendrell (Tarragona)
postal_code: 43700
lat: 41.2201
lng: 1.5347
opening_hours:
  - {day: Lunes,     opens: "08:00", closes: "19:00", is_24h: false}
  - {day: Martes,    opens: "08:00", closes: "19:00", is_24h: false}
  - {day: Miércoles, opens: "08:00", closes: "19:00", is_24h: false}
  - {day: Jueves,    opens: "08:00", closes: "19:00", is_24h: false}
  - {day: Viernes,   opens: "08:00", closes: "19:00", is_24h: false}
  - {day: Sábado,    opens: "09:00", closes: "13:00", is_24h: false}
  - {day: Domingo,   opens: null, closes: null, is_24h: false}
cif_nif: B22222222
registro_mercantil: Registro Mercantil de Tarragona, Tomo 0, Folio 0, Hoja T-22222
transport_card_number: MDL-T-000000
moving_companies_registry_number: RCAT-MUD-00000
fleet_size: 6
has_faim_certification: false
color_primary: "#1B4B43"
color_secondary: "#E8C468"
color_accent: "#F4F1EA"
font_heading: Fraunces
font_body: Inter
animations_enabled: true
years_experience: 18
jobs_completed: 3400
avg_response_minutes: 30
main_service_area_id: → El Vendrell
```

> Nota de diseño: paleta verde oscuro + dorado suave (transmite confianza y
> calidez, no urgencia) — de nuevo, distinta a las dos skills anteriores,
> para reforzar que el theming vía `color_primary/secondary/accent` cambia de
> verdad el carácter visual sin tocar código.

## 2. Servicios (`services`) — 10 registros

| name | service_category | requires_sensitive_tone | short_description |
|---|---|---|---|
| Mudanzas de particulares | mudanza | No | Pisos y casas, con o sin embalaje incluido |
| Mudanzas de oficinas | mudanza | No | Traslados de empresas minimizando el tiempo de parada |
| Guardamuebles y trasteros | mudanza | No | Almacenamiento seguro a corto o largo plazo |
| Embalaje profesional | mudanza | No | Material y técnica de embalaje para objetos frágiles |
| Montaje y desmontaje de muebles | mudanza | No | Incluido opcionalmente en cualquier mudanza |
| Transporte de objetos especiales | mudanza | No | Pianos, cajas fuertes, obras de arte |
| Mudanzas nacionales | mudanza | No | A cualquier punto de España |
| Mudanzas internacionales | mudanza | No | Gestión de aduanas y documentación incluida |
| Vaciado integral de pisos y casas | vaciado | No | Antes de vender, alquilar o reformar |
| Vaciado por herencia | vaciado | Sí | Acompañamiento cercano en un momento delicado |

## 3. Zonas de servicio (`service_areas`) — 14 registros

| name | comarca | is_headquarters | is_featured |
|---|---|---|---|
| El Vendrell | Baix Penedès | Sí | Sí |
| Cunit | Baix Penedès | No | Sí |
| Calafell | Baix Penedès | No | Sí |
| Segur de Calafell | Baix Penedès | No | Sí |
| Coma-ruga | Baix Penedès | No | No |
| Cubelles | Garraf | No | Sí |
| Bellvei | Baix Penedès | No | No |
| Banyeres del Penedès | Baix Penedès | No | No |
| L'Arboç | Baix Penedès | No | No |
| Sant Jaume dels Domenys | Baix Penedès | No | No |
| Santa Oliva | Baix Penedès | No | No |
| Albinyana | Baix Penedès | No | No |
| Vilanova i la Geltrú | Garraf | No | Sí |
| Sitges | Garraf | No | No |

## 4. Testimonios (`testimonials`) — 6 registros de ejemplo

1. **Elena R. (El Vendrell)** — ★5 — "Se encargaron de todo, incluido el
   embalaje. Llegó todo perfecto a la casa nueva."
2. **Jordi M. (Cunit)** — ★5 — "Vaciaron el piso de mi madre con mucho
   respeto, en un momento que no era fácil para la familia."
3. **Empresa local, Calafell** — ★4 — "Trasladaron la oficina en un fin de
   semana, el lunes ya estábamos operativos."
4. **Marta S. (Cubelles)** — ★5 — "Presupuesto claro desde el primer día,
   sin ningún cargo sorpresa al final."
5. **Pere V. (Vilanova i la Geltrú)** — ★4 — "Buen trato con el piano,
   se nota que tienen experiencia con objetos delicados."
6. **Anna T. (Segur de Calafell)** — ★5 — "Guardamuebles muy útil mientras
   terminábamos la reforma de la casa nueva."

## 5. FAQ (`faqs`) — 8 registros de ejemplo

| category | question |
|---|---|
| Precios y presupuestos | ¿Cuánto cuesta una mudanza? |
| Precios y presupuestos | ¿El presupuesto es gratuito y sin compromiso? |
| Planificación y plazos | ¿Con cuánta antelación debo reservar? |
| Planificación y plazos | ¿Hacéis mudanzas en fin de semana? |
| Vaciados y gestión de residuos | ¿Qué hacéis con los muebles que no me llevo? |
| Vaciados y gestión de residuos | ¿Puedo quedarme con algunos objetos y que el resto se retire? |
| Sobre el servicio | ¿El seguro cubre roturas durante el transporte? |
| Sobre el servicio | ¿Hacéis mudanzas internacionales? |

## 6. Ideas de blog (`posts`) — 3 de partida (ampliar con las de `02-seo-estrategia-keywords.md`)

1. "¿Cuánto cuesta una mudanza? Guía de precios 2026" (categoría: Precios)
2. "Checklist completo para organizar una mudanza sin estrés" (categoría:
   Planificación)
3. "Vaciar un piso por herencia: guía paso a paso" (categoría: Vaciados)
