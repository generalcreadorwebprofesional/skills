# 07 · Cumplimiento legal

> **Aviso importante**: guía técnica de qué apartados y trámites necesita
> este tipo de negocio, no asesoramiento legal. El transporte de mercancías
> está muy regulado en España (LOTT y su reglamento) — antes de operar con
> vehículos propios, un gestor/asesor de transporte debe confirmar qué
> autorización concreta corresponde a tu flota y tu ámbito de actuación.

## 1. Marco legal de la web (idéntico a las skills anteriores)

- **LSSI-CE**, **RGPD/LOPDGDD**, guía de cookies de la AEPD: mismos
  requisitos que en las skills de Desatascos y Taller de Motos — 3 páginas
  legales, banner de cookies con "Aceptar todas"/"Rechazar todas"/
  "Configurar" al mismo nivel, casilla de privacidad en formularios.

## 2. Autorización de transporte (LOTT) — lo específico de mudanzas

- El transporte de mercancías por cuenta ajena y con remuneración
  (justo lo que hace una empresa de mudanzas) requiere **autorización de
  transporte** conforme a la Ley 16/1987 de Ordenación de los Transportes
  Terrestres (LOTT) y su reglamento (ROTT).
- Tipo de tarjeta según el peso máximo autorizado del vehículo: **MDL**
  (vehículos con MMA no superior a 3,5 t), **MPC**/**MDP** (vehículos de
  más de 3,5 t / más de 5,5 t) — cada una con ámbito nacional o autonómico
  según el caso concreto. Confirmar con el gestor de transporte cuál
  corresponde a la flota real antes de operar.
- Requisitos generales para obtenerla: establecimiento en España,
  **honorabilidad** (sin condenas/sanciones graves), **capacidad
  financiera** y **competencia profesional** (certificado de capacitación
  del transportista).
- En varias comunidades autónomas existe además un **Registro de Empresas
  de Mudanzas** específico (adicional a la tarjeta de transporte general),
  con requisitos propios: licencia municipal de apertura del local/almacén,
  ficha técnica de los vehículos ("capitonés"), plan de prevención de
  riesgos laborales, y **seguro de responsabilidad civil y seguro de
  transporte** en vigor — comprobar si la comunidad autónoma donde opera el
  proyecto real tiene este registro específico.
- **Sello FAIM** (FIDI Accredited International Mover): certificación de
  calidad internacional, no obligatoria pero muy valorada en mudanzas
  internacionales — si la empresa lo tiene, mostrarlo es una señal de
  confianza fuerte (campo `has_faim_certification` en `CompanySetting`).

## 3. El contrato de mudanza

- Regulado por la **Ley 15/2009 del Contrato de Transporte Terrestre de
  Mercancías**, que se aplica también a las mudanzas como modalidad
  específica de transporte.
- Varias administraciones autonómicas exigen o recomiendan un
  **contrato-tipo de mudanzas** aprobado, con un contenido mínimo:
  identificación de las partes, inventario de bienes, valoración del
  contenido a efectos de seguro, fecha y condiciones de recogida/entrega,
  precio y forma de pago, y régimen de responsabilidad ante daños o
  pérdidas.
- Por eso esta skill incluye una página pública `/contrato-tipo-mudanza`
  (ver `01-sitemap-arquitectura.md`) — además de ser buena práctica de
  transparencia, en algunas comunidades autónomas es una obligación
  informativa explícita.
- El contrato real de cada servicio se genera a partir de esta misma
  plantilla (`ContractTemplateResource`, ver `05-panel-administracion.md`),
  con los datos concretos de cada cliente y servicio.

## 4. Seguros obligatorios/recomendados

- **Seguro de responsabilidad civil** de la actividad.
- **Seguro de transporte/mercancías**: cubre los bienes del cliente durante
  el transporte — su existencia y límites de cobertura deben quedar
  reflejados en el propio contrato-tipo (apartado 3), no darse por hecho.
- Si se ofrece guardamuebles, valorar también cobertura específica para el
  periodo de almacenamiento (distinto del riesgo de transporte).

## 5. Gestión de residuos en el servicio de vaciados

- Los muebles, enseres y "voluminosos" retirados en un vaciado tienen la
  consideración de **residuos domésticos** — su gestión profesional y
  habitual (no puntual como particular) encaja como actividad de
  **transportista de residuos**, sujeta a la Ley 7/2022 de residuos y
  suelos contaminados para una economía circular, que exige registro/
  comunicación previa a la administración autonómica competente para operar
  como transportista de residuos con carácter profesional.
- En la práctica, lo más habitual y recomendable es **coordinar con un
  gestor de residuos autorizado o con los puntos limpios/deixalleries
  municipales** para la entrega final de lo retirado, conservando la
  documentación de entrega (para trazabilidad, igual que en la skill del
  taller de motos con los aceites usados) — no acumular ni verter por
  cuenta propia.
- La Ley 7/2022 también prevé el desarrollo de un régimen de
  **responsabilidad ampliada del productor** para muebles y enseres —
  conviene revisar si a fecha de puesta en marcha del proyecto real ya está
  operativo, porque puede añadir obligaciones o, alternativamente, vías de
  gestión ya organizadas por sistemas colectivos del sector.
- Diferenciar en el propio servicio (y en el presupuesto) qué se **dona/
  recicla** (mobiliario en buen estado — buena práctica y también argumento
  de venta: "damos salida responsable a lo que no te llevas") de qué va
  como residuo a tratamiento — esto además es un contenido de blog natural
  (ver `02-seo-estrategia-keywords.md`, idea nº 7).

## 6. Reclamos publicitarios: qué evitar

- Igual que en las skills anteriores: evitar superlativos absolutos no
  verificables (~~"la mudanza más barata de la comarca"~~,
  ~~"presupuesto cerrado sin ver la casa"~~ — en mudanzas, un presupuesto
  serio casi siempre requiere ver o al menos detallar bien el volumen real,
  prometer lo contrario genera reclamaciones).
- No prometer plazos de entrega que dependan de factores fuera de control
  (tráfico, climatología en mudanzas de larga distancia) como si fueran
  garantías absolutas — mejor "plazo estimado de X días" que "entrega
  garantizada el día X".

## 7. Accesibilidad

Igual que en las skills anteriores: `prefers-reduced-motion` respetado,
`alt` descriptivo en imágenes, contraste suficiente, foco visible en
elementos interactivos.
