# 01 · Sitemap y arquitectura de páginas

Particularidad de este sector frente a las skills anteriores: una empresa de
mudanzas no solo compite en local ("mudanzas Cunit"), también en búsquedas de
**largo recorrido** ("mudanzas Barcelona", "mudanzas internacionales"). La
arquitectura separa ambas cosas para no mezclar intenciones distintas en una
misma página.

## 1. Páginas fijas

| Página | URL | Intención de búsqueda | Contenido mínimo obligatorio |
|---|---|---|---|
| Home | `/` | Marca + "mudanzas [zona principal]", "empresa de mudanzas y vaciados" | H1 único, resumen de servicios, zonas, por qué elegirnos, testimonios, FAQ, CTA. Ver `04-guion-animaciones-scroll.md` |
| Sobre nosotros | `/sobre-nosotros` | Confianza/experiencia (E-E-A-T) | Historia, equipo, flota de vehículos, nº de tarjeta de transporte, seguros, sello FAIM si se tiene |
| Índice de servicios | `/servicios` | "servicios de mudanzas y vaciados" | Listado de todos los `Service` |
| Ficha de servicio | `/servicios/{servicio:slug}` | "vaciado de pisos", "guardamuebles", "mudanzas de oficinas"... | Descripción, proceso, precio orientativo, zonas, FAQ, CTA |
| Mudanzas urgentes / última hora | `/mudanzas-urgentes` | Alta intención comercial | Landing específica: disponibilidad, plazos reales, CTA de llamada |
| Índice de zonas (local) | `/zonas-de-servicio` | "¿trabajáis en mi pueblo?" | Mapa + listado de `ServiceArea` locales |
| Ficha de zona local | `/zonas-de-servicio/{zona:slug}` | "mudanzas en El Vendrell", "vaciado de pisos Calafell"... | Contenido único por población |
| **Mudanzas de larga distancia** | `/mudanzas-nacionales` | "mudanzas a Barcelona", "mudanzas a Madrid", "mudanzas nacionales" | Página de alcance amplio, sin listar cada ciudad de España (ver apartado 2) |
| **Mudanzas internacionales** | `/mudanzas-internacionales` | "mudanzas al extranjero", "mudanzas Europa" | Explicación del proceso (aduanas, plazos, documentación), países más solicitados desde la zona |
| Presupuesto de mudanza | `/presupuesto-mudanza` | Conversión — lead principal | Formulario corto (origen, destino, m² o nº habitaciones, fecha aproximada) |
| Presupuesto de vaciado | `/presupuesto-vaciado` | Conversión — lead diferenciado (necesita otros datos) | Formulario corto (tipo de inmueble, motivo del vaciado, urgencia) |
| Contacto | `/contacto` | Conversión + NAP | Teléfono, WhatsApp, email, dirección, horario, mapa |
| Opiniones | `/opiniones` | Confianza | Listado completo de `Testimonial` con `AggregateRating` |
| Blog / consejos | `/blog` | Búsquedas informativas | Índice de `Post` |
| Artículo de blog | `/blog/{post:slug}` | "cómo embalar platos", "cuánto cuesta una mudanza"... | Ver ideas en `02-seo-estrategia-keywords.md` |
| Preguntas frecuentes | `/preguntas-frecuentes` | Dudas pre-compra | Acordeón con `FAQPage` schema |
| Contrato-tipo de mudanza | `/contrato-tipo-mudanza` | Transparencia/obligación informativa en algunas CCAA | Modelo de contrato visible, además del que se firma en cada servicio concreto |
| Aviso legal / Privacidad / Cookies | `/aviso-legal`, `/politica-de-privacidad`, `/politica-de-cookies` | Obligatorio legal | Ver `07-legal-cumplimiento.md` |
| 404 personalizada | — | UX | Buscador + enlaces a servicios/zonas + teléfono |

## 2. Por qué separar "local" de "alcance amplio" (y no crear una página por ciudad de España)

- Las páginas de zona local (`/zonas-de-servicio/{zona}`) llevan contenido
  único por población — funcionan porque son pocas y cada una aporta valor
  real (igual que en las skills anteriores).
- Crear una página por cada ciudad española de destino ("mudanzas a
  Valencia", "mudanzas a Sevilla"...) sin contenido realmente diferenciado
  por ciudad sería exactamente el problema de contenido fino/programático
  que ya se advierte en las otras skills — aquí el riesgo es mayor porque
  "toda España" invita a automatizarlo.
- En su lugar: **una sola página fuerte** `/mudanzas-nacionales` que explica
  el servicio de largo recorrido (cómo se calcula el precio por distancia,
  plazos, seguro de transporte) y menciona de forma natural en el texto las
  rutas más habituales desde la zona (Barcelona, Tarragona, Madrid,
  Valencia) sin crear una URL por cada una. Si con el tiempo una ruta
  concreta genera mucho volumen de búsqueda real y contenido genuino que
  aportar (por ejemplo, "mudanzas El Vendrell - Barcelona" por ser un
  trayecto muy habitual), se puede crear esa página puntual con contenido
  propio — pero como excepción justificada, no como plantilla automática.

## 3. Diferenciar mudanza vs. vaciado en el propio embudo

Aunque ambos servicios comparten empresa y flota, la intención de búsqueda y
el tipo de cliente son distintos (alguien que se muda vs. alguien que vacía
un piso, a menudo por una herencia o antes de vender/alquilar). Por eso:

- Dos formularios de presupuesto distintos (`/presupuesto-mudanza` y
  `/presupuesto-vaciado`), cada uno con los campos relevantes a su caso —
  mezclar ambos en un único formulario largo reduce conversiones.
- El copy de vaciados (especialmente "vaciado por herencia") debe tratarse
  con tacto: sin urgencia agresiva de venta, con un tono más cercano y
  respetuoso — ver notas de tono en `04-guion-animaciones-scroll.md`.

## 4. Rutas Laravel (patrón)

```php
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/servicios', [ServiceController::class, 'index'])->name('services.index');
Route::get('/servicios/{service:slug}', [ServiceController::class, 'show'])->name('services.show');
Route::get('/zonas-de-servicio', [ServiceAreaController::class, 'index'])->name('areas.index');
Route::get('/zonas-de-servicio/{serviceArea:slug}', [ServiceAreaController::class, 'show'])->name('areas.show');
Route::get('/mudanzas-nacionales', [PageController::class, 'nationalMoves'])->name('national');
Route::get('/mudanzas-internacionales', [PageController::class, 'internationalMoves'])->name('international');
Route::get('/mudanzas-urgentes', [PageController::class, 'urgentMoves'])->name('urgent');
Route::get('/presupuesto-mudanza', [LeadController::class, 'createMoveQuote'])->name('quote.move.create');
Route::post('/presupuesto-mudanza', [LeadController::class, 'storeMoveQuote'])->name('quote.move.store');
Route::get('/presupuesto-vaciado', [LeadController::class, 'createClearanceQuote'])->name('quote.clearance.create');
Route::post('/presupuesto-vaciado', [LeadController::class, 'storeClearanceQuote'])->name('quote.clearance.store');
Route::get('/contrato-tipo-mudanza', [LegalController::class, 'contractTemplate'])->name('legal.contract-template');
```

## 5. Enlazado interno mínimo

- Home enlaza a: servicios destacados, zonas destacadas, mudanzas
  nacionales/internacionales, ambos formularios de presupuesto, blog.
- Cada ficha de **servicio** enlaza a: zonas donde se presta, FAQ
  relacionadas, 1-2 artículos de blog, CTA del formulario correspondiente
  (mudanza o vaciado, según el servicio).
- Cada ficha de **zona** enlaza a: todos los servicios disponibles ahí,
  testimonios de esa zona, zonas colindantes.
- Footer: todas las zonas, todos los servicios, mudanzas nacionales/
  internacionales, contrato-tipo, páginas legales, ambos presupuestos.
