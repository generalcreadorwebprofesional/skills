# 08 · Stack técnico: instalación paso a paso

Idéntico al de las skills anteriores (no hay librerías nuevas específicas de
este sector, ya que no se usa nivel 3D aquí).

## 1. Panel de administración

```bash
composer require filament/filament:"^4.0"
php artisan filament:install --panels
php artisan make:filament-user
```

## 2. SEO técnico

```bash
composer require spatie/laravel-sitemap
composer require spatie/laravel-sluggable
composer require ralphjsmit/laravel-seo
composer require spatie/schema-org
```

## 3. Media e imágenes

```bash
composer require spatie/laravel-medialibrary
php artisan vendor:publish --provider="Spatie\MediaLibrary\MediaLibraryServiceProvider" --tag="medialibrary-migrations"
php artisan migrate
composer require spatie/image-optimizer
```

## 4. Formularios y anti-spam

```bash
composer require spatie/laravel-honeypot
php artisan vendor:publish --provider="Spatie\Honeypot\HoneypotServiceProvider"
```

Dado que la velocidad de respuesta al lead es crítica en este sector (ver
`02-seo-estrategia-keywords.md`, apartado 5), añadir una notificación
inmediata:

```bash
php artisan make:notification NewLeadReceived
```

configurada para enviarse por email al equipo comercial en cuanto se guarda
un `MoveQuote` o `ClearanceQuote` nuevo (evento `created` del modelo).

## 5. Animaciones de scroll (frontend)

```bash
npm install gsap lenis
```

```js
// resources/js/app.js
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { MotionPathPlugin } from "gsap/MotionPathPlugin";
import Lenis from "lenis";

gsap.registerPlugin(ScrollTrigger, MotionPathPlugin);

const lenis = new Lenis();
lenis.on("scroll", ScrollTrigger.update);
gsap.ticker.add((time) => lenis.raf(time * 1000));
gsap.ticker.lagSmoothing(0);
```

No hace falta `@google/model-viewer` ni Three.js en este proyecto — el
Nivel Lite en SVG es suficiente y coherente con el tono del sector (ver
`04-guion-animaciones-scroll.md`).

## 6. Compilación de assets

Vite + Tailwind + Alpine.js ya vienen con Laravel — verificar el enlace en
`vite.config.js` y usar `@vite([...])` en el layout.

## 7. Base de datos y entorno

```bash
php artisan migrate
php artisan db:seed --class=MudanzasPenedesSeeder
```

(Contenido exacto del seeder en `assets/seed-data-mudanzas-penedes.md`.)

## 8. Producción / rendimiento

```bash
php artisan optimize
npm run build
```

Forzar HTTPS y un único dominio canónico (`www` o sin `www`).
