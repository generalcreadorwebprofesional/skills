# 02 · Estrategia SEO para captación constante de clientes

Este es el archivo más importante de esta skill porque es la prioridad que
marcaste. Una advertencia honesta antes de entrar en materia: lo de abajo es
la base técnica y de contenido más completa que se puede construir — el
resultado real depende también de la competencia en tu zona y de mantener
esto vivo en el tiempo (apartado 6). No es un interruptor que se enciende
una vez y ya está.

## 1. Los tres tipos de intención de búsqueda

| Tipo | Ejemplo | Página que debe posicionar | Objetivo |
|---|---|---|---|
| **Urgente/inmediata** | "mudanza urgente El Vendrell", "vaciado de piso rápido" | `/mudanzas-urgentes`, home, ficha de zona | Llamada o formulario en minutos |
| **Transaccional de servicio** | "empresa de mudanzas", "vaciado de pisos", "guardamuebles" | `/servicios`, ficha de servicio, ficha de zona | Presupuesto |
| **Informativa** | "cómo embalar platos para una mudanza", "cuánto cuesta vaciar un piso" | `/blog/{post}` | Tráfico top-of-funnel + autoridad temática, capta al usuario semanas antes de que decida contratar |

## 2. Clusters de palabras clave

### Cluster A — Marca + genéricas de conversión
- mudanzas [nombre de la empresa]
- empresa de mudanzas
- mudanzas y vaciados
- mudanzas económicas / mudanzas baratas
- mudanzas urgentes / mudanzas última hora
- **portes** (sinónimo muy buscado en España para trabajos de transporte más
  pequeños que una mudanza completa — no lo obvies, tiene volumen de
  búsqueda propio y distinto de "mudanzas")
- presupuesto mudanza

### Cluster B — Por tipo de servicio (una ficha `Service` por cada uno)
- mudanzas de particulares / mudanzas de pisos y casas
- mudanzas de oficinas y empresas
- guardamuebles / alquiler de trasteros
- vaciado integral de pisos
- vaciado de casas
- vaciado de trasteros y garajes
- vaciado por herencia
- embalaje profesional para mudanzas
- montaje y desmontaje de muebles
- transporte de piano / caja fuerte / objetos especiales
- mudanzas nacionales
- mudanzas internacionales

### Cluster C — Local (nombre de población + palabra genérica)
Para cada `ServiceArea` (lista completa en `assets/seed-data-mudanzas-penedes.md`):
- mudanzas + [población] (*mudanzas El Vendrell*, *mudanzas Cunit*)
- vaciado de pisos + [población]
- portes + [población]
- empresa de mudanzas + [comarca] (*mudanzas Baix Penedès*)
- guardamuebles + [población]

### Cluster D — Informativas para el blog (top of funnel)

1. "¿Cuánto cuesta una mudanza? Guía de precios 2026" → *cuánto cuesta una mudanza*
2. "Cómo embalar platos y objetos frágiles paso a paso" → *cómo embalar platos mudanza*
3. "Checklist completo para organizar una mudanza sin estrés" → *checklist mudanza*
4. "Vaciar un piso por herencia: guía paso a paso y qué hacer con los objetos" → *vaciar piso herencia*
5. "¿Guardamuebles o trastero? Diferencias y cuándo elegir cada uno" → *guardamuebles vs trastero*
6. "Cuánto tiempo hay que reservar para una mudanza de oficina" → *mudanza de oficina planificación*
7. "Qué hacer con los muebles viejos al mudarte: donar, reciclar o tirar" → *qué hacer muebles viejos mudanza*
8. "Mudanza internacional: documentación y plazos que necesitas saber" → *mudanza internacional documentación*
9. "Cómo elegir una empresa de mudanzas de confianza (y qué preguntar antes de contratar)" → *elegir empresa de mudanzas* — este artículo, bien hecho, es también prueba social indirecta
10. "Mejores fechas del mes para hacer una mudanza (y por qué a final de mes cuesta más)" → *cuándo hacer una mudanza* — contenido muy propio del sector, ver apartado 3

## 3. Estacionalidad propia del sector (úsalo a tu favor)

- **Fin/inicio de mes**: en España la mayoría de contratos de alquiler
  cambian a fin de mes, así que la demanda de mudanzas y de camiones se
  concentra ahí — los presupuestos y la disponibilidad se tensan en esos
  días. Contenido y campañas recordando "reserva con antelación si te mudas
  a final de mes" capturan a quien busca con tiempo.
- **Verano y septiembre**: pico estacional clásico (fin de curso escolar,
  cambios de ciclo, buen tiempo para mudanzas). Reforzar contenido/anuncios
  en mayo-junio, antes del pico, para captar a quien busca con antelación.
- **Vaciados por herencia**: sin estacionalidad tan marcada, pero con más
  intención de búsqueda tras periodos vacacionales largos (Navidad, verano),
  cuando las familias se reúnen y deciden gestionar la vivienda de un
  familiar.
- Reflejar esta estacionalidad en el propio calendario de contenido del blog
  (apartado 6) y en el mensaje de la home según la época del año si el
  admin quiere activarlo (banner estacional editable, opcional).

## 4. Plantillas de metadatos y datos estructurados

| Tipo de página | `<title>` (≤60 car.) | Meta description (≤155 car.) |
|---|---|---|
| Home | `{{empresa}} · Mudanzas y vaciados en {{zona_principal}} y alrededores` | `Mudanzas y vaciados en {{zona_principal}} y {{comarca}}. Presupuesto claro, sin sorpresas. Pide presupuesto en menos de 2 minutos.` |
| Servicio | `{{servicio}} en {{zona_principal}} · {{empresa}}` | `{{servicio}} con {{empresa}}: profesionales, seguro incluido y presupuesto cerrado. Llama al {{telefono}}.` |
| Zona | `Mudanzas en {{zona}} · {{empresa}}` | `Empresa de mudanzas y vaciados en {{zona}}: pisos, casas, oficinas y trasteros. Presupuesto rápido y sin compromiso.` |
| Mudanzas nacionales | `Mudanzas nacionales desde {{zona_principal}} · {{empresa}}` | `Mudanzas a toda España desde {{zona_principal}}. Precio por distancia y volumen, seguro de transporte incluido.` |
| Blog | `{{titulo_post}} · Blog de {{empresa}}` | `{{extracto_post}}` |

Datos estructurados (schema.org, vía `spatie/schema-org`):
- `LocalBusiness` (subtipo `MovingCompany` si el buscador lo reconoce, o
  `LocalBusiness` + `additionalType`) en home/contacto, con `areaServed`
  listando todas las `ServiceArea`.
- `Service` en cada ficha de servicio.
- `FAQPage` en `/preguntas-frecuentes`.
- `BreadcrumbList` en todas las páginas de contenido.
- `AggregateRating`/`Review` en `/opiniones`, solo con valoraciones reales.

## 5. La conversión importa tanto como el tráfico: velocidad de respuesta al lead

Este es un punto específico del sector que muchas webs de mudanzas
descuidan: quien pide presupuesto de mudanza normalmente **pide presupuesto
a 3-5 empresas a la vez** y contrata a la que responde antes y mejor, no
necesariamente a la más barata. Por eso:

- El formulario de presupuesto debe pedir **lo mínimo imprescindible**
  (origen, destino, tipo de inmueble/nº de habitaciones, fecha aproximada,
  teléfono) — cada campo de más reduce la tasa de envíos.
- Notificación **inmediata** al equipo comercial en cuanto entra un lead
  (email + idealmente aviso instantáneo tipo push/WhatsApp interno) — la
  velocidad de la primera respuesta es, en la práctica, tan determinante
  para cerrar el cliente como el propio precio.
- Considerar un **chat en directo o WhatsApp Business** visible en todas las
  páginas (no solo en contacto) para capturar al usuario en el momento
  exacto en que está comparando varias opciones, antes de que cierre la
  pestaña y pida presupuesto a la competencia.
- Medir en el panel (`LeadResource`) el tiempo transcurrido entre la entrada
  del lead y el primer contacto — es una métrica operativa tan importante
  como el propio tráfico SEO.

## 6. Por qué "de forma habitual" depende de mantener esto vivo (no es un lanzamiento único)

- **Reseñas de Google**: para negocios locales como este, las reseñas
  recientes influyen tanto en el posicionamiento del "paquete local" de
  Google como en la conversión del usuario que ya llegó a la web. Pedir una
  reseña de forma sistemática tras cada servicio completado (un simple
  enlace directo por WhatsApp/email al finalizar el trabajo) debería ser un
  paso del propio flujo operativo, no algo esporádico.
- **Contenido nuevo con cadencia constante**: publicar 1-2 artículos de blog
  al mes (de la lista del apartado 2 o ampliándola) mantiene la señal de
  actividad del sitio y va capturando progresivamente más búsquedas
  informativas — un blog con 3 artículos publicados el día del lanzamiento y
  nunca más actualizado pierde la mayor parte de este beneficio con el
  tiempo.
- **Citas locales (NAP) consistentes**: el nombre, dirección y teléfono
  deben coincidir exactamente en la web, en Google Business Profile y en
  cualquier directorio local (páginas amarillas, asociaciones de comercio de
  la comarca) donde se dé de alta la empresa — inconsistencias aquí diluyen
  la señal de confianza local ante Google.
- **Mantenimiento técnico**: revisar cada pocos meses enlaces rotos, tiempos
  de carga y que el sitemap sigue reflejando el catálogo real de zonas y
  servicios (`references/09-checklist-seo-tecnico-lanzamiento.md`).

## 7. SEO local más allá de la web

- Google Business Profile con categoría principal "Empresa de mudanzas" (y
  categoría secundaria de vaciado/gestión de residuos si Google la ofrece),
  fotos reales de la flota y del equipo, y el mismo NAP que en la web.
- Directorios y asociaciones locales de la comarca del Baix Penedès/Garraf
  como fuente de enlaces y citas locales adicionales.
- Vincular las reseñas reales de Google desde `/opiniones` en la propia web
  (con enlace al perfil, nunca copiando el texto literal de la reseña sin
  más — mejor resumir o citar solo fragmentos breves si se reproducen).
