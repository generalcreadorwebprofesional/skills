# 06 · Modelo de datos (Eloquent)

Base idéntica a las skills anteriores (`company_settings`, `services`,
`service_areas`, tabla pivote, `testimonials`, `post_categories`, `posts`,
`faqs`, `legal_pages`, `redirects`) — se detallan aquí los campos añadidos o
distintos.

## 1. `company_settings` — campos adicionales

| Campo | Tipo |
|---|---|
| transport_card_number | string, nullable |
| moving_companies_registry_number | string, nullable |
| fleet_size | unsignedInteger, nullable |
| has_faim_certification | boolean, default false |

## 2. `services` — campos adicionales

| Campo | Tipo |
|---|---|
| service_category | enum('mudanza','vaciado','otro'), default 'mudanza' |
| requires_sensitive_tone | boolean, default false |

## 3. `move_quotes` (en vez de un `Lead` genérico, dos tablas específicas)

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| origin_address | string |
| destination_address | string |
| property_type | enum('piso','casa','oficina','trastero') |
| rooms_or_size | string (p. ej. "3 habitaciones" o "80 m²") |
| approximate_date | date, nullable |
| additional_services | json (embalaje, montaje, guardamuebles temporal...) |
| name | string |
| phone | string |
| email | string, nullable |
| status | enum('nuevo','contactado','presupuestado','cerrado','perdido') |
| source_page | string, nullable |
| timestamps | |

## 4. `clearance_quotes`

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| property_address | string |
| property_type | enum('piso','casa','trastero','garaje','oficina') |
| reason | enum('herencia','fin_alquiler','venta','otro') |
| urgency | enum('normal','urgente') |
| name | string |
| phone | string |
| email | string, nullable |
| status | enum('nuevo','contactado','presupuestado','cerrado','perdido') |
| source_page | string, nullable |
| timestamps | |

## 5. `contract_templates`

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| content | longText (HTML con placeholders `{{empresa.*}}`) |
| updated_at | timestamp |

## 6. Resto de tablas

`service_areas`, `service_service_area`, `testimonials`, `post_categories`,
`posts`, `faqs`, `legal_pages`, `redirects`: mismos campos y relaciones que
en las skills anteriores.

## 7. Relaciones Eloquent (resumen)

```php
// Service
public function serviceAreas(): BelongsToMany { return $this->belongsToMany(ServiceArea::class); }
public function faqs(): HasMany { return $this->hasMany(Faq::class); }

// ServiceArea
public function services(): BelongsToMany { return $this->belongsToMany(Service::class); }
public function testimonials(): HasMany { return $this->hasMany(Testimonial::class); }

// Route model binding por slug en todos los modelos con slug
public function getRouteKeyName(): string { return 'slug'; }
```

`CompanySetting::current()` sigue el mismo patrón singleton cacheado de las
skills anteriores.
