# 09 · Checklist de lanzamiento SEO técnico

## Rastreo e indexación
- [ ] `sitemap.xml` con todas las páginas publicadas, sin 404 ni borradores.
- [ ] `robots.txt` permite el rastreo salvo `/admin`.
- [ ] Sitemap enviado a Google Search Console.
- [ ] Canonical único por página, un solo dominio indexable.
- [ ] Página 404 personalizada con código HTTP 404 real.

## Metadatos y contenido
- [ ] `<title>` y meta description únicos por página.
- [ ] 1 solo `<h1>` por página, jerarquía sin saltos.
- [ ] Ninguna ficha de zona con texto duplicado de otra.
- [ ] `/mudanzas-nacionales` no se ha convertido en decenas de páginas por
      ciudad sin contenido único (ver `01-sitemap-arquitectura.md`, apartado 2).
- [ ] Cero afirmaciones publicitarias absolutas no verificables.

## Datos estructurados
- [ ] `LocalBusiness` en home/contacto validado (Rich Results Test).
- [ ] `Service` en cada ficha de servicio.
- [ ] `FAQPage`, `BreadcrumbList`, `AggregateRating` (solo con datos reales).

## Conversión (específico de este sector)
- [ ] Los dos formularios de presupuesto (mudanza/vaciado) están separados y
      piden solo los campos imprescindibles.
- [ ] Notificación inmediata al equipo al recibir un lead nuevo, probada de
      verdad (no solo configurada).
- [ ] Teléfono y WhatsApp clicables en todas las páginas, no solo en contacto.
- [ ] Tiempo medio de primera respuesta medido desde el primer día (panel).

## Legal
- [ ] Las 3 páginas legales con datos reales, enlazadas desde el footer.
- [ ] Banner de cookies conforme (3 botones al mismo nivel).
- [ ] `/contrato-tipo-mudanza` publicada con datos reales de tarjeta de
      transporte y seguros.
- [ ] Nº de tarjeta de transporte y, si aplica, de Registro de Empresas de
      Mudanzas, visibles en "Sobre nosotros".
- [ ] Servicio de vaciados con el flujo de gestión de residuos definido
      (gestor autorizado o punto limpio, con trazabilidad documental).

## Rendimiento (Core Web Vitals)
- [ ] Imágenes en WebP/AVIF, `loading="lazy"` salvo la del hero.
- [ ] GSAP/ScrollTrigger cargados vía Vite, sin bloquear el render inicial.
- [ ] Cache de rutas/vistas/config activa en producción.

## SEO local y mantenimiento continuo (no solo el día del lanzamiento)
- [ ] NAP idéntico entre web, schema y Google Business Profile.
- [ ] Todas las `ServiceArea` reales publicadas con descripción propia.
- [ ] Flujo de solicitud de reseñas tras cada servicio ya activo (no
      pendiente de "hacerlo más adelante").
- [ ] Calendario editorial del blog definido (mínimo 1-2 posts/mes) con
      responsable asignado.

## Accesibilidad
- [ ] `prefers-reduced-motion: reduce` respetado en todas las animaciones.
- [ ] Contraste de texto suficiente con los colores de marca configurados.
