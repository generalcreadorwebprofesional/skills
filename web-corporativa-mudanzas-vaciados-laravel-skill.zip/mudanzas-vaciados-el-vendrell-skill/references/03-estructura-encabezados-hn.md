# 03 · Estructura de encabezados (H1–H6)

Misma regla inquebrantable de siempre: **1 H1 por página**, jerarquía en
cascada sin saltos. Textos de ejemplo = datos por defecto de "Mudanzas
Penedès", editables desde el admin.

## 1. Home (`/`)

```
H1: Mudanzas Penedès · Mudanzas y vaciados en El Vendrell y toda la comarca
  H2: Nuestros servicios
    H3: Mudanzas de particulares
    H3: Mudanzas de oficinas
    H3: Vaciado integral de pisos y casas
    H3: Guardamuebles y trasteros
    H3: Vaciado por herencia
  H2: Zonas donde trabajamos
    H3: El Vendrell
    H3: Cunit
    H3: Calafell
    H3: Cubelles
  H2: Por qué elegir a Mudanzas Penedès
    H3: Presupuesto cerrado antes de empezar
    H3: Seguro de responsabilidad civil y de mercancías
    H3: Equipo propio, sin subcontratas
    H3: Gestión responsable de lo que no te llevas
  H2: Cómo trabajamos
    H3: 1. Nos cuentas qué necesitas mudar o vaciar
    H3: 2. Visita o presupuesto a distancia
    H3: 3. Embalaje y ejecución en la fecha acordada
    H3: 4. Entrega y revisión final contigo
  H2: Opiniones de nuestros clientes
  H2: Preguntas frecuentes
  H2: Últimos consejos del blog
  H2: ¿Necesitas presupuesto para tu mudanza o vaciado?
```

## 2. Ficha de servicio (`/servicios/{servicio}`)

```
H1: Vaciado integral de pisos en El Vendrell
  H2: En qué consiste este servicio
  H2: Cuándo lo necesitas
    H3: Antes de vender o alquilar una vivienda
    H3: Tras una herencia
    H3: Al finalizar un contrato de alquiler
  H2: Cómo trabajamos este servicio
    H3: Valoración e inventario previo
    H3: Retirada y clasificación (donar, reciclar, desechar)
    H3: Limpieza final del espacio
  H2: Zonas donde ofrecemos este servicio
  H2: Preguntas frecuentes sobre este servicio
  H2: Solicita presupuesto sin compromiso
```

## 3. Ficha de zona (`/zonas-de-servicio/{zona}`)

```
H1: Mudanzas en El Vendrell
  H2: Empresa de mudanzas y vaciados en El Vendrell y municipios cercanos
  H2: Servicios disponibles en El Vendrell
  H2: Zonas cercanas a El Vendrell que también cubrimos
  H2: Opiniones de clientes en El Vendrell
  H2: ¿Necesitas presupuesto en El Vendrell?
```

## 4. Mudanzas nacionales (`/mudanzas-nacionales`)

```
H1: Mudanzas nacionales desde El Vendrell
  H2: Cómo funciona una mudanza de larga distancia
  H2: Cómo se calcula el precio
    H3: Por volumen (m³)
    H3: Por distancia
    H3: Servicios adicionales (embalaje, montaje)
  H2: Rutas más habituales desde El Vendrell
  H2: Preguntas frecuentes sobre mudanzas nacionales
  H2: Solicita presupuesto para tu mudanza nacional
```

## 5. Artículo de blog (`/blog/{post}`)

```
H1: [Título del artículo — único, con la keyword objetivo]
  H2: [Subtema 1]
    H3: [si se divide en pasos]
  H2: [Subtema 2]
  H2: Cuándo pedir ayuda profesional
  H2: Servicios relacionados
```

## 6. Preguntas frecuentes (`/preguntas-frecuentes`)

```
H1: Preguntas frecuentes sobre mudanzas y vaciados
  H2: Precios y presupuestos
    H3: (una por pregunta)
  H2: Planificación y plazos
    H3: (una por pregunta)
  H2: Vaciados y gestión de residuos
    H3: (una por pregunta)
```

## 7. Contacto y presupuestos

```
H1: Contacta con Mudanzas Penedès
  H2: Nuestros datos de contacto
  H2: Pide presupuesto de mudanza
  H2: Pide presupuesto de vaciado
  H2: Dónde estamos y zonas que cubrimos
```

## 8. Contrato-tipo de mudanza (`/contrato-tipo-mudanza`)

```
H1: Modelo de contrato de mudanza
  H2: Qué incluye nuestro contrato
  H2: Tus derechos como cliente
  H2: Descarga el modelo de contrato
```

## 9. Páginas legales

```
H1: Aviso legal   /   H1: Política de privacidad   /   H1: Política de cookies
  H2: (un H2 por cada apartado obligatorio — ver 07-legal-cumplimiento.md)
```

## 10. Checklist de validación por página

- [ ] Exactamente un `<h1>` en el HTML renderizado.
- [ ] Ningún H2/H3 vacío o puramente decorativo.
- [ ] El H1 contiene la keyword principal de forma natural.
- [ ] Todos los H2 en el nivel de anidación correcto en el DOM.
