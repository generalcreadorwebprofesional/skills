# 05 · Panel de administración (Filament)

Mismo principio que en las skills anteriores: si algo se ve en la web, se
edita aquí. Se detallan las diferencias propias de mudanzas y vaciados.

## 1. Ajustes de la empresa — `CompanySetting` (página singleton)

Igual estructura base que en las skills anteriores (identidad, contacto,
horario, redes, legal, marca/tema, SEO, integraciones, métricas del home),
con estos campos adicionales:

| Campo nuevo | Uso |
|---|---|
| `transport_card_number` | Nº de tarjeta de transporte (LOTT) — se muestra en "Sobre nosotros" y en el pie de página como señal de confianza |
| `moving_companies_registry_number` | Nº de inscripción en el Registro de Empresas de Mudanzas de la comunidad autónoma (si existe en la región del proyecto) |
| `fleet_size` | Nº de vehículos propios, para mostrar en "Sobre nosotros" |
| `has_faim_certification` | Booleano — si la empresa tiene el sello FAIM (mudanzas internacionales de calidad) |

## 2. Servicios — `ServiceResource`

Misma estructura base (`name`, `slug`, `icon`, `featured_image`,
`short_description`, `description`, `is_featured`, `order`, SEO,
`published`), con:

| Campo nuevo | Uso |
|---|---|
| `service_category` | Enum: `mudanza`, `vaciado`, `otro` — determina a qué formulario de presupuesto enlaza el CTA de la ficha (`/presupuesto-mudanza` o `/presupuesto-vaciado`) |
| `requires_sensitive_tone` | Booleano — marca servicios como "vaciado por herencia" para aplicar el tono sobrio de `04-guion-animaciones-scroll.md` |

## 3. Zonas de servicio — `ServiceAreaResource`

Idéntico a las skills anteriores (`name`, `slug`, `comarca`, `province`,
`lat`, `lng`, `description`, `is_headquarters`, `is_featured`, `order`, SEO).

## 4. Presupuestos — dos recursos, no uno

- `MoveQuoteResource`: origen, destino, tipo de inmueble/nº habitaciones,
  fecha aproximada, servicios adicionales solicitados (embalaje, montaje),
  estado (nuevo/contactado/presupuestado/cerrado/perdido).
- `ClearanceQuoteResource`: tipo de inmueble, motivo (herencia, fin de
  alquiler, otro — campo sensible, tratar con discreción en la interfaz),
  urgencia, estado.
- Ambos comparten el mismo patrón de notificación inmediata al equipo (ver
  `02-seo-estrategia-keywords.md`, apartado 5) — la velocidad de respuesta es
  crítica en este sector.

## 5. Testimonios, Blog, FAQ, Páginas legales, Redirecciones, Usuarios

Estructura idéntica a las skills anteriores, sin cambios funcionales — solo
cambia el copy de ejemplo cargado (ver `assets/seed-data-mudanzas-penedes.md`).

## 6. Nuevo: contrato-tipo de mudanza

- `ContractTemplateResource`: un único documento editable (rich editor) con
  campos de fusión (`{{empresa.nombre}}`, `{{empresa.cif_nif}}`,
  `{{empresa.transport_card_number}}`) que alimenta tanto la página pública
  `/contrato-tipo-mudanza` como el documento real que se genera para cada
  servicio contratado (ver `06-modelo-datos-laravel.md`).

## 7. Dashboard

- Leads nuevos (mudanza y vaciado, en widgets separados), tiempo medio de
  primera respuesta (métrica clave de este sector, ver `02-...md` apartado
  5), servicios más solicitados por mes (para detectar estacionalidad real,
  ver `02-...md` apartado 3), últimas reseñas recibidas.
