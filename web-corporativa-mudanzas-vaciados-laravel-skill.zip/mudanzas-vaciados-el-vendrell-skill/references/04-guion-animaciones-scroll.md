# 04 · Guion de animaciones de scroll

Nivel "Lite" (SVG + GSAP ScrollTrigger, sin 3D — no hace falta aquí, este
sector vende confianza y tranquilidad, no espectáculo). Base técnica idéntica
a las skills anteriores: `gsap`, `ScrollTrigger`, `Lenis`, todo con
`prefers-reduced-motion` respetado y un interruptor `animations_enabled` en
`CompanySetting`.

## Hilo narrativo: "de tu casa antigua a la nueva"

En vez de agitar un problema urgente (como en las otras dos skills), aquí el
tono es de **tranquilidad y control**: la mudanza da un poco de vértigo, y el
mensaje visual es "nosotros nos encargamos de todo, tú solo llegas a tu
nueva casa". Un pequeño camión/caja ilustrados en SVG recorre la pantalla de
izquierda (casa antigua, algo desordenada) a derecha (casa nueva, ordenada)
a medida que se hace scroll por el home — con `MotionPathPlugin` igual que en
la skill de motos, pero sin llegar a necesitar 3D.

## Escena 0 — Hero (0–100vh)

**Copy de ejemplo:**
> H1: **Tu mudanza, sin que tengas que preocuparte de nada**
> Subtítulo: Mudanzas y vaciados en El Vendrell y alrededores. Presupuesto
> claro en menos de 2 minutos.
> Botón principal: **Pedir presupuesto**
> Botón secundario: Llamar ahora · 977 200 200

**Animación:** Entrada en cascada del H1 y botones. Ilustración de cajas
apiladas con un ligero movimiento de "respiración" (`scale` sutil en bucle).

## Escena de transición (100–220vh) — el recorrido de la caja/camión

Un camión (o una caja con patas, según el tono de marca) se desplaza por una
ruta SVG desde la "casa antigua" hacia la "casa nueva", cruzando 2-3
etiquetas con lo que la empresa se encarga de resolver: **"Embalaje"**,
**"Transporte seguro"**, **"Montaje en destino"** — apareciendo y
desapareciendo según el camión las cruza (misma técnica de
`strokeDasharray`/`MotionPathPlugin` que en la skill de motos, sin nivel 3D).

## Escena 2 — Cómo trabajamos (220–300vh)

```
H2: Cómo trabajamos
H3 1: Nos cuentas qué necesitas mudar o vaciar
H3 2: Visita o presupuesto a distancia
H3 3: Embalaje y ejecución en la fecha acordada
H3 4: Entrega y revisión final contigo
```

**Animación:** Timeline horizontal con `pin: true`, iconos dibujados con
`strokeDashoffset` a medida que se hace scroll (igual patrón que en las
skills anteriores).

## Escena 3 — Servicios (300–380vh)

Grid de tarjetas con fade + stagger (`ScrollTrigger.batch()`), igual que en
las otras skills.

## Escena 4 — Zonas y confianza (380–460vh)

Contadores animados (*count-up*, disparo único): años de experiencia,
mudanzas realizadas, valoración media. Cifras reales editables desde
`CompanySetting`, nunca relleno — misma nota legal que en las skills
anteriores.

## Escena 5 — Opiniones (460–520vh)

Carrusel con scroll-snap, igual que en las skills anteriores.

## Escena 6 — FAQ (520–580vh)

Acordeón con las FAQ destacadas, enlace "Ver todas".

## Escena 7 — CTA final (580vh–fin)

**Copy de ejemplo:**
> H2: ¿Listo para tu próxima mudanza?
> "Cuéntanos qué necesitas y te preparamos un presupuesto claro, sin
> sorpresas de última hora."
> Botón: **Pedir presupuesto**   Botón: **Llamar ahora**

## Nota de tono para la página de vaciado por herencia

Esta página (o sección del servicio de vaciados) debe evitar cualquier
animación o copy con tono comercial agresivo o de urgencia — es un momento
delicado para quien la lee. Recomendación: sin cuenta atrás, sin lenguaje de
"oferta limitada", con un copy más pausado ("te acompañamos en un momento que
sabemos que no es fácil") y las mismas garantías de siempre (presupuesto
claro, gestión responsable) expresadas con un tono más sobrio que el resto de
la web.
