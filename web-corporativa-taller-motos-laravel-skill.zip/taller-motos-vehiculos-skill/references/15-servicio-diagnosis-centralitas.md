# 15 · Servicio de diagnosis y reprogramación de centralitas (ECU)

## 1. Qué es este servicio (alcance legítimo)

Servicio técnico en el que el taller conecta la centralita (ECU) del
vehículo del cliente a un ordenador con software de diagnosis específico
(vía OBD-II u otros conectores del fabricante), lee los códigos de error,
identifica la causa y **corrige o configura** lo que corresponda:

- Lectura y borrado de códigos de avería (DTC) tras la reparación real del
  problema que los originó (nunca borrar el código sin reparar la causa, eso
  sería solo ocultar el síntoma).
- Adaptaciones tras sustituir una pieza (por ejemplo, tras cambiar una
  batería, un sensor o un inyector, muchas centralitas necesitan una
  "adaptación"/reset para reconocer la pieza nueva).
- Actualización del software de la centralita a la versión que publica el
  fabricante (recall/campaña de actualización).
- Configuración de parámetros dentro de los rangos que el propio fabricante
  permite (por ejemplo, activar/desactivar una función de confort ya prevista
  de fábrica en ese modelo).
- Diagnóstico de fallos eléctricos/electrónicos complejos que no se detectan
  a simple vista (comunicación entre módulos, sensores intermitentes).

## 2. Lo que este servicio NO debe ofrecer (límite legal explícito)

Esto no es una cuestión de estilo: son prácticas **ilegales o directamente
delictivas** en España y en el resto de la UE, y no deben aparecer ni como
servicio ni como opción oculta en ningún formulario del admin:

- **Anulación o modificación de sistemas anticontaminación** (borrado de
  EGR, filtro de partículas/DPF, sistema AdBlue/SCR): constituye un
  "dispositivo manipulador" prohibido por el Reglamento (UE) 2016/646 y
  normativa de homologación de vehículos — además de infracción de tráfico
  grave y motivo de no pasar la ITV/inspección técnica equivalente.
- **Manipulación del cuentakilómetros**: es fraude tipificado (estafa /
  alteración de datos) conforme al Código Penal español y a la normativa de
  protección del consumidor en toda la UE.
- **Desactivación o bypass de sistemas antirrobo/inmovilizador** sin
  acreditar la titularidad del vehículo: facilita el robo de vehículos y
  puede constituir complicidad en un delito.
- **Reprogramación de vehículos con financiación activa que bloquee el
  motor** (dispositivos GPS-stop de financieras) sin autorización expresa de
  la entidad financiera — es alteración de un mecanismo de garantía de un
  tercero.
- **Aumento de potencia (chip-tuning) que saque al vehículo de su
  homologación** sin la posterior re-homologación/reforma exigida por
  tráfico — si el taller ofrece preparación/aumento de potencia como
  servicio adicional, debe informarse siempre de la obligación de reformar
  la ficha técnica antes de circular, nunca presentarlo como "sin trámites".

## 3. Cómo se refleja esto en el producto (nivel de especificación, no de código de explotación)

- El formulario de "Solicitar diagnosis de centralita" en el área privada
  del cliente **no ofrece ninguna opción** de las prohibidas en el apartado 2
  como casilla seleccionable — solo tipos de servicio legítimos (lista del
  apartado 1).
- El campo `service_note`/`observaciones` del ticket es de texto libre para
  que el cliente explique el problema, pero el equipo (`comercial`/`oficina`)
  tiene la obligación operativa de **rechazar y no ejecutar** cualquier
  solicitud que, aunque esté redactada de forma ambigua, encaje en el
  apartado 2 (p. ej. "quítame el filtro de partículas que me da problemas" se
  redirige a diagnosticar y reparar el filtro, no a eliminarlo).
- Cada ticket de este servicio queda con **trazabilidad completa**: VIN del
  vehículo, técnico que lo atendió, software/versión utilizada, códigos de
  error leídos antes y después, y descripción de la intervención realizada —
  esta trazabilidad protege tanto al cliente como al taller ante cualquier
  reclamación o requerimiento posterior.
- Antes de cualquier reprogramación, el sistema exige **confirmar la
  titularidad o autorización** del vehículo (nombre del titular según
  documentación aportada) — un simple checkbox no es prueba suficiente por sí
  solo; el flujo debe pedir subir la documentación del vehículo (ficha
  técnica/permiso de circulación) al ticket.

## 4. Modelo de datos (`ecu_service_tickets`)

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| lead_id / cliente_id | foreignId |
| vehicle_vin | string |
| service_type | enum('lectura_diagnostico','borrado_codigos_tras_reparacion','adaptacion_pieza','actualizacion_software','configuracion_parametros_oem','otro') |
| dtc_codes_before | text, nullable |
| dtc_codes_after | text, nullable |
| technician_id | foreignId → users |
| software_used | string |
| ownership_document_path | string (documento subido) |
| status | enum('recibido','en_diagnostico','presupuestado','en_reparacion','finalizado','rechazado') |
| rejection_reason | string, nullable (se rellena si `status = rechazado`, p. ej. "solicitud fuera del alcance legal del servicio") |
| notes | text |
| timestamps | |

## 5. Panel de administración

- `EcuServiceTicketResource`: gestión completa del flujo anterior, con
  filtro rápido por estado y alerta visual si un ticket lleva mucho tiempo
  "recibido" sin diagnosticar.
- Página de referencia interna (no pública) con el listado del apartado 2,
  visible para cualquier `comercial`/`oficina` que reciba una solicitud, para
  que el criterio de rechazo sea consistente entre todo el equipo.
