# 16 · Expansión internacional: qué países activar y marco legal/fiscal

> **Este es el archivo más importante para leer con un abogado/asesor fiscal
> antes de activar cualquier país o medio de pago.** No es un trámite menor:
> aquí se resumen los puntos que, mal resueltos, generan sanciones
> administrativas, contratos anulables o, en el caso de blanqueo de
> capitales, responsabilidad penal. Esta skill da el mapa; no sustituye el
> asesoramiento profesional específico para cada país que se active.

## 1. Planteamiento: gestionado desde España, activable país a país

La empresa se constituye y opera desde España (sede fiscal, alta de
actividad, registro AML si aplica). Cada país de la Unión Europea se activa
de forma **individual e independiente** en una tabla `countries` del admin
(`is_enabled`, notas legales, régimen de IVA aplicable, si se permite venta a
consumidores o solo a profesionales) — nunca "toda Europa a la vez" de
fábrica.

## 2. El punto legal más importante y menos obvio: subastas online y derecho de desistimiento

La Directiva 2011/83/UE de derechos de los consumidores define la
**"subasta pública"** exenta de ciertas normas de venta a distancia como:

> *"el método de venta en el que el comerciante ofrece bienes o servicios a
> los consumidores que **asisten o pueden asistir a la subasta en persona**,
> mediante un procedimiento transparente y competitivo de licitación
> dirigido por un subastador..."* (art. 2.13)

**Una subasta 100% online, sin ninguna posibilidad de asistencia física, no
encaja con claridad en esta definición.** La consecuencia práctica: el
derecho de desistimiento de 14 días propio de la venta a distancia con
consumidores **podría seguir aplicando** a una subasta puramente online,
salvo que se cumpla otra excepción del art. 16 (por ejemplo, bienes
personalizados, o que el propio consumidor pierda el derecho por las
características del contrato) — y un vehículo de segunda mano normalmente
NO encaja en esas otras excepciones. Esto es un área donde la doctrina
académica reconoce expresamente que la aplicación del desistimiento a
subastas "enteramente en línea" es compleja y no está resuelta de forma
uniforme en toda la UE.

**Cómo se aborda esto en la hoja de ruta (ver `SKILL.md`, sección 8):**

- **Fase 2 (subastas solo entre profesionales)**: si comprador y vendedor son
  ambos empresarios/profesionales actuando en su actividad (B2B), la
  normativa de protección de consumidores **no aplica** — es la vía más
  segura para lanzar el sistema de subastas sin resolver antes esta zona
  gris. Esto encaja de forma natural con permitir pujar solo a
  `cliente_profesional` en las primeras sesiones.
- **Fase 3 (apertura a particulares)**: antes de permitir pujar a
  `cliente_particular`, decidir con asesoría legal una de estas vías:
  (a) ofrecer explícitamente una forma de "asistencia en persona" (por
  ejemplo, una sede física donde se pueda seguir la subasta y pujar
  in situ el día del evento) para encajar en la definición de subasta
  pública; o (b) renunciar a esa exención y **conceder expresamente el
  derecho de desistimiento de 14 días** también en las compras por subasta a
  consumidores, ajustando el modelo de negocio a esa realidad (p. ej.
  depósito de garantía no reembolsable solo tras el periodo de
  desistimiento).

## 3. Prevención de blanqueo de capitales (Ley 10/2010, España)

- Quien **comercia profesionalmente con bienes** (aquí, vehículos) es
  "sujeto obligado" conforme al art. 2.1 de la Ley 10/2010 cuando se
  producen **cobros o pagos en efectivo superiores a 10.000 €** relacionados
  con esa actividad — un umbral habitual en toda la UE por transposición de
  las directivas antiblanqueo (AMLD).
- Ser sujeto obligado implica: aplicar medidas de diligencia debida
  (identificar al cliente y, en su caso, al titular real), conservar esa
  documentación, formar al personal, nombrar un representante ante el
  SEPBLAC, y comunicar operaciones con indicios de blanqueo.
- **Recomendación de producto**: limitar o desincentivar los pagos en
  efectivo en toda la plataforma (favorecer transferencia/pasarela de pago
  trazable) reduce tanto el riesgo legal como la complejidad operativa —
  aunque la obligación de diligencia debida como comerciante de bienes de
  valor puede aplicar igualmente en determinados casos, conviene revisarlo
  con el asesor.
- Este régimen es nacional (Ley 10/2010 en España) pero **cada país de la UE
  tiene su propia ley de transposición de las directivas antiblanqueo**, con
  umbrales y matices que pueden no ser idénticos — no asumir que las reglas
  españolas son válidas automáticamente al vender desde otro país activado.

## 4. IVA: régimen especial de bienes usados (REBU) y ventas intracomunitarias

- El **REBU** (arts. 135-139 Ley del IVA español / arts. 312-315 Directiva
  IVA de la UE) permite tributar solo por el **margen de beneficio**
  (precio de venta − precio de compra, IVA incluido en ambos) en vez de por
  el precio total, cuando el revendedor compra el vehículo a un particular o
  a otro revendedor que también aplicó REBU.
- Si el vehículo se compró con IVA general repercutido y deducible, la
  reventa **no puede** aplicar REBU: se aplica el régimen general.
- **Vehículos "nuevos" a efectos de IVA intracomunitario** (menos de 6 meses
  desde la primera matriculación **o** menos de 6.000 km recorridos) NO se
  consideran "usados" a estos efectos aunque el precio sea bajo — su venta a
  otro Estado miembro tributa de forma distinta (en destino), no bajo REBU.
  Este matiz es fácil de pasar por alto y afecta directamente a qué
  formulario/factura genera el sistema según la antigüedad/kilometraje del
  vehículo.
- En operaciones intracomunitarias bajo REBU, la **factura debe indicar
  expresamente** que la operación tributa conforme a los arts. 312 a 315 de
  la Directiva IVA — un campo de plantilla de factura, no texto libre
  improvisado cada vez (ver `18-gestion-documental-firma-electronica-poderes.md`).
- Si la plataforma cobra **suscripciones** (servicio digital) a consumidores
  de varios países de la UE, revisar con el asesor fiscal si corresponde
  darse de alta en la **Ventanilla Única (OSS - One Stop Shop)** para
  declarar el IVA de cada país del suscriptor sin registrarse individualmente
  en cada uno.

## 5. Protección de datos (RGPD) con roles sensibles

- El rol `aseguradora` accede a datos de vehículos y, potencialmente, de
  personas — aplicar **minimización de datos**: la aseguradora ve lo
  estrictamente necesario para su gestión (histórico del vehículo), no el
  perfil completo del comprador/vendedor salvo que exista una base legal
  específica (por ejemplo, gestión de un siniestro con consentimiento del
  asegurado).
- Cualquier intercambio de datos con una aseguradora como tercero requiere
  una **base legal** (consentimiento, ejecución de contrato, interés
  legítimo documentado) y, si hay transferencia estructurada y periódica,
  probablemente un **contrato de encargo de tratamiento o de corresponsables**
  entre la plataforma y la aseguradora (art. 26/28 RGPD).
- Los documentos con datos especialmente sensibles (por ejemplo, informes
  médicos en peritajes de accidentes) requieren medidas de seguridad
  reforzadas — cifrado en reposo y acceso restringido por rol y por caso
  concreto, no por rol genérico.

## 6. Qué mirar antes de activar cada país (tabla de trabajo, no exhaustiva)

| Aspecto a revisar por país | Por qué importa |
|---|---|
| ¿Se permite vender a consumidores por subasta online sin más requisitos, o hace falta licencia de subastador? | Algunos países tienen regulación específica de "auctioneers" (p. ej. tradición anglosajona) distinta a la española |
| ¿Cómo se transfiere la titularidad/matriculación de un vehículo comprado a otro país de la UE? | El comprador matricula en su país de residencia con la documentación de origen — la plataforma no gestiona la matriculación, pero debe emitir la documentación que el país de destino exige (factura, certificado de conformidad si aplica, informe de kilometraje) |
| ¿El país conduce por la izquierda? (Irlanda, Malta, Chipre) | Reintroducir un vehículo con el volante a la izquierda (conducción continental) en un país que circula por la izquierda tiene restricciones/sobrecostes de homologación — valorar excluir estos mercados o avisar de forma muy visible antes de pujar/comprar |
| ¿Está dentro de la Unión Aduanera de la UE? | Reino Unido, Suiza, Noruega son geográficamente "Europa" pero fuera de la unión aduanera: cualquier venta implica trámites de aduana e IVA de importación — tratarlos aparte, no como "un país más" de la UE |
| Umbral y ley de blanqueo de capitales local | Cada Estado miembro transpone las directivas AMLD con matices propios |
| Ley de protección de consumidores local | El Reglamento Roma I (art. 6) da derecho al consumidor a las normas imperativas de protección de su país de residencia **aunque el contrato señale la ley española como aplicable** — elegir "ley española" en las condiciones generales no blinda frente a esto cuando hay un consumidor de por medio |
| Idioma obligatorio de la información precontractual | Varios países exigen que las condiciones y la información al consumidor estén en su idioma oficial, no basta con ofrecer solo español/inglés |

## 7. Recomendación de lista de partida (a confirmar con asesoría legal, no una decisión cerrada)

- **Verde (activar primero)**: España (sede), y como fase 3 candidatos
  naturales por proximidad cultural/legal y volumen de mercado: Portugal,
  Francia, Italia — todos en la Unión Aduanera, conducción por la derecha,
  con tradición de derecho civil similar a la española.
- **Ámbar (evaluar caso a caso antes de activar)**: Alemania, Países Bajos,
  Bélgica, Polonia, Rumanía — mercados grandes pero con procedimientos de
  matriculación/documentación notablemente distintos que conviene mapear
  antes de anunciar la apertura.
- **Rojo (desactivar o tratar como caso especial, no como "un país más")**:
  Irlanda, Malta, Chipre (conducción por la izquierda), Reino Unido, Suiza,
  Noruega (fuera de la unión aduanera de la UE).

Esta clasificación es un punto de partida razonado, **no una conclusión
legal**: cada color debe confirmarse (o corregirse) con el asesor antes de
activar el país correspondiente en la tabla `countries` del admin.

## 8. Panel de administración — recurso nuevo

- `CountryResource`: `name`, `iso_code`, `is_enabled`, `allows_consumers`
  (bool — si permite venta a particulares o solo B2B), `vat_scheme_notes`,
  `legal_notes` (texto libre para que `admin` documente el resultado de la
  revisión legal de ese país), `requires_customs` (bool, para marcar los
  países fuera de la unión aduanera).
- El formulario de registro y el checkout comprueban `is_enabled` del país
  del usuario antes de permitir completar el alta o la compra — si el país
  no está activo, se muestra un mensaje claro ("Todavía no operamos en tu
  país") en vez de dejar completar el proceso a medias.
