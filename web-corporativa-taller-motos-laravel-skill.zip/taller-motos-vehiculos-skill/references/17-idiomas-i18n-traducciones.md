# 17 · Idiomas y traducciones (i18n)

## 1. Qué idiomas activar (ligado a los países de `16-...md`)

No se traduce "a todos los idiomas de Europa" de golpe — se traduce a los
idiomas de los países realmente activados, más los idiomas cooficiales
relevantes del propio mercado base:

| Fase | Idiomas |
|---|---|
| Fase 0-1 (España) | Español (`es`), catalán (`ca`) — cooficial en la zona de Cunit/El Vendrell — e inglés (`en`) como idioma "puente" para compradores internacionales desde el minuto uno |
| Fase 3 (Portugal, Francia, Italia) | + Portugués (`pt`), francés (`fr`), italiano (`it`) |
| Fase ámbar (`16-...md`) | + Alemán (`de`), neerlandés (`nl`), polaco (`pl`), rumano (`ro`), según qué países se confirmen |

## 2. Arquitectura técnica

- Sistema de localización nativo de Laravel (`lang/{locale}/*.php` o JSON) para
  textos de interfaz (botones, menús, mensajes del sistema, emails
  transaccionales).
- **Contenido gestionado desde el admin** (servicios, páginas legales, blog,
  fichas de vehículo) necesita traducción **por campo**, no solo de
  interfaz: usar `spatie/laravel-translatable` (añade un trait `HasTranslations`
  a los modelos Eloquent, guardando cada campo traducible como JSON
  `{"es": "...", "en": "...", "fr": "..."}` en la misma columna) — evita
  duplicar tablas enteras por idioma.
- Middleware de detección de idioma: 1º parámetro de URL/subcarpeta
  (`/es/...`, `/en/...`, `/fr/...` — recomendado para SEO, cada idioma con su
  propia URL indexable), 2º idioma guardado en el perfil del usuario si está
  logueado, 3º cabecera `Accept-Language` del navegador, 4º idioma por
  defecto del país detectado por IP como último recurso.
- **Cada idioma es una URL distinta** (`/es/servicios/...`,
  `/en/services/...`), nunca solo un selector que cambia el texto sin cambiar
  la URL — imprescindible para que Google indexe cada idioma como una página
  propia (ver apartado 4, SEO multilenguaje).

## 3. Qué se traduce y qué no

| Se traduce | No se traduce (o se adapta, no se traduce literal) |
|---|---|
| Toda la interfaz (menús, botones, formularios, emails) | Marca comercial (el nombre de la empresa no se traduce) |
| Contenido editorial (servicios, blog, FAQ, páginas legales) | Slugs de URL — sí conviene traducir el slug también (`/en/services/oil-change` en vez de `/en/services/cambio-de-aceite`) para SEO en cada idioma, pero manteniendo un `id` interno común que enlaza las versiones entre sí |
| Fichas de vehículo (descripciones redactadas) | Datos objetivos que no cambian por idioma (VIN, cilindrada, kilometraje — se muestran igual, solo cambia la unidad si el país usa otra distinta, poco habitual en la UE que usa el sistema métrico salvo excepciones) |
| Mensajes del sistema de subastas (pujas, estados) | Nombres de los roles en base de datos (quedan en un valor técnico interno tipo `enum`, se traduce su etiqueta visible, no el valor almacenado) |

## 4. SEO multilenguaje

- Etiquetas `hreflang` en cada página apuntando a sus equivalentes en los
  demás idiomas activos, más una etiqueta `x-default` apuntando a la versión
  en español (idioma principal de la plataforma).
- Sitemap.xml separado (o con bloques) por idioma, todos enlazados desde un
  sitemap índice.
- Meta title/description traducidos de verdad (no solo el cuerpo de la
  página) — un `<title>` sin traducir en una página en inglés es una señal
  de mala calidad tanto para el usuario como para Google.
- Nunca traducción automática sin revisión para el contenido más visible
  (home, fichas de servicio, páginas legales) — para blog/contenido menor,
  una primera pasada con traducción automática de calidad revisada
  después es aceptable como punto de partida.

## 5. Flujo de traducción de contenido en el admin

1. El editor crea/edita el contenido en el idioma principal (español).
2. En el mismo formulario de Filament, pestañas por idioma (un
   `Tabs::make()` con una pestaña por locale activo) para rellenar cada
   traducción del mismo campo sin salir del recurso.
3. Indicador visual en el listado de qué porcentaje de idiomas tiene
   completos cada contenido (por ejemplo, un badge "ES ✓ EN ✓ FR ✗") para
   detectar de un vistazo qué falta traducir antes de activar un idioma
   nuevo de cara al público.
4. Un idioma no se muestra en el selector público hasta que su contenido
   crítico (páginas fijas + servicios + legal) esté 100% traducido — mejor no
   ofrecer un idioma a medias que dar mala impresión con mezcla de idiomas.

## 6. Legal ligado al idioma

Como se apunta en `16-expansion-internacional-paises-legal-fiscal.md`
(apartado 6), varios países exigen que la información precontractual y las
condiciones legales estén disponibles en su idioma oficial para poder
vender allí — por eso la Fase 3 de países va siempre ligada a tener el
idioma correspondiente ya completado, no se activa un país sin su idioma.
