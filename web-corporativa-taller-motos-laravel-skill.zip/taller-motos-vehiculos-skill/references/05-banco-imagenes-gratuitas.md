# 05 · Banco de imágenes gratuitas (nuevo respecto a la skill de Desatascos)

Objetivo: que cada servicio, zona y sección del home tenga una imagen
relevante y de calidad, **sin coste y sin riesgo legal de derechos de autor**,
curada a mano (no genérica de "banco de imágenes de oficina").

## 1. Bancos recomendados y qué licencia tiene cada uno (verificado 2026)

| Banco | Licencia | ¿Atribución obligatoria? | Notas |
|---|---|---|---|
| **Pexels** (pexels.com) | Pexels License | No | Uso comercial y personal libre; no se puede dar a entender que la marca fotografiada respalda el taller; no vale para compilarlas en un banco de imágenes competidor |
| **Unsplash** (unsplash.com) | Unsplash License (desde la compra por Getty ya no es CC0) | No (recomendada, no obligatoria) | Uso comercial permitido salvo para crear un producto que compita con bancos de stock |
| **Pixabay** (pixabay.com) | Pixabay License (tampoco es CC0 desde su cambio de términos) | No | No se pueden redistribuir las imágenes como archivos sueltos ni como parte de otro banco de imágenes; cuidado con los resultados "Patrocinados" (enlazan a Shutterstock, de pago) |
| **StockSnap.io** | CC0 | No | Buen respaldo cuando Pexels/Unsplash no tienen lo que se busca |
| **Reshot** (reshot.com) | Reshot Free License | No | Fuerte en iconos e ilustraciones planas, útil para iconografía de servicios |
| **Burst by Shopify** (burst.shopify.com) | Shopify/Burst License | No | Orientado a producto/comercio, poco específico de motos pero útil para fondos genéricos de taller |

**Sitios a evitar** para imágenes de la web: buscador de Google Imágenes
directamente (cada resultado tiene su propia licencia, normalmente NO libre),
Pinterest (mismo problema), e Instagram/redes sociales de terceros (nunca usar
sin permiso explícito del autor).

**Regla de oro:** ante la duda sobre la licencia de una imagen concreta,
**no se usa**. Sustituir siempre por otra de un banco de la tabla de arriba.

## 2. Términos de búsqueda por servicio (para no acabar con fotos genéricas)

| Servicio | Búsquedas sugeridas (ES/EN, EN suele dar más resultados) |
|---|---|
| Home / hero | "motorcycle mechanic garage", "moto taller reparación", "motorcycle engine close up" |
| Cambio de aceite y filtros | "motorcycle oil change", "cambio aceite moto" |
| Reparación de motor | "motorcycle engine repair", "mecánico motor moto" |
| Frenos y neumáticos | "motorcycle brake disc", "motorcycle tire change" |
| Chapa y pintura | "motorcycle fairing paint", "motorcycle bodywork" |
| Asistencia en carretera | "motorcycle breakdown roadside", "moto averiada carretera" |
| Diagnosis electrónica | "motorcycle diagnostic tool", "motorcycle wiring" |
| Trabajos realizados (antes/después) | Recomendado usar **fotos propias reales** del taller en cuanto sea posible — para este apartado en concreto, una foto de stock resta credibilidad; usar banco de imágenes solo como placeholder temporal |
| Sobre nosotros / equipo | Evitar fotos de stock de "equipo sonriendo en oficina" (rompe la coherencia temática); mejor "mechanic workshop team", o directamente fotos reales del taller en cuanto existan |

## 3. Modelos 3D gratuitos (para la animación insignia en Nivel Full — ver `04-guion-animaciones-scroll.md`)

- **Sketchfab** (sketchfab.com): más de 600.000 modelos descargables. Filtrar
  siempre por:
  1. "Downloadable" activado.
  2. Licencia = **Standard** (uso comercial y no comercial sin atribución) o
     **CC0** (dominio público, sin atribución).
  3. Si el modelo deseado solo existe en **CC-BY**, es usable comercialmente
     pero **hay que acreditar al autor** de forma visible en la web (footer o
     página de créditos) — revisar la licencia exacta de cada modelo
     individual, puede variar entre modelos del mismo creador.
- Formato a exportar/descargar: `.glb` (formato binario glTF, el que espera
  `<model-viewer>` y la mayoría de visores web modernos).
- Si ningún modelo gratuito encaja con la estética de marca, alternativas:
  encargar un modelo low-poly simplificado a un freelance (coste bajo para un
  objeto simple), o quedarse directamente con el Nivel Lite en SVG (que no
  necesita ningún modelo 3D y es igualmente efectivo).

## 4. Flujo de trabajo de curación (para quien gestione el contenido)

1. Buscar 3-5 candidatas por cada hueco de imagen usando los términos de la
   tabla del apartado 2.
2. Descargar en la mayor resolución disponible.
3. Antes de subir, comprobar en la propia página del banco que la licencia
   sigue siendo la esperada (las políticas pueden variar con el tiempo,
   especialmente en Unsplash/Pixabay tras sus adquisiciones corporativas).
4. Subir desde el propio `ServiceResource`/`PostResource` del panel Filament
   (campo `featured_image`, gestionado por `spatie/laravel-medialibrary`), que
   se encarga de generar automáticamente las conversiones WebP/AVIF definidas
   (ver `08-stack-tecnico-paquetes.md`).
5. Rellenar siempre el campo `alt` con una descripción real de lo que se ve en
   la imagen y, cuando aplique, la palabra clave del servicio de forma
   natural (ej.: "Mecánico cambiando el aceite de una moto en el taller de El
   Vendrell") — nunca dejar el `alt` vacío ni relleno de keywords sin sentido.
6. Si la imagen requiere atribución (caso poco común con los bancos
   recomendados, pero posible con algún modelo CC-BY de Sketchfab), añadir el
   crédito en el campo correspondiente del admin (ver
   `06-panel-administracion.md`, campo `image_credit` opcional en el modelo
   de medios) para que se muestre automáticamente donde corresponda.

## 5. Por qué esto también es SEO (no solo estética)

- Imágenes específicas del sector (motor, frenos, taller real) en vez de
  fotos de stock genéricas mejoran la señal de relevancia temática de la
  página (Google también analiza el contexto alrededor de la imagen: `alt`,
  texto cercano, nombre de archivo).
- Nombrar el archivo de forma descriptiva antes de subirlo ayuda a
  Google Images: `cambio-aceite-moto-el-vendrell.webp` en vez de
  `IMG_04213.jpg`.
- Las fotos reales del propio taller (trabajos realizados, equipo, local)
  son, con diferencia, la señal más fuerte de autenticidad/E-E-A-T para
  Google y para el propio cliente — los bancos gratuitos son un buen punto de
  partida para lanzar la web, pero deben sustituirse progresivamente por
  contenido visual real del negocio en cuanto sea posible.
