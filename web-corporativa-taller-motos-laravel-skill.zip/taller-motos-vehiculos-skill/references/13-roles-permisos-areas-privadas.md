# 13 · Roles, áreas privadas y restricción de rutas

## 1. Los 6 roles y su propósito

| Rol | Quién es | Objetivo principal en la plataforma |
|---|---|---|
| `admin` | Propietario/responsable técnico de la plataforma | Control total: configuración, roles, países activos, planes, finanzas |
| `oficina` | Back office / administración interna | Gestión operativa diaria: moderación de anuncios, leads, documentación, soporte |
| `comercial` | Agente comercial/ventas | Gestión de su cartera de clientes, vehículos asignados, comisiones, cita/seguimiento |
| `cliente_profesional` | Concesionario, gestoría, taller asociado | Publicar stock propio, pujar en subastas, gestionar sus propios documentos y facturas |
| `cliente_particular` | Comprador/vendedor individual | Comprar, vender, pujar (si su plan lo permite), gestionar sus propios datos y documentos |
| `aseguradora` | Compañía de seguros colaboradora | Consultar vehículos siniestrados/en gestión, subir/descargar peritajes, ver histórico de un vehículo por VIN |

## 2. Implementación técnica de roles

- Paquete recomendado: `spatie/laravel-permission` (roles + permisos, estándar
  de facto en Laravel) + `bezhansalleh/filament-shield` para generar y
  gestionar los permisos de cada `Resource` de Filament automáticamente por
  rol.
- Cada usuario (`User`) tiene un único rol principal (evita la complejidad de
  roles múltiples salvo que el proyecto real lo requiera; si un mismo
  usuario necesita dos roles, mejor dos cuentas separadas para no mezclar
  áreas privadas y permisos).
- Los permisos se definen a nivel de **recurso + acción** (`ver`, `crear`,
  `editar`, `eliminar`, `exportar`, `aprobar`) para cada modelo, no solo
  "acceso sí/no" al panel.

## 3. Restricción de rutas por rol (obligatorio, no opcional)

### 3.1 Middleware de rol

```php
// app/Http/Middleware/EnsureRole.php
public function handle($request, Closure $next, ...$roles)
{
    if (! $request->user() || ! $request->user()->hasAnyRole($roles)) {
        abort(403);
    }
    return $next($request);
}
```

### 3.2 Aplicación en rutas (patrón)

```php
Route::middleware(['auth', 'role:admin'])->prefix('area/admin')->group(function () {
    // rutas exclusivas de admin
});

Route::middleware(['auth', 'role:oficina,admin'])->prefix('area/oficina')->group(function () {
    // oficina y admin (admin ve todo)
});

Route::middleware(['auth', 'role:comercial,oficina,admin'])->prefix('area/comercial')->group(function () {
    // comercial y superiores
});

Route::middleware(['auth', 'role:cliente_profesional'])->prefix('area/profesional')->group(function () {
    // solo clientes profesionales
});

Route::middleware(['auth', 'role:cliente_particular'])->prefix('area/particular')->group(function () {
    // solo clientes particulares
});

Route::middleware(['auth', 'role:aseguradora'])->prefix('area/aseguradora')->group(function () {
    // solo aseguradoras
});
```

### 3.3 Reglas de oro de la restricción de rutas

- **Nunca confiar solo en ocultar el enlace en el menú** — cada ruta debe
  estar protegida en el propio middleware/backend, porque una URL escrita a
  mano por un usuario sin permiso debe devolver 403, no simplemente "no
  aparecer en el menú".
- Aplicar el mismo control dentro de **Filament** con `filament-shield`, para
  que cada `Resource`/página del panel compruebe el permiso además de la
  ruta HTTP general.
- Las **acciones** (no solo las páginas) también se protegen: por ejemplo,
  `comercial` puede *ver* todos los vehículos de su oficina pero solo
  *editar* los que tiene asignados (`$vehicle->comercial_id === auth()->id()`
  como comprobación adicional dentro del `Policy`, no solo el rol genérico).
- Usar **Laravel Policies** por modelo (`VehicleListingPolicy`,
  `AuctionLotPolicy`, `DocumentPolicy`...) para la lógica fina de "puede
  editar esto en concreto", dejando el middleware de rutas para el corte
  grueso "puede entrar en esta sección o no".
- Test automatizado mínimo: por cada rol, un test que intente acceder a las
  rutas de los demás roles y compruebe que responde 403 — evita regresiones
  cuando se añadan rutas nuevas en el futuro.

## 4. Qué tiene cada rol en su área privada

### `admin`
- Todo lo de `oficina` + gestión de usuarios y roles, activación/desactivación
  de países (`16-...md`), configuración de planes de suscripción, ajustes
  globales de marca/tema, logs de auditoría de toda la plataforma, informes
  financieros globales (ventas, comisiones, ingresos por suscripción).

### `oficina`
- Bandeja de leads (todos), moderación de anuncios (vehículos/piezas)
  pendientes de aprobar, gestión de sesiones de subasta (crear/editar/
  cancelar), gestión documental general (ver `18-...md`), soporte a clientes
  (histórico de conversaciones/incidencias), asignación de leads a
  comerciales, informes operativos (no financieros globales, esos son de
  `admin`).

### `comercial`
- Su cartera de clientes y vehículos asignados, calendario de
  seguimientos/citas, generación de documentos de venta y de poder/
  autorización para sus propios clientes (con la firma electrónica del
  cliente, ver `18-...md`), panel de comisiones propias, historial de leads
  que ha cerrado/perdido.

### `cliente_profesional`
- Publicación y gestión de su propio stock (vehículos y piezas), historial de
  compras/ventas realizadas en la plataforma, participación en subastas
  (pujar y también poner sus propios vehículos a subasta si el plan lo
  permite), facturación propia (descarga de facturas emitidas y recibidas a
  través de la plataforma), gestión de su ficha de empresa (CIF, dirección,
  usuarios adicionales de su organización si se permite multi-usuario por
  cuenta profesional).

### `cliente_particular`
- Sus vehículos en venta/subasta, sus pujas activas e historial, sus
  compras, sus documentos personales (contratos de compraventa, facturas),
  gestión de su suscripción/plan, mensajes con comerciales o con otros
  usuarios (si se habilita mensajería), preferencias de notificación
  (nuevas pujas, resultado de subastas seguidas).

### `aseguradora`
- Búsqueda de vehículos por VIN/matrícula (histórico dentro de la
  plataforma: si ha estado en venta, en subasta, informes de estado
  aportados), subida de peritajes o informes de siniestro vinculados a un
  vehículo, descarga de la documentación que la plataforma tenga de ese
  vehículo (con consentimiento/base legal adecuada — ver nota de protección
  de datos en `16-...md`, apartado de GDPR), sin acceso a datos personales de
  compradores/vendedores más allá de lo estrictamente necesario para su
  gestión (principio de minimización de datos).

## 5. Menú dinámico por rol

El layout del área privada renderiza el menú lateral a partir de los
permisos reales del usuario (`auth()->user()->getPermissionsViaRoles()`), no
de una lista fija en Blade — así, si mañana se ajustan permisos de un rol
desde el admin, el menú se actualiza solo, sin tocar código ni plantillas.
