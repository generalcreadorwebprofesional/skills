# 19 · Modelo de datos ampliado (v3)

Consolida en un único lugar las tablas nuevas descritas en los archivos 11 a
18, para tener una vista completa antes de migrar. Los campos ya detallados
en su archivo de origen no se repiten en extenso aquí, solo se listan para
referencia rápida.

## 1. Marketplace (`11-...md`)

- `vehicle_listings`: datos del vehículo, precio, estado, `seller_type`
  (enum: oficina/comercial/profesional/particular), `country_id`.
- `part_listings`: datos de la pieza, compatibilidad (JSON de marcas/
  modelos/años), `vehicle_listing_id` de procedencia (nullable).

## 2. Subastas (`12-...md`)

- `auction_sessions`: `starts_at`, `ends_at`, `status`, `animation_level`
  (`lite`/`full`), `country_scope` (nullable, si una sesión se limita a
  ciertos países).
- `auction_lots`: `auction_session_id`, `vehicle_listing_id`, `starting_price`,
  `reserve_price` (oculto a frontend), `current_price`, `min_increment`,
  `status`, `extended_until` (nullable, para la extensión anti-sniping).
- `bids`: `auction_lot_id`, `bidder_id`, `amount`, `created_at` (inmutable,
  nunca se edita ni se borra, solo se puede anular con un registro aparte).
- `bid_logs`: copia de auditoría con IP/user agent de cada `bid` (o
  ampliación de la propia tabla `bids` con esas columnas si se prefiere no
  duplicar).

## 3. Roles y permisos (`13-...md`)

- Tablas estándar de `spatie/laravel-permission`: `roles`, `permissions`,
  `model_has_roles`, `model_has_permissions`, `role_has_permissions` — no
  requieren diseño propio, las genera el paquete.

## 4. Suscripciones (`14-...md`)

- `subscription_plans`: `name`, `price`, `interval` (mensual/anual),
  `permissions_unlocked` (JSON o relación con `permissions`).
- Tablas de `laravel/cashier` (`subscriptions`, `subscription_items`) si se
  usa Stripe vía Cashier — no requieren diseño propio.

## 5. Servicio de centralitas (`15-...md`)

- `ecu_service_tickets`: ver tabla completa en el archivo de origen.

## 6. Internacionalización de negocio (`16-...md`)

- `countries`: `name`, `iso_code`, `is_enabled`, `allows_consumers`,
  `vat_scheme_notes`, `legal_notes`, `requires_customs`.

## 7. Idiomas (`17-...md`)

- Sin tablas propias: los campos traducibles se guardan como columnas JSON
  en los modelos existentes vía `spatie/laravel-translatable`
  (`HasTranslations` trait) — por ejemplo, `services.name` pasa de `string`
  a `json` con `{"es": "...", "en": "...", "fr": "..."}`.

## 8. Documentos (`18-...md`)

- `documents`: ver tabla completa en el archivo de origen (`morphTo` hacia
  vehículo, lote, ticket o usuario).
- `document_templates`: `type`, `content` (con campos de fusión),
  `version`, `is_active`.

## 9. Relaciones clave entre módulos (resumen visual)

```
User ──< Role (spatie/permission)
User ──< Subscription (cashier)
User ──1 Country

VehicleListing ──1 User (seller)
VehicleListing ──0..1 AuctionLot
VehicleListing ──< PartListing (procedencia)

AuctionSession ──< AuctionLot ──< Bid ──1 User (bidder)

Document ──morphTo── (VehicleListing | AuctionLot | EcuServiceTicket | User)

EcuServiceTicket ──1 User (cliente) ──1 User (technician)
```

## 10. Índices y rendimiento a vigilar desde el diseño inicial

- `bids`: índice compuesto (`auction_lot_id`, `created_at`) — es la tabla que
  más escritura/lectura concurrente va a recibir durante una sesión en
  directo.
- `vehicle_listings`: índice en `vin` (único, para detectar duplicados) y en
  (`status`, `country_id`) para los listados filtrados del marketplace.
- `documents`: índice en (`documentable_type`, `documentable_id`) por ser
  tabla polimórfica de alto volumen a medio plazo.
