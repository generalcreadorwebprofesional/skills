# 07 · Modelo de datos (Eloquent)

Base idéntica a la skill de Desatascos (`company_settings`, `services`,
`service_areas`, tabla pivote, `testimonials`, `post_categories`, `posts`,
`faqs`, `leads`, `legal_pages`, `redirects`) — se detallan aquí solo los
campos añadidos o distintos para el taller de motos.

## 1. `company_settings` — campos adicionales

| Campo | Tipo |
|---|---|
| brands_worked_with | text, nullable |
| roadside_assistance_radius_km | unsignedInteger, nullable |
| animations_3d_enabled | boolean, default false |
| hero_moto_model_path | string, nullable |
| hero_moto_poster_image | string, nullable |
| industrial_registry_number | string, nullable |

## 2. `services` — campos adicionales

| Campo | Tipo |
|---|---|
| vehicle_type | enum('moto','scooter','quad','otros'), default 'moto' |

(El resto de campos — `name`, `slug`, `icon`, `featured_image`,
`short_description`, `description`, `is_emergency`, `is_featured`, `order`,
`meta_title`, `meta_description`, `focus_keyword`, `published` — son
idénticos a la skill de Desatascos.)

```php
Schema::table('services', function (Blueprint $table) {
    $table->enum('vehicle_type', ['moto', 'scooter', 'quad', 'otros'])->default('moto');
});
```

## 3. `media` (extensión sobre `spatie/laravel-medialibrary`)

La tabla `media` la gestiona el propio paquete; se añaden campos personalizados
vía `custom_properties` (columna JSON nativa del paquete, no requiere
migración propia):

| Custom property | Tipo | Uso |
|---|---|---|
| alt_text | string | Texto alternativo obligatorio |
| source | enum('propia','banco_gratuito','modelo_3d') | Trazabilidad del origen |
| image_credit | string, nullable | Crédito si la licencia lo requiere |

## 4. Resto de tablas

`service_areas`, `service_service_area`, `testimonials`, `post_categories`,
`posts`, `post_service`, `faqs`, `leads`, `legal_pages`, `redirects`: mismos
campos y relaciones que en la skill de Desatascos
(`06-modelo-datos-laravel.md` de aquella skill). Único cambio de negocio: en
`leads`, el campo `service_area_id`/`service_id` ahora referencian
servicios/zonas de taller de motos en vez de desatascos, sin cambio de
estructura.

## 5. Relaciones Eloquent (resumen, sin cambios respecto a Desatascos)

```php
// Service
public function serviceAreas(): BelongsToMany { return $this->belongsToMany(ServiceArea::class); }
public function faqs(): HasMany { return $this->hasMany(Faq::class); }
public function testimonials(): HasMany { return $this->hasMany(Testimonial::class); }
public function posts(): BelongsToMany { return $this->belongsToMany(Post::class); }

// ServiceArea
public function services(): BelongsToMany { return $this->belongsToMany(Service::class); }
public function testimonials(): HasMany { return $this->hasMany(Testimonial::class); }

// Route model binding por slug en todos los modelos con slug
public function getRouteKeyName(): string { return 'slug'; }
```

`CompanySetting::current()` sigue el mismo patrón singleton cacheado descrito
en la skill de Desatascos.
