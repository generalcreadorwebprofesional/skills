# 03 · Estructura de encabezados (H1–H6)

Misma regla inquebrantable que en la skill de Desatascos: **1 H1 por página**,
jerarquía en cascada sin saltos. Textos de ejemplo = datos por defecto de
"Taller RPM", editables desde el admin.

## 1. Home (`/`)

```
H1: Taller RPM · Reparación de motos en El Vendrell y toda la comarca
  H2: Servicios para tu moto
    H3: Cambio de aceite y filtros
    H3: Reparación de motor
    H3: Frenos y neumáticos
    H3: Chapa y pintura
    H3: Asistencia en carretera
  H2: Zonas donde trabajamos
    H3: El Vendrell
    H3: Cunit
    H3: Calafell
    H3: Cubelles
  H2: Por qué elegir a Taller RPM
    H3: Mecánicos con más de [X] años de experiencia
    H3: Presupuesto claro antes de tocar la moto
    H3: Piezas originales o de calidad equivalente, tú eliges
    H3: Garantía por escrito de cada reparación
  H2: Cómo trabajamos
    H3: 1. Nos cuentas qué le pasa a tu moto
    H3: 2. Diagnóstico y presupuesto sin compromiso
    H3: 3. Reparación con plazos claros
    H3: 4. Recogida, prueba y garantía
  H2: Opiniones de nuestros clientes
  H2: Preguntas frecuentes
    H3: (una por pregunta destacada en home, máx. 4-5)
  H2: Últimos consejos del blog
  H2: ¿Tu moto se ha averiado?
```

## 2. Ficha de servicio (`/servicios/{servicio}`)

```
H1: Cambio de aceite y filtros en El Vendrell
  H2: En qué consiste este servicio
  H2: Cuándo lo necesitas
    H3: Síntoma 1 — el aceite lleva más de [X] km sin cambiarse
    H3: Síntoma 2 — el motor suena distinto
    H3: Síntoma 3 — pierde potencia o consume más
  H2: Cómo trabajamos este servicio
    H3: Diagnóstico previo
    H3: Sustitución de aceite y filtro
    H3: Prueba final y garantía
  H2: Zonas donde ofrecemos este servicio
    H3: (lista de 3-6 ServiceArea relacionadas)
  H2: Preguntas frecuentes sobre este servicio
  H2: Solicita presupuesto sin compromiso
```

## 3. Ficha de zona (`/zonas-de-servicio/{zona}`)

```
H1: Taller de motos en El Vendrell
  H2: Taller de reparación de motos en El Vendrell y municipios cercanos
  H2: Servicios disponibles en El Vendrell
    H3: (uno por cada Service ofrecido en esa zona)
  H2: Zonas cercanas a El Vendrell que también cubrimos
  H2: Opiniones de clientes en El Vendrell
  H2: ¿Tu moto se ha averiado en El Vendrell?
```

## 4. Artículo de blog (`/blog/{post}`)

```
H1: [Título del artículo — único, con la keyword objetivo]
  H2: [Subtema 1]
    H3: [si se divide en pasos]
  H2: [Subtema 2]
  H2: Cuándo llevarla al taller
  H2: Servicios relacionados
```

## 5. Preguntas frecuentes (`/preguntas-frecuentes`)

```
H1: Preguntas frecuentes sobre reparación de motos
  H2: Precios y presupuestos
    H3: (una por pregunta)
  H2: Averías y asistencia en carretera
    H3: (una por pregunta)
  H2: Sobre el servicio técnico y las piezas
    H3: (una por pregunta)
```

## 6. Contacto (`/contacto`) y Presupuesto (`/presupuesto`)

```
H1: Contacta con Taller RPM
  H2: Nuestros datos de contacto
  H2: Formulario de contacto
  H2: Dónde estamos y zonas que cubrimos
```

## 7. Sobre nosotros (`/sobre-nosotros`)

```
H1: Sobre Taller RPM
  H2: Nuestra historia
  H2: El equipo
  H2: Marcas con las que trabajamos
  H2: Compromiso ambiental y normativo
    H3: Gestión de residuos conforme a normativa
    H3: Taller inscrito en el Registro Industrial
```

## 8. Páginas legales

```
H1: Aviso legal   /   H1: Política de privacidad   /   H1: Política de cookies
  H2: (un H2 por cada apartado obligatorio — ver 09-legal-cumplimiento.md)
```

## 9. Checklist de validación por página

- [ ] Exactamente un `<h1>` en el HTML renderizado.
- [ ] Ningún H2/H3 vacío o puramente decorativo.
- [ ] El H1 contiene la keyword principal de forma natural.
- [ ] Todos los H2 están en el nivel de anidación correcto en el DOM.
