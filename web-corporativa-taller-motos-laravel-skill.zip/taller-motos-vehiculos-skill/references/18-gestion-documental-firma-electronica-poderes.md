# 18 · Gestión documental, firma electrónica y generación de poderes

## 1. Qué tipos de documento genera/gestiona la plataforma

| Documento | Quién lo genera | Necesita firma electrónica |
|---|---|---|
| Contrato de compraventa de vehículo/pieza | Sistema, a partir de la ficha del anuncio + datos de comprador/vendedor | Sí |
| Factura (venta directa, comisión de subasta, suscripción) | Sistema, automática | No (documento tributario, no contractual en ese sentido) |
| Autorización/mandato para trámites (p. ej. "autorizo a [comercial] a presentar esta documentación en mi nombre") | `comercial` u `oficina`, con datos del cliente | Sí — ver apartado 3, límites importantes |
| Presupuesto / ficha de intervención (taller, centralitas) | `comercial`/`oficina` | Firma simple de aceptación por parte del cliente |
| Informe de peritaje (aseguradora) | Rol `aseguradora`, sube su propio PDF | No lo genera la plataforma, solo lo almacena |
| Condiciones de participación en subasta (aceptadas al pujar por primera vez) | Sistema, versión vigente en el momento de aceptar | Sí (aceptación con registro de fecha/hora/IP) |

## 2. Arquitectura técnica

- **Generación de PDF**: plantillas Blade renderizadas a PDF (ver skill
  `pdf` del propio proyecto de generación de documentos si está disponible
  en el entorno, o `barryvdh/laravel-dompdf`/`spatie/browsershot` en Laravel)
  con **campos de fusión** (merge fields) del tipo `{{cliente.nombre}}`,
  `{{vehiculo.vin}}`, `{{empresa.cif_nif}}` — nunca texto fijo con datos
  copiados a mano.
- **Almacenamiento**: `spatie/laravel-medialibrary` (ya usado en el resto de
  la skill) sobre un disco privado (no público), con control de acceso por
  Policy: un cliente solo puede descargar sus propios documentos; `oficina`/
  `admin` pueden ver todos; `comercial` solo los de su cartera;
  `aseguradora` solo los vinculados a los vehículos que gestiona.
- **Versionado**: cada documento guarda la versión de la plantilla legal con
  la que se generó (importante para las condiciones de subasta: si cambian,
  hay que poder demostrar qué versión aceptó cada usuario y cuándo).

## 3. Firma electrónica: qué nivel hace falta según el documento (eIDAS)

El Reglamento eIDAS (UE) 910/2014 distingue tres niveles, y **no todos los
documentos necesitan el nivel más alto**:

| Nivel | Qué es | Para qué sirve aquí |
|---|---|---|
| **Firma electrónica simple** | Cualquier dato en formato electrónico que el firmante usa para manifestar su voluntad (un clic de "Acepto" con registro de IP/fecha) | Aceptación de condiciones de subasta, presupuestos, aceptación de un servicio de taller |
| **Firma electrónica avanzada (AdES)** | Vinculada de forma única al firmante, permite identificarlo y detectar cualquier cambio posterior en el documento | Contratos de compraventa entre particulares/profesionales — proveedores como Signaturit, DocuSign o SignWell ofrecen este nivel con verificación de identidad razonable |
| **Firma electrónica cualificada (QES)** | Emitida por un prestador cualificado de confianza, equivalente legal a la firma manuscrita en toda la UE | Solo para los documentos de mayor peso jurídico si el proyecto real lo requiere (p. ej. determinados poderes, según el trámite concreto) |

**Recomendación práctica**: integrar un proveedor de firma electrónica ya
homologado bajo eIDAS (no construir un sistema de firma propio desde cero)
para los niveles avanzado/cualificado — construir solo la capa de "firma
simple" (checkbox + registro de auditoría) internamente, que es
perfectamente válida para consentimientos y aceptaciones de bajo riesgo.

## 4. Generación de poderes/autorizaciones — el punto que requiere más cuidado

La plataforma puede **generar un documento de autorización o mandato**
(por ejemplo, "autorizo a mi comercial a realizar en mi nombre el trámite
X ante la administración/aseguradora Y"), pre-rellenado con los datos del
cliente desde su ficha. Esto es una función de producto legítima y útil,
pero con límites que hay que respetar:

- Un **mandato/autorización simple** para gestiones de bajo riesgo (por
  ejemplo, presentar papeleo administrativo sencillo en nombre del cliente)
  puede bastar con firma electrónica simple/avanzada y no siempre requiere
  notario.
- Un **poder notarial** propiamente dicho — el que se necesita para actos de
  mayor trascendencia jurídica, o cuando un tercero (registro público,
  notaría, entidad financiera) exige específicamente "poder ante notario" —
  **no puede sustituirse por un documento generado y firmado solo en la
  plataforma**: debe otorgarse ante notario para tener esa validez, aunque
  la plataforma perfectamente puede generar el **borrador/minuta** con todos
  los datos ya rellenados para que el cliente solo tenga que llevarlo a la
  notaría (ahorra tiempo real, sin fingir una validez que el documento no
  tiene por sí solo).
- El sistema debe **distinguir claramente** entre ambos tipos de documento en
  su plantilla y en la interfaz: un "mandato/autorización de gestión" se
  presenta como tal, y si el trámite concreto requiere poder notarial, la
  plataforma debe decirlo explícitamente en pantalla ("Este trámite requiere
  poder notarial; te generamos la minuta para llevar a la notaría, no puede
  firmarse solo desde aquí") en vez de dejar que el usuario asuma que ya
  está todo resuelto.
- Nunca generar ni entregar un documento de poder/autorización sin que el
  propio interesado (el cliente cuyos datos se usan) lo haya revisado y
  firmado él mismo — un `comercial` no puede generar y dar por firmado un
  poder "en nombre de" un cliente sin su participación activa en el proceso
  de firma.

## 5. Modelo de datos (`documents`)

| Campo | Tipo |
|---|---|
| id | bigIncrements |
| documentable_type / documentable_id | morphTo (vehículo, lote de subasta, ticket de centralita, usuario...) |
| type | enum('contrato_compraventa','factura','autorizacion_gestion','minuta_poder_notarial','presupuesto','condiciones_subasta_aceptadas','peritaje','otro') |
| template_version | string |
| generated_by | foreignId → users |
| file_path | string (disco privado) |
| signature_status | enum('no_requiere','pendiente','firmado_simple','firmado_avanzado','firmado_cualificado') |
| signed_at | timestamp, nullable |
| signer_ip | string, nullable |
| signature_provider_reference | string, nullable (id de la firma en el proveedor externo, si aplica) |
| timestamps | |

## 6. Panel de administración

- `DocumentResource`: listado con filtros por tipo/estado de firma,
  descarga controlada por permisos, reenvío de solicitud de firma pendiente.
- Plantillas de documento editables desde un `DocumentTemplateResource`
  (texto con campos de fusión, para que cambios legales en el aviso legal o
  en las condiciones de subasta no requieran tocar código).
- Alerta automática si un documento de tipo `minuta_poder_notarial` aparece
  marcado como `firmado_*` sin pasar por el flujo notarial — no debería
  ocurrir nunca por diseño (apartado 4), y si ocurre es una señal de que
  algo se ha implementado o usado mal.
