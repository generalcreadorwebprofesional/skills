# 09 · Cumplimiento legal

> **Aviso importante**: esto es una guía técnica de qué apartados y mecánicas
> debe tener la web (y, en el apartado 4, qué trámites tiene el negocio en
> sí) para acercarse al cumplimiento normativo español. No sustituye el
> asesoramiento de un abogado o gestor: antes de operar y publicar la web con
> datos reales, un profesional debe revisar y adaptar todo al caso concreto.

## 1. Marco legal aplicable a la web (idéntico a la skill de Desatascos)

- **LSSI-CE** — Aviso Legal con los datos identificativos del titular.
- **RGPD** + **LOPDGDD** — tratamiento de datos personales (formularios).
- **Guía de cookies de la AEPD** (vigente en 2026) — rechazar tan fácil como
  aceptar.
- **Ley General de Publicidad** — reclamos comerciales verificables.

## 2. Las 3 páginas legales obligatorias

Mismo contenido mínimo que en la skill de Desatascos:

- `/aviso-legal`: identificación del titular (razón social, CIF/NIF,
  domicilio social, registro mercantil, email), objeto y condiciones de uso,
  propiedad intelectual, exclusión de responsabilidad, legislación aplicable.
- `/politica-de-privacidad`: responsable, finalidad, legitimación,
  destinatarios, plazo de conservación, derechos ARCO-POL, derecho a
  reclamar ante la AEPD.
- `/politica-de-cookies`: tabla de cookies (nombre, finalidad, tipo,
  duración, si requiere consentimiento), cómo configurar/retirar el
  consentimiento, cómo eliminar cookies del navegador.

Contenido en `legal_pages.content` con placeholders (`{{empresa.legal_name}}`,
`{{empresa.cif_nif}}`, etc.) resueltos al renderizar.

## 3. Banner de cookies (idéntico a la skill de Desatascos)

- Primera capa con **3 acciones al mismo nivel**: "Aceptar todas" /
  "Rechazar todas" / "Configurar".
- Segunda capa con categorías (técnicas bloqueadas activas, analíticas y
  marketing desmarcadas por defecto).
- Ningún script de terceros se carga antes del consentimiento.
- Enlace permanente "Configurar cookies" en el footer.
- Casilla de aceptación de privacidad (no premarcada) en todos los
  formularios, validada también en el `FormRequest` de Laravel.

## 4. Obligaciones propias de un taller de motos/vehículos (más allá de la web)

Esto no es "SEO de la web", pero es contenido que **sí conviene mostrar en
`/sobre-nosotros`** como señal de confianza (y de E-E-A-T real ante Google:
un taller que demuestra estar registrado y cumplir la normativa ambiental
transmite mucha más credibilidad que uno que no dice nada al respecto):

- **Inscripción en el Registro Industrial** de la comunidad autónoma
  correspondiente — requisito para operar como taller de reparación de
  vehículos en España. El número de registro puede mostrarse en
  `/sobre-nosotros` (campo `industrial_registry_number` en
  `CompanySetting`, ver `06-panel-administracion.md`).
- **Licencia de actividad municipal**, obtenida presentando un proyecto
  técnico que cumpla la normativa del ayuntamiento correspondiente.
- **Alta como productor (o pequeño productor) de residuos peligrosos** ante
  la comunidad autónoma — obligatoria porque un taller de motos genera
  aceites usados, baterías, neumáticos y otros residuos calificados como
  peligrosos según la Ley 7/2022 de residuos y suelos contaminados.
- **Gestión de aceites industriales usados** conforme al RD 679/2006: si se
  generan más de 500 litros al año, debe llevarse un registro (cantidades,
  origen, fechas de entrega/recepción) y entregarse siempre a un **gestor de
  residuos autorizado**, formalizado con un Documento de Control y
  Seguimiento.
- **Archivo cronológico** de los residuos generados y entregados, y
  **contrato de tratamiento** con el gestor autorizado — documentos que las
  inspecciones (Policía Local, SEPRONA) piden habitualmente; su ausencia es
  la causa más común de sanciones a talleres no regularizados.
- **Seguro de responsabilidad civil** que cubra los daños que puedan
  ocurrir a los vehículos de clientes mientras están en el taller.

Ninguno de estos trámites lo gestiona la web en sí, pero **mencionarlos
explícitamente en `/sobre-nosotros`** (ver estructura en
`03-estructura-encabezados-hn.md`, H2 "Compromiso ambiental y normativo") es
una señal de confianza diferencial frente a talleres informales — y, dado el
contexto de webs de la competencia con talleres irregulares detectados en la
comarca, una ventaja competitiva real y honesta.

## 5. Reclamos publicitarios: qué evitar

Igual que en la skill de Desatascos: evitar superlativos absolutos no
verificables (~~"los mecánicos más baratos de la comarca"~~,
~~"reparación garantizada al 100% siempre"~~). Sustituir por reclamos
concretos y editables desde el admin: "Presupuesto cerrado antes de tocar la
moto", "Garantía por escrito de X meses en cada reparación", "Mecánicos con
X años de experiencia" (solo si es cierto).

Cuidado adicional en este sector: no prometer plazos de reparación que
después no se puedan cumplir de forma sistemática (publicidad engañosa por
incumplimiento reiterado) y no usar logotipos de marcas de motos (Honda,
Yamaha, etc.) sin autorización — mencionar la marca en texto es lícito
("trabajamos con Honda y Yamaha"), pero el logotipo es propiedad industrial
de un tercero.

## 6. Accesibilidad

Igual que en la skill de Desatascos: `prefers-reduced-motion` respetado
siempre (crítico aquí porque la animación insignia en 3D es la más pesada de
toda la skill — ver guardarraíles en `04-guion-animaciones-scroll.md`), `alt`
descriptivo en todas las imágenes (ver `05-banco-imagenes-gratuitas.md`),
contraste suficiente con los colores de marca configurables, foco visible en
elementos interactivos.
