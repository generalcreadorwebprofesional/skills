# 01 · Sitemap y arquitectura de páginas

## 1. Páginas fijas

| Página | URL | Intención de búsqueda que cubre | Contenido mínimo obligatorio |
|---|---|---|---|
| Home | `/` | Marca + "taller de motos [zona]", "reparación de motos" | H1 único, resumen scrollable de servicios, zonas, por qué elegirnos, testimonios, FAQ, CTA final. Ver `04-guion-animaciones-scroll.md` |
| Sobre nosotros | `/sobre-nosotros` | Confianza/experiencia (E-E-A-T) | Historia, mecánicos/equipo, marcas con las que se trabaja, taller registrado y gestión de residuos conforme a normativa (ver `09-legal-cumplimiento.md`) |
| Índice de servicios | `/servicios` | "servicios de un taller de motos" | Listado de todos los `Service` |
| Ficha de servicio | `/servicios/{servicio:slug}` | "cambio de aceite moto", "reparación de motor moto"... | Descripción, proceso, precio orientativo/presupuesto, zonas donde se presta, FAQ, CTA, galería de imágenes del servicio (ver `05-banco-imagenes-gratuitas.md`) |
| Asistencia en carretera | `/asistencia-en-carretera` | "moto averiada", "grúa moto urgente", máxima intención comercial | Landing de alta urgencia: tiempo de respuesta, teléfono directo, qué hacer mientras llega el técnico |
| Índice de zonas | `/zonas-de-servicio` | "¿trabajáis en mi pueblo?" | Mapa + listado de `ServiceArea` |
| Ficha de zona | `/zonas-de-servicio/{zona:slug}` | "taller de motos en El Vendrell", "mecánico de motos Calafell"... | Contenido único por población (ver nota anti-duplicados) |
| Trabajos realizados | `/trabajos-realizados` | Prueba social visual, E-E-A-T | Galería antes/después de motos reparadas, por servicio y zona |
| Opiniones | `/opiniones` | Confianza | Listado completo de `Testimonial` con `AggregateRating` |
| Blog / consejos | `/blog` | Búsquedas informativas | Índice de `Post` |
| Artículo de blog | `/blog/{post:slug}` | "cada cuánto cambiar el aceite de la moto", etc. | Ver ideas en `02-seo-estrategia-keywords.md` |
| Preguntas frecuentes | `/preguntas-frecuentes` | Dudas pre-compra | Acordeón con `FAQPage` schema |
| Solicitar presupuesto | `/presupuesto` | Conversión (no urgente) | Formulario corto (nombre, teléfono, modelo de moto, servicio, mensaje) |
| Contacto | `/contacto` | Conversión + NAP | Teléfono, WhatsApp, email, dirección, horario, mapa embebido |
| Marcas con las que trabajamos | `/marcas` (opcional) | "taller [marca] moto" (Honda, Yamaha, Kawasaki...) | Listado de marcas con las que el taller tiene experiencia — ver nota legal sobre uso de logos de terceros |
| Trabaja con nosotros | `/trabaja-con-nosotros` (opcional) | Captación de personal | Formulario simple |
| Aviso legal / Privacidad / Cookies | `/aviso-legal`, `/politica-de-privacidad`, `/politica-de-cookies` | Obligatorio legal | Ver `09-legal-cumplimiento.md` |
| 404 personalizada | — | UX | Buscador + enlaces a servicios/zonas destacadas + teléfono |

## 2. Páginas técnicas

- `/sitemap.xml`, `/robots.txt`, tabla `redirects` — igual que en la skill de
  Desatascos (ver `07-modelo-datos-laravel.md`).

## 3. Rutas Laravel (patrón)

```php
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/sobre-nosotros', [PageController::class, 'about'])->name('about');
Route::get('/servicios', [ServiceController::class, 'index'])->name('services.index');
Route::get('/servicios/{service:slug}', [ServiceController::class, 'show'])->name('services.show');
Route::get('/zonas-de-servicio', [ServiceAreaController::class, 'index'])->name('areas.index');
Route::get('/zonas-de-servicio/{serviceArea:slug}', [ServiceAreaController::class, 'show'])->name('areas.show');
Route::get('/asistencia-en-carretera', [PageController::class, 'roadsideAssistance'])->name('roadside');
Route::get('/trabajos-realizados', [CaseStudyController::class, 'index'])->name('cases.index');
Route::get('/opiniones', [TestimonialController::class, 'index'])->name('testimonials.index');
Route::get('/blog', [PostController::class, 'index'])->name('blog.index');
Route::get('/blog/{post:slug}', [PostController::class, 'show'])->name('blog.show');
Route::get('/preguntas-frecuentes', [FaqController::class, 'index'])->name('faq.index');
Route::get('/presupuesto', [LeadController::class, 'createQuote'])->name('quote.create');
Route::post('/presupuesto', [LeadController::class, 'storeQuote'])->name('quote.store');
Route::get('/contacto', [LeadController::class, 'createContact'])->name('contact.create');
Route::post('/contacto', [LeadController::class, 'storeContact'])->name('contact.store');
Route::get('/aviso-legal', [LegalController::class, 'show'])->defaults('type', 'aviso-legal')->name('legal.notice');
Route::get('/politica-de-privacidad', [LegalController::class, 'show'])->defaults('type', 'privacidad')->name('legal.privacy');
Route::get('/politica-de-cookies', [LegalController::class, 'show'])->defaults('type', 'cookies')->name('legal.cookies');
```

## 4. Nota importante anti contenido duplicado

Igual que en la skill de Desatascos: no generar automáticamente
`/servicios/{servicio}/{zona}` para todas las combinaciones. Solo para los 2-3
servicios estrella (revisión/mantenimiento, asistencia en carretera, cambio de
neumáticos) en las 3-4 zonas de mayor volumen, y solo con contenido
verdaderamente único por combinación (mín. 250-300 palabras, referencias
reales a esa población). Si no se puede garantizar, mejor no crear la página.

## 5. Enlazado interno mínimo

- Home enlaza a: servicios destacados, zonas destacadas, asistencia en
  carretera, presupuesto, blog, marcas.
- Cada ficha de **servicio** enlaza a: 3-5 zonas donde se presta, FAQ
  relacionadas, 1-2 artículos de blog, CTA de presupuesto.
- Cada ficha de **zona** enlaza a: todos los servicios disponibles ahí,
  testimonios de esa zona, zonas colindantes.
- Cada **artículo de blog** enlaza a 1-2 servicios relacionados.
- Footer: todas las zonas, todos los servicios, las 3 páginas legales,
  contacto y presupuesto.
