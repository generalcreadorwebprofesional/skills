# 14 · Planes de suscripción / membresías

## 1. Por qué un plan de pago (y no acceso libre a pujar)

Cobrar una suscripción para poder pujar cumple dos funciones a la vez:
económica (ingreso recurrente) y de **calidad/seguridad** (filtra a
curiosos y reduce pujas falsas o abandono de lotes ganados — ver
`12-sistema-subastas-en-vivo.md`, apartado 3).

## 2. Estructura de planes propuesta (editable en `SubscriptionPlanResource`)

| Plan | Precio orientativo/mes | Incluye |
|---|---|---|
| **Visitante** (gratis) | 0 € | Ver catálogo y sesiones en directo sin pujar, recibir alertas de nuevos lotes |
| **Particular** | ~9,99 €/mes | Pujar en subastas (con verificación de identidad y medio de pago), publicar hasta N anuncios en el marketplace |
| **Profesional** | ~29,99 €/mes | Todo lo del plan Particular + publicar stock ilimitado, estadísticas de sus anuncios, acceso a subastas exclusivas para profesionales, facturación con NIF de empresa |
| **Profesional Plus** | ~79,99 €/mes | Todo lo anterior + comisión reducida en ventas cerradas a través de la plataforma, prioridad de soporte, varios usuarios por cuenta de empresa |

Los precios y nombres son orientativos — el propio `SubscriptionPlanResource`
permite crear, renombrar o eliminar planes libremente, incluidos planes
anuales con descuento.

## 3. Implementación técnica

- **Paquete recomendado**: `laravel/cashier` (Stripe) — gestiona
  suscripciones recurrentes, periodos de prueba, cambios de plan, facturas y
  webhooks de pago de forma robusta sin reinventar la lógica de cobro
  recurrente.
- Alternativa si se prioriza una pasarela española/europea con más presencia
  local: Redsys o GoCardless (domiciliación SEPA) — cualquiera de las dos
  requiere más trabajo de integración manual que Cashier+Stripe.
- Webhooks obligatorios a implementar: pago recibido, pago fallido,
  suscripción cancelada, tarjeta a punto de caducar — cada uno debe
  reflejarse en el estado del usuario (p. ej., si el pago falla, degradar
  automáticamente a "Visitante" tras el periodo de gracia configurado, nunca
  dejar a alguien pujando sin plan activo).
- El middleware de acceso a pujar comprueba `auth()->user()->subscribed('plan-pujas')`
  (o el scope equivalente de Cashier) **además** de la comprobación de rol —
  son dos capas independientes (rol = qué tipo de usuario eres; plan = si
  tienes acceso pagado activo).

## 4. Aspectos legales del cobro recurrente (España/UE)

- Información precontractual clara sobre el precio, periodicidad y
  renovación automática **antes** de la contratación (obligatorio bajo la
  Directiva 2011/83/UE y el Real Decreto-ley que traspuso la Directiva Ómnibus
  2019/2161 sobre transparencia en renovaciones automáticas).
- Debe ser **igual de fácil cancelar** la suscripción que contratarla — la
  normativa europea reciente (y ya varias leyes nacionales de transposición)
  exige que la cancelación esté accesible en un número de pasos razonable
  desde el área privada, no oculta tras contactar por email/teléfono.
- Recordatorio antes de cada renovación si el plan es anual (buena práctica,
  y obligatorio en algunos países de la UE).
- Factura automática por cada cobro, con IVA correspondiente al país del
  suscriptor si es un servicio digital B2C (reglas de IVA de servicios
  electrónicos/digitales — ver nota en
  `16-expansion-internacional-paises-legal-fiscal.md`, que puede requerir
  registro en el régimen de Ventanilla Única (OSS) si se factura a
  consumidores de varios países de la UE).

## 5. Panel de administración — recursos nuevos

- `SubscriptionPlanResource`: crear/editar planes, precios, qué permisos
  desbloquea cada uno.
- `SubscriberResource` (o pestaña dentro de `UserResource`): estado de la
  suscripción de cada usuario, historial de pagos, acción manual de
  "conceder acceso temporal" (para pruebas o gestos comerciales) con
  registro de quién y por qué lo concedió.
- Widget de dashboard: ingresos recurrentes mensuales (MRR), tasa de bajas
  (churn) del último mes, plan más contratado.
