# 06 · Panel de administración (Filament)

Mismo principio que en la skill de Desatascos: si algo se ve en la web, se
edita aquí. Se detallan solo las diferencias respecto al taller de motos; la
mecánica general (Resources, Settings singleton, etc.) es la misma.

## 1. Ajustes del taller — `CompanySetting` (página singleton)

Igual que en la skill de Desatascos (identidad, contacto, horario, redes,
legal, marca/tema visual, SEO, integraciones, métricas del home), con estos
campos adicionales propios del sector:

| Campo nuevo | Uso |
|---|---|
| `brands_worked_with` | Texto libre o repeater de marcas de moto con las que se trabaja (solo texto, ver nota legal sobre logos en `02-seo-estrategia-keywords.md`) |
| `roadside_assistance_radius_km` | Radio de acción para asistencia en carretera, mostrado en `/asistencia-en-carretera` |
| `animations_3d_enabled` | Toggle específico para activar/desactivar el **Nivel Full** (3D) de la animación insignia sin tocar `animations_enabled` general — permite mantener el resto de animaciones pero apagar el 3D si el hosting no aguanta bien la carga del modelo |
| `industrial_registry_number` | Nº de inscripción en el Registro Industrial (para mostrar como sello de confianza en "Sobre nosotros", ver `09-legal-cumplimiento.md`) |

## 2. Servicios — `ServiceResource`

Igual estructura que en la skill de Desatascos
(`name`, `slug`, `icon`, `featured_image`, `short_description`,
`description`, `is_featured`, `order`, SEO, `published`), con:

| Campo nuevo | Uso |
|---|---|
| `is_emergency` | Ahora significa "aparece en `/asistencia-en-carretera`" |
| `vehicle_type` | Enum: `moto`, `scooter`, `quad`, `otros` — permite filtrar/organizar servicios si el taller amplía a más tipos de vehículo |
| `image_credit` (en el modelo de medios, no en el servicio directamente) | Crédito opcional del banco de imágenes/modelo 3D usado, ver `05-banco-imagenes-gratuitas.md` |

## 3. Zonas de servicio — `ServiceAreaResource`

Idéntico a la skill de Desatascos (`name`, `slug`, `comarca`, `province`,
`lat`, `lng`, `description`, `is_headquarters`, `is_featured`, `order`, SEO).

## 4. Testimonios, Blog, FAQ, Leads, Páginas legales, Redirecciones, Usuarios

Estructura idéntica a la skill de Desatascos (`05-panel-administracion.md` de
aquella skill), sin cambios funcionales — solo cambia el copy de ejemplo que
se les carga (ver `assets/seed-data-taller-rpm.md`).

## 5. Nuevo: gestor de imágenes/medios con crédito y licencia

Ampliar el `MediaLibrary` de Filament (o crear un pequeño `MediaResource` de
apoyo) para que cada imagen subida tenga, además de los campos estándar:

- `alt_text` (obligatorio en el formulario, con validación — no dejar subir
  una imagen sin texto alternativo).
- `source` (select: "Foto propia del taller" / "Banco de imágenes gratuito" /
  "Modelo 3D") — puramente informativo para quien gestione el contenido.
- `image_credit` (opcional, texto libre) — se muestra automáticamente en un
  pequeño crédito discreto si el banco de origen lo requiere (ver
  `05-banco-imagenes-gratuitas.md`, caso de modelos CC-BY de Sketchfab).

## 6. Nuevo: control de la animación insignia

Dentro de `CompanySetting` (o como página de configuración aparte si se
prefiere no sobrecargar el formulario principal):

- `animations_3d_enabled` (ver apartado 1).
- `hero_moto_model_path` (nullable) — ruta al archivo `.glb` subido si se usa
  el Nivel Full; si está vacío, el frontend cae automáticamente al Nivel Lite
  en SVG sin que nadie tenga que tocar código.
- `hero_moto_poster_image` — imagen estática (WebP) usada como `poster` del
  `<model-viewer>` mientras carga el modelo 3D.

Con estos tres campos, activar o desactivar la animación insignia en 3D es
una tarea 100% de admin, sin despliegue de código — coherente con el
principio de "todo editable" de toda la skill.

## 7. Dashboard

Igual que en la skill de Desatascos: leads nuevos, gráfico semanal, últimos
leads sin contactar, servicios/zonas publicados vs. borrador.
