# 10 · Checklist de lanzamiento SEO técnico

Base idéntica a la skill de Desatascos, con 2 bloques nuevos (imágenes/3D y
obligaciones del taller). No dar el proyecto por terminado sin repasar todo.

## Rastreo e indexación
- [ ] `sitemap.xml` con todas las páginas publicadas, sin 404 ni borradores.
- [ ] `robots.txt` permite el rastreo salvo `/admin`.
- [ ] Sitemap enviado a Google Search Console y Bing Webmaster Tools.
- [ ] Canonical único por página, un solo dominio indexable.
- [ ] Página 404 personalizada con código HTTP 404 real.

## Metadatos
- [ ] `<title>` y meta description únicos por página.
- [ ] Open Graph/Twitter Card en páginas relevantes.
- [ ] Favicon configurado desde `CompanySetting`.

## Encabezados y contenido
- [ ] 1 solo `<h1>` por página, jerarquía sin saltos.
- [ ] Ninguna ficha de zona con texto duplicado de otra.
- [ ] Ninguna afirmación publicitaria absoluta no verificable.

## Datos estructurados
- [ ] `LocalBusiness`/`AutomotiveBusiness` en home/contacto validado.
- [ ] `Service` en cada ficha de servicio.
- [ ] `FAQPage`, `BreadcrumbList`, `AggregateRating` (solo con datos reales).

## Imágenes y animación insignia (nuevo respecto a Desatascos)
- [ ] **Toda** imagen subida tiene `alt_text` relleno y licencia verificada
      (ver `05-banco-imagenes-gratuitas.md`) — ninguna proviene de una
      búsqueda de Google Imágenes sin comprobar su licencia.
- [ ] Si se usa un modelo 3D (Nivel Full), su licencia está verificada
      (Standard/CC0, o CC-BY con crédito visible añadido en la web).
- [ ] El `.glb` del modelo 3D está optimizado en peso y solo se activa en
      escritorio (`animations_3d_enabled` + comprobación de ancho de
      pantalla, ver `04-guion-animaciones-scroll.md`).
- [ ] Existe siempre un fallback funcional (Nivel Lite en SVG) si el modelo
      3D no carga o el dispositivo no cumple los requisitos.
- [ ] La animación insignia respeta `prefers-reduced-motion` igual que el
      resto de animaciones.

## Rendimiento (Core Web Vitals)
- [ ] Imágenes en WebP/AVIF, `loading="lazy"` salvo la del hero.
- [ ] El bundle 3D (si activo) no bloquea el LCP del hero ni carga en móvil.
- [ ] GSAP/ScrollTrigger/MotionPath cargados vía Vite, sin bloquear el
      render inicial.
- [ ] Cache de rutas/vistas/config activa en producción.
- [ ] Test en PageSpeed Insights / Lighthouse en verde (o cerca) en móvil y
      escritorio **con y sin** el Nivel Full 3D activado.

## SEO local
- [ ] NAP idéntico entre web, schema y Google Business Profile.
- [ ] Todas las `ServiceArea` reales publicadas con descripción propia.
- [ ] Teléfono clicable (`tel:`) y WhatsApp en todas las páginas.
- [ ] Ningún logotipo de marca de moto de terceros usado sin autorización.

## Legal
- [ ] Las 3 páginas legales con datos reales, enlazadas desde el footer.
- [ ] Banner de cookies conforme (3 botones al mismo nivel, sin dark patterns).
- [ ] Casilla de privacidad en formularios, validada en backend.
- [ ] Bloque de "Compromiso ambiental y normativo" en `/sobre-nosotros` con
      los datos reales del taller (Registro Industrial, gestión de residuos)
      — ver `09-legal-cumplimiento.md`, apartado 4.

## Accesibilidad y UX
- [ ] `prefers-reduced-motion: reduce` respetado en todas las animaciones,
      incluida la insignia.
- [ ] Botón de llamada/WhatsApp visible en móvil tras el hero.
- [ ] Contraste de texto suficiente con los colores de marca configurados.

## Analítica y medición
- [ ] GA4/Search Console verificados con los IDs de `CompanySetting`.
- [ ] Evento de conversión en clic de llamada/WhatsApp y envío de formulario.
