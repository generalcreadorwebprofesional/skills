# 02 · Estrategia SEO y palabras clave

## 1. Tres tipos de intención

| Tipo | Ejemplo | Página que debe posicionar | Objetivo |
|---|---|---|---|
| **Urgente** | "moto averiada El Vendrell", "grúa moto urgente" | `/asistencia-en-carretera`, home, ficha de zona | Llamada inmediata |
| **Servicio** | "cambio de aceite moto", "taller de motos", "reparación motor moto" | `/servicios`, ficha de servicio, ficha de zona | Presupuesto o llamada |
| **Informativa** | "cada cuánto cambiar aceite moto", "cómo preparar la moto para la itv" | `/blog/{post}` | Tráfico top-of-funnel + autoridad temática |

## 2. Clusters de palabras clave

### Cluster A — Marca + genéricas de conversión
- taller de motos [nombre del taller]
- reparación de motos
- mecánico de motos
- taller de motos barato / económico
- taller de motos cerca de mí
- taller de motos y scooters

### Cluster B — Por tipo de servicio (una ficha `Service` por cada uno)
- cambio de aceite y filtros moto
- reparación de motor de moto
- diagnosis electrónica / avería eléctrica moto
- cambio de neumáticos y equilibrado moto
- revisión y cambio de frenos moto
- cadena y kit de arrastre / transmisión moto
- chapa y pintura de motos / carenados
- preparación pre-ITV moto
- asistencia en carretera / rescate de motos
- reparación de scooters y quads (categoría "otros vehículos")

### Cluster C — Local (nombre de población + palabra genérica)
Para cada `ServiceArea` (lista completa en `assets/seed-data-taller-rpm.md`):
- taller de motos + [población] (*taller de motos El Vendrell*, *taller de motos Calafell*)
- mecánico de motos + [población]
- reparación de motos + [población]
- taller de motos + [comarca] (*taller de motos Baix Penedès*)
- asistencia en carretera moto + [población]

### Cluster D — Informativas para el blog

1. "¿Cada cuánto hay que cambiar el aceite de la moto?" → *cambio de aceite moto cada cuánto*
2. "Cómo preparar tu moto para pasar la ITV a la primera" → *pre itv moto*
3. "Señales de que tu moto necesita una revisión de frenos" → *frenos moto revisión*
4. "Cadena de la moto: cuándo engrasar, tensar o cambiar el kit de arrastre" → *kit de arrastre moto*
5. "Qué hacer si tu moto se avería en carretera" → *moto averiada qué hacer*
6. "Cómo saber si la batería de tu moto está agotada" → *batería moto agotada síntomas*
7. "Mantenimiento de la moto en invierno: guía práctica" → *mantenimiento moto invierno*
8. "Ruidos raros en el motor de la moto: qué pueden significar" → *ruido motor moto*
9. "Diferencias entre revisión básica y puesta a punto completa" → enlace interno hacia servicios
10. "Scooter vs moto: mantenimiento y averías más comunes" → *mantenimiento scooter*

## 3. Plantillas de metadatos

| Tipo de página | `<title>` (≤60 car.) | Meta description (≤155 car.) |
|---|---|---|
| Home | `{{taller}} · Taller de motos en {{zona_principal}} y alrededores` | `Reparación y mantenimiento de motos en {{zona_principal}} y {{comarca}}. Presupuesto claro, mecánicos propios. Llama ahora.` |
| Servicio | `{{servicio}} en {{zona_principal}} · {{taller}}` | `{{servicio}} para tu moto en {{zona_principal}} y alrededores. Diagnóstico honesto y presupuesto cerrado. Llama al {{telefono}}.` |
| Zona | `Taller de motos en {{zona}} · {{taller}}` | `Reparación y mantenimiento de motos en {{zona}}: revisiones, frenos, neumáticos y asistencia en carretera.` |
| Asistencia en carretera | `Asistencia en carretera para motos en {{zona_principal}} · {{taller}}` | `¿Tu moto se ha averiado? Te ayudamos en {{zona_principal}} y alrededores. Llama directamente, sin esperas.` |
| Blog | `{{titulo_post}} · Blog de {{taller}}` | `{{extracto_post}}` |

Reglas: meta description única por página, canonical propia por URL, dominio
único indexable (`www` o sin `www`, nunca ambos).

## 4. Datos estructurados (schema.org)

| Página | Schema principal | Notas |
|---|---|---|
| Home / Contacto | `LocalBusiness` (subtipo `AutomotiveBusiness` / `MotorcycleRepair` si el buscador lo soporta, o `LocalBusiness` + `additionalType`) | `name`, `telephone`, `address`, `geo`, `openingHoursSpecification`, `areaServed`, `image`, `priceRange` |
| Ficha de servicio | `Service` | `serviceType`, `areaServed`, `provider` |
| Ficha de zona | `LocalBusiness`/`Service` acotado a esa población | Contenido único, no duplicar el bloque del home |
| FAQ | `FAQPage` | Un `Question`/`acceptedAnswer` por FAQ mostrada |
| Todas las páginas de contenido | `BreadcrumbList` | Refleja la ruta de navegación |
| Opiniones (con rating real) | `AggregateRating` dentro de `LocalBusiness` | Nunca inventar valoraciones |
| Blog post | `Article`/`BlogPosting` | `datePublished`, `author`, `image` |

## 5. SEO local

- NAP idéntico entre la web, el schema `LocalBusiness` y Google Business
  Profile (categoría: "Taller de motocicletas" / "Motorcycle repair shop").
- Reseñas: enlazar `/opiniones` al perfil real de Google.
- Mapa embebido en `/contacto` y en cada ficha de zona.
- Nota sobre marcas: si el taller trabaja con motos de marcas concretas
  (Honda, Yamaha, Kawasaki, etc.), se puede mencionar textualmente
  ("especialistas en Honda y Yamaha"), pero **no usar los logotipos oficiales
  de esas marcas sin autorización** — son propiedad industrial de terceros.
  Usar solo el nombre en texto plano o iconografía genérica propia.

## 6. Rendimiento como factor SEO

- Imágenes en WebP/AVIF, lazy-load salvo la del hero (ver `05-banco-imagenes-gratuitas.md`).
- El bundle 3D (si se activa el nivel avanzado de la animación insignia, ver
  `04-guion-animaciones-scroll.md`) se carga de forma diferida y nunca bloquea
  el primer render ni el LCP (Largest Contentful Paint) del hero.
- GSAP/ScrollTrigger cargado vía Vite, sin bloquear el render inicial.
- Cache de vistas/rutas/config en producción.
