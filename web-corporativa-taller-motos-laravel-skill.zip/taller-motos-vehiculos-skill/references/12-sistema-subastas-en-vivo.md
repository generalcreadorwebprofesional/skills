# 12 · Sistema de subastas en vivo en tiempo real

## 0. Qué hacen hoy las plataformas de referencia (y qué vamos a hacer distinto)

| Plataforma | Qué hace bien | Qué le falta / qué evitamos |
|---|---|---|
| **Copart / IAAI** | Volumen altísimo, pujadores profesionales verificados, sistema de pujas robusto (proxy bidding) | Interfaz funcional pero fría, cero componente de comunidad/espectáculo, pensada para B2B |
| **Cars & Bids** | Extensión de tiempo anti-sniping, comentarios en vivo durante la puja (genera FOMO real), fichas de vehículo muy cuidadas | Sin sonido/ambientación, sin "efecto subasta" visual, auciones "un lote a la vez" en cola larga (7 días) |
| **Bring a Trailer** | Comunidad muy activa, insignias "reserva"/"sin reserva" claras, alto engagement por comentarios | Igual que arriba: sin tiempo real "de evento", cada lote corre su propio reloj independiente |
| **Barrett-Jackson** | Espectáculo total: sonido de martillo, locutor, ambiente de sala — genera adrenalina real | Modelo de retransmisión de TV/vídeo en directo — carísimo de replicar en una web propia |
| **Car & Classic** | Regla de extensión de +3 min ante puja de última hora, simple y efectiva | Sin componente social/comunidad, sin sesiones programadas tipo evento |
| **OPENLANE / ADESA** | Múltiples subastas simultáneas muy eficientes para concesionarios | Cero orientación a consumidor final, nula narrativa/emoción |

**Nuestra propuesta**: la sensación de espectáculo de Barrett-Jackson (sonido,
efectos de "vendido", tensión de cuenta atrás) + la mecánica justa de Cars &
Bids/Car & Classic (extensión anti-sniping, reserva oculta pero visible su
estado) + la eficiencia de Copart/OPENLANE (verificación previa,
compradores cualificados) — **sin el coste de retransmitir vídeo en directo**,
que es lo que de verdad encarece y ralentiza este tipo de plataformas. "En
vivo" aquí significa **interacción en tiempo real real** (pujas, contador,
sonido, espectadores conectados), no necesariamente una cámara encendida todo
el rato — es más barato, más rápido de cargar y, bien ejecutado, se percibe
igual de "en directo".

## 1. Arquitectura técnica (tiempo real, barata y rápida)

- **Laravel Reverb** (servidor WebSocket de primera parte, gratuito y
  autoalojado — sin coste por mensaje como Pusher) + **Laravel Echo** en el
  frontend.
- Canales **por lote**, no un canal global: `presence-lot.{id}` para saber
  cuánta gente está viendo ese lote en ese momento (contador social "328
  personas viendo"), y eventos de dominio (`NewBid`, `AuctionExtended`,
  `LotSold`, `LotUnsold`, `AuctionStarted`) emitidos solo a quien está
  suscrito a ese lote — así no se satura a nadie con tráfico de lotes que no
  está mirando.
- Payloads mínimos: cada evento de puja envía solo `{amount, bidder_alias,
  bid_count, timestamp}`, nunca el objeto completo del lote — el cliente
  actualiza el DOM de forma incremental (un `<span>` de importe, no re-render
  de toda la tarjeta).
- Medios pesados fuera de nuestro servidor: fotos en WebP/AVIF servidas desde
  el propio storage con conversiones de `spatie/laravel-medialibrary`; si se
  quiere vídeo de presentación de un lote o del presentador en directo,
  **insertarlo como embed de YouTube (en directo o no listado)** en lugar de
  montar streaming propio — YouTube absorbe todo el coste de ancho de banda,
  nosotros solo mostramos el iframe.
- La ambientación 3D/visual "de sala de subastas" (foco de luz, plataforma,
  confeti) se carga **una sola vez por sesión** y se cachea en el navegador —
  nunca se genera un asset pesado nuevo por cada lote (ver apartado 4).
- Cache de las páginas de solo lectura que cambian poco (catálogo, próximas
  sesiones) con el cache de respuestas de Laravel; la página del lote en
  directo nunca se cachea (es la única parte realmente dinámica).
- Limitar (`throttle`) las peticiones de puja por usuario en el servidor para
  evitar spam de pujas automatizado.
- Escalado: si el número de espectadores concurrentes crece mucho, Reverb
  soporta escalado horizontal vía Redis pub/sub entre varias instancias — no
  hace falta planteárselo hasta que el tráfico real lo justifique (evitar
  sobre-ingeniería en el lanzamiento).

## 2. Calendario de sesiones: 2 veces por semana, en el horario de más audiencia

**Recomendación de partida** (a validar con datos reales una vez en marcha,
no como verdad absoluta): **martes y jueves, de 20:30 a 22:30 (hora de
España peninsular, CET/CEST)**.

Razonamiento:
- Evitamos el lunes (día de "vuelta a la rutina", menor consumo de ocio
  online) y el viernes/sábado noche (plena competencia con planes sociales
  presenciales).
- Después de la cena entre semana es la franja de mayor consumo de
  contenido de ocio/entretenimiento online en España, similar a por qué
  gran parte del prime time televisivo empieza igualmente en esa franja.
- Mantener siempre el **mismo día y hora cada semana** (rutina reconocible,
  como una "cita semanal") es más valioso a largo plazo que optimizar cada
  sesión de forma distinta — es lo que hacen los mejores formatos de "live
  commerce" y de eventos recurrentes (predictibilidad = hábito).
- Al expandirse a otros países, ojo con el huso horario: 20:30 en España
  peninsular es 19:30 en Portugal/Reino Unido — si el público de esos
  mercados crece, valorar una segunda franja o mantener la hora CET como
  "hora de referencia europea" indicándolo claramente en cada país.

**Cómo verificarlo con datos reales** (no os quedéis solo con esta
recomendación):
1. Desde el lanzamiento, registrar en `auction_sessions` la métrica de
   espectadores simultáneos máximos y el nº de pujas por franja horaria.
2. Usar el contador de presencia (`presence-lot`) y Google Analytics 4 (hora
   del día con más usuarios activos) para contrastar la hipótesis.
3. Probar A/B durante 4-6 semanas moviendo una de las dos sesiones (por
   ejemplo, jueves a domingo por la tarde) y comparar resultados antes de
   fijarlo definitivamente.

## 3. Mecánica de la puja (justicia y anti-sniping)

- **Incrementos mínimos por tramo de precio** (tabla editable en admin):
  ejemplo, pujas <1.000€ suben de 25 en 25; 1.000-5.000€ de 50 en 50;
  >5.000€ de 100 en 100.
- **Extensión anti-sniping** (como Car & Classic): si llega una puja válida
  en los últimos **3 minutos**, el cronómetro del lote se amplía
  automáticamente 3 minutos más, y así sucesivamente hasta que nadie vuelva a
  pujar en ese margen — evita que quien puja en el último segundo se lleve el
  lote sin dar opción de respuesta a los demás.
- **Reserva oculta pero con estado visible**: el vendedor puede fijar un
  precio de reserva no público; el lote muestra un badge dinámico
  "Reserva no alcanzada" / "¡Reserva alcanzada!" en cuanto la puja la supera
  — transparencia sin desvelar la cifra exacta (igual que Bring a Trailer /
  Cars & Bids).
- **Verificación previa para pujar** (KYC ligero): solo puede pujar quien
  tiene una cuenta verificada (identidad + medio de pago asociado) y un plan
  activo (ver `14-planes-suscripcion-membresias.md`) — reduce pujas falsas y
  abandono de lotes ganados.
- **El vendedor no puede pujar en su propio lote** (comprobación en servidor
  `seller_id !== bidder_id`), y el sistema registra alertas si detecta
  patrones sospechosos (mismo método de pago o misma IP pujando contra el
  vendedor) para revisión manual por `oficina`/`admin` — sin automatizar
  ninguna sanción, solo marcar para revisión humana.
- **Registro inmutable de cada puja** (`bid_logs`) con IP, user agent y
  timestamp, para poder resolver disputas o reclamaciones después.

## 4. Sonido y ambientación (guion de efectos)

Ver `assets/sonidos-gratuitos-subasta.md` para las fuentes concretas y
licencias. Resumen de qué sonido/efecto corresponde a cada evento:

| Evento | Sonido | Efecto visual |
|---|---|---|
| Inicio de sesión | Fanfarria corta/ambiente de "sala llenándose" | Fade-in del stage 3D/2D de la sala, conteo de espectadores conectándose |
| Nueva puja | "Ping"/golpe corto y seco (no repetitivo) | El importe actual hace un pequeño "pop" de escala + el bloque de "última puja" se desliza con la puja nueva |
| Reserva alcanzada | Campanada suave, una sola vez por lote | El badge cambia de gris a verde con una transición de color |
| Extensión de tiempo (anti-sniping) | Sonido de "alerta" breve, distinto al de puja normal | El anillo del cronómetro pulsa/brilla y el número de tiempo restante hace un salto visible |
| Últimos 10 segundos | Tictac acelerado (solo si el usuario tiene el sonido activado) | Borde del lote en rojo pulsante |
| Lote vendido | Golpe de martillo de subastador ("mazo") | Sello "VENDIDO" que entra con rotación/escala tipo sello de goma + confeti ligero (CSS/canvas, no 3D) |
| Lote sin venta (reserva no alcanzada) | Tono neutro/apagado, nada triunfal | Sello "Reserva no alcanzada" en gris, sin confeti, con CTA "Contactar con el vendedor" |
| Cierre de sesión completa | Música de cierre breve | Resumen de la sesión (lotes vendidos, importe total, mejor puja) |

**Reglas técnicas de sonido, no negociables:**
- Todo sonido **empieza muteado por defecto** y requiere un toggle explícito
  del usuario para activarse — los navegadores bloquean el autoplay de audio
  con sonido sin interacción del usuario, así que forzarlo no funcionaría de
  todos modos, y respeta a quien está en un sitio público.
- Anti-spam de sonido: si llegan varias pujas en menos de 1-2 segundos
  (lote muy disputado), no se solapan sonidos — se reproduce como máximo uno
  cada X milisegundos (debounce), o se sustituye por un sonido "ráfaga"
  específico para pujas muy rápidas.
- Accesibilidad: cada evento también se anuncia en una región
  `aria-live="polite"` para usuarios de lector de pantalla ("Nueva puja: 4.250
  euros"), no solo mediante sonido/color.

## 5. Animación y 3D — el mismo criterio "ligero por defecto" que en el hero

Reutilizamos el patrón de `04-guion-animaciones-scroll.md` (Nivel Lite/Nivel
Full), aplicado ahora a la sala de subastas:

- **Nivel Lite (por defecto, todos los dispositivos)**: la "sala" es una
  ilustración 2D/CSS (gradientes, un foco de luz con `box-shadow`/`filter`,
  un podio) — se carga una vez, pesa poquísimo, funciona en cualquier móvil.
  El "sello de vendido" es una animación CSS (`transform: scale + rotate`)
  sobre una imagen SVG del sello, no un modelo 3D.
- **Nivel Full (opcional, solo escritorio potente, activable por sesión
  desde el admin)**: un elemento 3D **reutilizado en todas las sesiones**
  (por ejemplo, un trofeo o un mazo de subastador girando lentamente de
  fondo con `<model-viewer>`), cargado una sola vez y cacheado — nunca un
  modelo 3D distinto por cada lote, eso sí sería carísimo de cargar y de
  mantener.
- El **vehículo del lote en sí** se muestra con fotos de alta calidad
  (galería) y, si el vendedor lo aporta, un giro de 360° pregenerado (una
  secuencia de imágenes, no un modelo 3D real-time) — mucho más barato de
  producir y de servir que un modelo 3D por vehículo, y visualmente muy
  efectivo para coches.

## 6. Estados de una sesión y de un lote (máquina de estados)

**Sesión de subasta** (`auction_sessions.status`):
`programada` → `en_directo` → `finalizada`

**Lote** (`auction_lots.status`):
`programado` → `en_puja` → `vendido` | `sin_venta` → `liquidado` (cuando se
completa el pago/transferencia de titularidad)

Cada transición dispara el evento de broadcasting correspondiente (apartado
1) y, cuando aplica, el efecto de sonido/animación del apartado 4. Nunca se
cambia de estado directamente desde el frontend: todas las transiciones las
valida el backend (p. ej., no se puede marcar "vendido" un lote cuya reserva
no se ha alcanzado, salvo decisión manual explícita del vendedor/`oficina`).

## 7. Panel de administración — recursos nuevos

- `AuctionSessionResource`: crear/programar sesiones (fecha, hora, lotes
  incluidos, nivel de animación 3D activado/desactivado).
- `AuctionLotResource`: alta de lote (vehículo del marketplace convertido en
  lote), precio de salida, reserva (oculta), incrementos aplicables.
- `BidResource` (solo lectura + acciones de anulación manual con motivo, para
  casos de fraude detectado).
- Widget de dashboard en directo: espectadores conectados ahora mismo,
  pujas en la última hora, lote más disputado.

## 8. Métricas a vigilar desde el primer día

- Espectadores simultáneos por sesión (pico y media).
- Tasa de conversión espectador → pujador registrado.
- Nº medio de pujas por lote y "lotes con extensión anti-sniping" (indicador
  de interés real).
- Abandono de pago tras ganar un lote (para ajustar el KYC/depósito previo si
  es alto).
