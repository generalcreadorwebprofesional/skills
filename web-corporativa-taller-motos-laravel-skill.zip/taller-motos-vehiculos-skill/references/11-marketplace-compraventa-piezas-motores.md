# 11 · Marketplace de compraventa (vehículos y piezas/motores)

Sistema de anuncios tipo "clasificados + ficha de producto", separado del
sistema de subastas (`12-sistema-subastas-en-vivo.md`) aunque comparte
catálogo de vehículos y piezas: un mismo vehículo puede estar "en venta
directa" o "en subasta", nunca en ambos estados a la vez.

## 1. Dos catálogos distintos

### A) Vehículos (`vehicle_listings`)

- Publicados por: `oficina` (vehículos de la propia empresa/depósito),
  `comercial` (vehículos en gestión de un agente comercial),
  `cliente_profesional` (concesionarios/gestorías que publican su stock),
  y opcionalmente `cliente_particular` (venta entre particulares moderada).
- Ficha de vehículo: marca, modelo, versión, año, kilometraje, VIN/bastidor,
  cilindrada, potencia, combustible, transmisión, color, nº de propietarios,
  historial de mantenimiento (si se aporta), informe de videoinspección/
  fotos (mín. 12 fotos + 1 vídeo recomendado), estado (nuevo/seminuevo/usado/
  para piezas/accidentado), precio, ubicación (país + ciudad), gastos de
  transporte estimados si el comprador está en otro país, documentación
  disponible (ficha técnica, ITV/equivalente, informe de kilometraje si
  existe), impuesto aplicable (REBU o régimen general, ver
  `16-expansion-internacional-paises-legal-fiscal.md`).
- Estados: `borrador`, `publicado`, `reservado`, `vendido`, `retirado`.

### B) Piezas y motores (`part_listings`)

- Categoría (motor completo, caja de cambios, embrague, electrónica/
  centralita, carrocería, neumáticos, otros), compatibilidad (marca/modelo/
  años compatibles — selector múltiple), estado (nuevo, reacondicionado,
  usado - funcional, usado - para despiece), nº de referencia del fabricante
  si se conoce, procedencia (vehículo del que se ha desmontado, con enlace al
  `vehicle_listing` de origen si aplica — trazabilidad útil también para
  evitar la venta de piezas de vehículos con antecedentes irregulares),
  garantía ofrecida (días), precio, stock disponible.
- Un motor/pieza puede generar su propio lead de "reserva" o integrarse en un
  carrito simple si el volumen de piezas lo justifica (ver apartado 4).

## 2. Flujo de publicación y moderación

1. El anunciante (según su rol) crea el anuncio en su área privada (ver
   `13-roles-permisos-areas-privadas.md`) → estado `borrador`.
2. Antes de pasar a `publicado`, un rol `oficina` o `admin` revisa: fotos
   mínimas, datos obligatorios completos, coherencia de precio, y —muy
   importante en vehículos— que el VIN no esté ya publicado en otro anuncio
   activo (evita duplicados y anuncios fantasma).
3. Publicado el anuncio, aparece en el buscador público con filtros (marca,
   modelo, rango de precio, año, kilometraje, combustible, país, tipo de
   vendedor) y en el sitemap/SEO como página propia
   (`/vehiculos/{listing:slug}`, `/piezas/{listing:slug}`).
4. Al marcarse `vendido`, el anuncio deja de ser indexable para búsqueda
   activa pero conserva su URL con un aviso "Vendido" (evita 404 y conserva
   el link-juice SEO acumulado) — importante para no perder posicionamiento
   ganado con anuncios de coches muy buscados.

## 3. Contacto y reserva (sin pago en la primera versión)

- Formulario "Me interesa" / "Reservar" → crea un `Lead` (reutilizando el
  modelo de la skill de taller, con `type = 'vehiculo'` o `'pieza'`) visible
  en el área privada del `comercial`/`oficina` asignado.
- Reserva con señal/depósito (opcional, fase avanzada): requiere pasarela de
  pago y, si se retiene dinero de terceros más de unos días, puede
  considerarse una actividad regulada de servicios de pago —ver nota en
  `16-expansion-internacional-paises-legal-fiscal.md` antes de implementar
  cualquier función de "depósito en garantía" (escrow) con fondos de
  terceros.

## 4. Piezas y motores: ¿carrito de compra o solo lead?

Recomendación por fases:

- **Fase 1 (recomendada)**: solo "solicitar disponibilidad/presupuesto"
  (como un lead), sin cobro online — más simple legal y técnicamente, válido
  para validar la demanda real antes de invertir en un checkout completo.
- **Fase 2 (si el volumen lo justifica)**: carrito + checkout con pasarela de
  pago (Stripe/Redsys u otra PSP con presencia en los países activos),
  factura automática, gestión de stock por unidades. En este punto aplican
  las obligaciones estándar de e-commerce (LSSI, derecho de desistimiento de
  14 días salvo excepciones del art. 16, información precontractual,
  garantía legal de conformidad de 3 años en la UE para bienes usados salvo
  reducción pactada a un mínimo de 1 año).

## 5. SEO del marketplace (complementario a `02-seo-estrategia-keywords.md`)

- Cada ficha de vehículo/pieza es una página indexable con datos
  estructurados `Product`/`Vehicle` (schema.org) y `Offer` (precio,
  disponibilidad, moneda).
- Slugs descriptivos: `/vehiculos/yamaha-mt-07-2021-15000km-el-vendrell`,
  no `/vehiculos/1234`.
- Páginas de listado por marca/modelo (`/vehiculos/yamaha`,
  `/vehiculos/yamaha/mt-07`) para capturar búsquedas tipo "yamaha mt-07 de
  segunda mano" — cuidado aquí también con el contenido fino: si una
  combinación marca+modelo tiene 0-1 anuncios, mejor no crear la página
  indexable todavía (mismo criterio anti-thin-content que en
  `01-sitemap-arquitectura.md`).

## 6. Panel de administración — recursos nuevos en Filament

- `VehicleListingResource`: gestión completa, cambio de estado, asignación a
  comercial, historial de cambios de precio.
- `PartListingResource`: gestión de piezas/motores, con relación al vehículo
  de procedencia si existe.
- Widget de dashboard: "Vehículos publicados vs. vendidos (últimos 30 días)",
  "Piezas con más solicitudes".
