# 04 · Guion de animaciones de scroll (versión "al máximo") + animación insignia

Este documento lleva el guion de scroll storytelling un nivel por encima de lo
estándar: además de las escenas de venta, incluye una **animación insignia**
—un elemento (la moto) que recorre físicamente la pantalla desde el hero hasta
la mitad de la siguiente sección— pensada para que, sin leer una sola palabra,
cualquiera entienda en 3 segundos "esto es un taller de motos". Todo el texto
es contenido de ejemplo de "Taller RPM", editable desde `CompanySetting` /
`Service` en producción.

## 0. Base técnica común (ampliada)

- Librerías: `gsap`, `gsap/ScrollTrigger`, `gsap/MotionPathPlugin`,
  `gsap/SplitText`, `gsap/Draggable` (todas gratis desde 2025, incluido uso
  comercial) + `lenis` para scroll con inercia.
- `gsap.registerPlugin(ScrollTrigger, MotionPathPlugin, SplitText, Draggable)`
- Accesibilidad (idéntico a la skill de Desatascos, no negociable):
  `gsap.matchMedia()` con la query `(prefers-reduced-motion: no-preference)`
  envolviendo TODA animación no esencial, interruptor global
  `animations_enabled` en `CompanySetting`, y **fallback estático** siempre
  visible si el JS falla o el usuario tiene reduced-motion.
- En móvil (`(max-width: 768px)`), la animación insignia se simplifica (ver
  apartado 2, "Nivel Lite") — nunca se carga el modelo 3D en móvil de gama
  media/baja.
- Botón de llamada/WhatsApp sticky, igual que en la skill de Desatascos: fade
  in tras pasar el hero, fijo el resto del scroll.

## 1. La animación insignia: "El recorrido de la moto"

### Concepto narrativo

En el hero aparece una moto **parada, con un problema** (testigo de avería
parpadeando, un leve hilo de humo). En cuanto el usuario empieza a hacer
scroll, la moto **arranca y recorre una carretera** dibujada en pantalla,
cruzando de largo 2-3 "señales de carretera" con los síntomas típicos de
avería (fusiona lo que en la skill de Desatascos eran dos escenas —hero y
agitación del problema— en una sola pieza de storytelling con movimiento
real). La moto termina el recorrido **entrando y aparcando en el taller**,
justo en el arranque de la sección "Cómo trabajamos": el propio movimiento
cuenta la historia completa ("tu moto tiene un problema → viene a nuestro
taller → la arreglamos") sin necesidad de leer nada.

Este recorrido va del final del hero (0vh-100vh) hasta, aproximadamente, el
50% de la siguiente sección (100vh-160vh de un total de sección de 120vh) —
de ahí "desde el hero hasta la mitad de la sección".

### Nivel Full (escritorio, dispositivos capaces): moto en 3D real

- Componente: **`<model-viewer>`** de Google (`@google/model-viewer`, MIT,
  ~280KB gzipped, soporta `.glb`/`.gltf`, controles de cámara y AR
  incorporados). Se añade con un único tag HTML, sin escribir WebGL a mano.
- Modelo 3D: descargar un modelo de moto gratuito de **Sketchfab**, filtrando
  por "Downloadable" y licencia **Standard** o **CC0** (uso comercial sin
  atribución). Si el único modelo válido para el estilo deseado es **CC-BY**,
  es usable comercialmente pero **hay que dar crédito visible** al autor (por
  ejemplo, en el footer o en una página de créditos) — revisar la licencia
  exacta de cada modelo concreto en su página de Sketchfab antes de
  descargarlo, porque puede cambiar entre modelos del mismo autor.
- Carga diferida: `<model-viewer>` con `loading="lazy"` y solo se instancia
  cuando un `IntersectionObserver` confirma que el hero está a punto de
  entrar en el viewport — nunca bloquea el LCP.
- `poster` obligatorio: una imagen estática (render WebP del propio modelo)
  para que no haya salto de layout ni hueco en blanco mientras el `.glb`
  termina de descargar.
- Recorrido ligado al scroll: en vez de animar posición 3D compleja, se anima
  la **cámara** alrededor de un modelo estático colocado sobre el "camino"
  ilustrado en 2D de fondo — visualmente da la sensación de que la moto se
  acerca y gira, con mucho menos coste de desarrollo que mover el objeto 3D:

  ```js
  const viewer = document.querySelector('#moto-3d');
  ScrollTrigger.create({
    trigger: '.seccion-recorrido',
    start: 'top top',
    end: 'bottom center',
    scrub: 1,
    onUpdate: (self) => {
      const p = self.progress; // 0 → 1
      const azimuth = gsap.utils.interpolate(0, 55, p);   // gira alrededor
      const polar   = gsap.utils.interpolate(75, 82, p);
      const radius  = gsap.utils.interpolate(105, 55, p) + '%'; // se acerca
      viewer.cameraOrbit = `${azimuth}deg ${polar}deg ${radius}`;
    }
  });
  ```

- Si se necesita que la moto además **se desplace** por la pantalla (no solo
  gire la cámara), la alternativa es Three.js puro: cargar el `.glb` con
  `GLTFLoader`, renderizar en un `<canvas>` posicionado en `position: fixed`
  detrás del contenido, y animar `mesh.position`/`mesh.rotation` con GSAP
  (`gsap.to(mesh.position, {x: .., y: .., scrollTrigger: {scrub:true}})`).
  Requiere más trabajo de integración que `<model-viewer>`, pero da control
  total del recorrido en 3D — usar solo si el "efecto wow" justifica el coste
  de desarrollo extra.
- **Guardarraíles de rendimiento** (obligatorios, no opcionales): activar el
  Nivel Full solo si `window.matchMedia('(min-width: 1024px)').matches` y NO
  `prefers-reduced-motion: reduce`. En cualquier otro caso, servir
  automáticamente el Nivel Lite.

### Nivel Lite (por defecto en móvil, y respaldo si el 3D no carga): moto en SVG con MotionPath

- Un `<svg>` con: (a) un `<path id="ruta">` que dibuja la carretera curva
  desde el hero hasta el taller, (b) una ilustración de moto en línea/silueta
  (un solo color, fácil de tematizar con `color_primary`/`color_accent` del
  admin), con las ruedas como `<g>` independientes.
- La carretera se "dibuja" a medida que se hace scroll con
  `strokeDasharray`/`strokeDashoffset` ligado al mismo progreso de scroll que
  mueve la moto (para que parezca que el camino aparece bajo las ruedas).
- La moto recorre la ruta con **MotionPathPlugin**, con inclinación en las
  curvas (`autoRotate`) imitando cómo una moto real se tumba al girar — un
  detalle de marca muy reconocible para el sector:

  ```js
  gsap.registerPlugin(MotionPathPlugin);

  let tl = gsap.timeline({
    scrollTrigger: {
      trigger: '.seccion-recorrido',
      start: 'top top',
      end: 'bottom center',
      scrub: 1,
    }
  });

  tl.to('.moto-svg', {
    motionPath: {
      path: '#ruta',
      align: '#ruta',
      autoRotate: true,
      alignOrigin: [0.5, 0.5],
    },
    ease: 'none',
  }, 0)
  .to('#ruta', { strokeDashoffset: 0 }, 0) // el trazo se revela en paralelo
  .fromTo('.señal-1', { autoAlpha: 0, y: 10 }, { autoAlpha: 1, y: 0 }, 0.15)
  .fromTo('.señal-1', { autoAlpha: 1 }, { autoAlpha: 0 }, 0.3)
  .fromTo('.señal-2', { autoAlpha: 0, y: 10 }, { autoAlpha: 1, y: 0 }, 0.45)
  .fromTo('.señal-2', { autoAlpha: 1 }, { autoAlpha: 0 }, 0.6);

  // Ruedas girando de forma continua, independiente del recorrido:
  gsap.to('.rueda', { rotate: 360, repeat: -1, ease: 'none', duration: 0.8, transformOrigin: '50% 50%' });
  ```

- Las "señales de carretera" (`.señal-1`, `.señal-2`, `.señal-3`) son textos
  cortos de ejemplo: **"¿No arranca?"**, **"¿Pierde potencia?"**, **"¿Ruido
  raro en el motor?"** — aparecen y desaparecen conforme la moto las cruza,
  sustituyendo a la clásica escena de "agitación del problema" estática.
- Este nivel funciona en cualquier dispositivo, no requiere WebGL, pesa muy
  poco (un SVG + unas líneas de GSAP) y es el que se usa siempre como
  respaldo si el nivel 3D no está disponible o `animations_enabled` está en
  su modo reducido.

### Punto de llegada (fin del recorrido)

En ambos niveles, la moto termina su recorrido "aparcada" sobre/junto a un
icono de taller (puerta de garaje entreabierta), coincidiendo exactamente con
el H2 "Cómo trabajamos" de la Escena 2 — el elemento visual y el contenido
textual llegan a la vez, reforzándose mutuamente.

---

## 2. Guion escena a escena completo (home)

### Escena 0 — Hero (0–100vh)

**Elemento:** Moto (SVG o 3D según nivel) parada, testigo de avería
parpadeando sutilmente; H1, subtítulo, CTA de llamada grande.

**Copy de ejemplo:**
> H1: **¿Tu moto no arranca o no rinde como antes?**
> Subtítulo: Mecánicos de confianza en El Vendrell y alrededores.
> Diagnóstico honesto, presupuesto claro.
> Botón principal: **Llamar ahora · 977 000 000**
> Botón secundario: Pedir presupuesto sin compromiso

**Animación:** Entrada en cascada del H1 (`SplitText` por líneas) y botones
al cargar. El testigo de avería parpadea en bucle lento (`opacity` 1→0.3→1).
Botón de llamada con "magnetic hover": en escritorio, el botón se desplaza
ligeramente hacia el cursor cuando este se acerca (`mousemove` + `gsap.to`
con `ease: "power3"`), un detalle típico de webs premium de 2026.

### Escena de transición (100–260vh) — Animación insignia

Ver apartado 1 completo. Aquí es donde vive el recorrido de la moto y las
"señales de carretera" con los síntomas de avería.

### Escena 2 — Cómo trabajamos (260–340vh)

**Elemento:** La moto llega y "aparca" en el taller; timeline de 4 pasos con
iconos que se dibujan con trazo SVG a medida que se hace scroll (igual que en
la skill de Desatascos, técnica `strokeDasharray`).

**Copy de ejemplo:**
> H2: Cómo trabajamos
> H3 1: Nos cuentas qué le pasa a tu moto
> H3 2: Diagnóstico y presupuesto sin compromiso
> H3 3: Reparación con plazos claros
> H3 4: Recogida, prueba en carretera y garantía

**Animación:** `ScrollTrigger` con `pin: true` mientras se recorre la
timeline horizontal, cada icono dibujado con `strokeDashoffset`.

### Escena 3 — Servicios (340–420vh)

**Elemento:** Grid de tarjetas de servicio, cada una con su imagen curada del
banco de imágenes gratuito (ver `05-banco-imagenes-gratuitas.md`).

**Animación:** `ScrollTrigger.batch()` con fade + `y: 30→0` y stagger entre
tarjetas del mismo lote.

**Mejora "al máximo":** al pasar el cursor sobre una tarjeta (desktop), la
imagen hace un `scale` suave (1 → 1.06) con `overflow: hidden` en el
contenedor — micro-interacción estándar en portfolios/webs de producto de
última generación, de coste de implementación mínimo.

### Escena 4 — Cobertura / zonas (420–500vh)

**Elemento:** Mapa estilizado de la comarca con pines por población y
contadores animados.

**Copy de ejemplo:**
> H2: El Vendrell, Cunit, Calafell y toda la comarca
> Contador 1: **+[X] años** reparando motos
> Contador 2: **+[X]** motos reparadas
> Contador 3: **[X]/5** valoración media de nuestros clientes

**Animación:** Pines con `stagger` tipo rebote (`ease: back.out`), contadores
con *count-up* disparado una vez (`once: true`).

**Nota legal:** cifras reales y editables desde `CompanySetting`, nunca
relleno — ver `09-legal-cumplimiento.md`.

### Escena 5 — Por qué elegirnos (500–560vh)

**Elemento:** 4 tarjetas flip (Mecánicos con experiencia · Presupuesto claro
· Piezas originales o equivalentes, tú eliges · Garantía por escrito).

**Animación:** `rotateY` con `transform-style: preserve-3d` al entrar en
viewport; en móvil, fade + scale simple.

### Escena 6 — Trabajos realizados (560–620vh) — nueva respecto a Desatascos

**Elemento:** Galería horizontal de antes/después (motos reparadas), con
scroll-snap y arrastre.

**Animación:** Scroll-snap horizontal nativo (`scroll-snap-type: x mandatory`)
+ `Draggable` de GSAP para arrastrar con el ratón en escritorio, con inercia
(`inertia: true`, plugin también gratis desde 2025).

### Escena 7 — Opiniones (620–680vh)

Igual que en la skill de Desatascos: carrusel con scroll-snap.

### Escena 8 — FAQ (680–740vh)

Acordeón con las FAQ destacadas, enlace "Ver todas" hacia
`/preguntas-frecuentes`.

### Escena 9 — CTA final (740vh–fin)

**Copy de ejemplo:**
> H2: ¿Tu moto se ha quedado tirada?
> "Cuéntanos qué le pasa y te decimos en el momento si podemos ayudarte hoy
> mismo."
> Botón: **Llamar ahora · 977 000 000**   Botón: **Escribir por WhatsApp**

**Animación:** Entrada simple, sin fricción visual — es el cierre.

---

## 3. Otras mejoras "de última generación" a incorporar (más allá de la moto)

- **Máscara de texto (clip-path reveal):** los H2 de cada sección se revelan
  con un `clip-path: inset(0 100% 0 0)` animado a `inset(0 0 0 0)`, en vez de
  un simple fade — sensación más "editorial"/premium.
- **Parallax de profundidad en el hero:** 2-3 capas (carretera, siluetas de
  El Vendrell al fondo, moto en primer plano) moviéndose a velocidades
  distintas (`yPercent` distinto por capa) al hacer scroll dentro del propio
  hero, antes de que arranque el recorrido insignia.
- **Cursor personalizado (desktop):** un pequeño círculo que sigue al cursor
  con `gsap.quickTo()` (más eficiente que un `mousemove` normal) y que
  cambia de tamaño/color al pasar sobre elementos clicables — detalle
  frecuente en webs de agencia/producto premium.
- **Indicador de progreso de scroll:** una barra fina fija en la parte
  superior (`transform: scaleX()` ligado a `ScrollTrigger.progress` global)
  que muestra al usuario cuánto le queda de página — mejora la sensación de
  control en páginas largas como este home.
- Todas estas mejoras son **aditivas y opcionales**: si el tiempo de
  desarrollo es limitado, priorizar primero la animación insignia (apartado 1)
  y el guion base (apartado 2); estas son la capa de pulido final.

## 4. Patrón resumido para páginas de servicio y de zona

Igual que en la skill de Desatascos: hero corto (sin la animación insignia
completa — como mucho una versión estática/mini del SVG de la moto), bloque
de "cuándo lo necesitas", bloque de proceso resumido, grid de zonas/servicios
relacionados, FAQ, CTA final idéntico al del home (componente Blade
reutilizado).

## 5. Resumen de técnicas usadas (referencia rápida)

| Efecto | API |
|---|---|
| Recorrido de un elemento por una ruta | `MotionPathPlugin` (`motionPath`, `autoRotate`) |
| Modelo 3D real en la web | `<model-viewer>` (Google) o Three.js + `GLTFLoader` |
| Cámara 3D controlada por scroll | `viewer.cameraOrbit` interpolado en `onUpdate` de `ScrollTrigger` |
| Carretera/icono "dibujándose" | `strokeDasharray` / `strokeDashoffset` |
| Botón magnético | `mousemove` + `gsap.to(target, {x, y, ease:"power3"})` |
| Texto revelado con máscara | `clip-path` animado |
| Galería horizontal arrastrable | `Draggable` + `inertia: true` |
| Contador numérico | tween de objeto plano + `onUpdate` |
| Cursor personalizado performante | `gsap.quickTo()` |
| Barra de progreso de scroll | `scaleX` ligado a `ScrollTrigger.progress` global |
