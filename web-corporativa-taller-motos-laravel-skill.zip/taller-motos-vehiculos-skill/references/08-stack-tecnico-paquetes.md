# 08 · Stack técnico: instalación paso a paso

Base idéntica a la skill de Desatascos (Filament, spatie/laravel-sitemap,
laravel-sluggable, ralphjsmit/laravel-seo, spatie/schema-org,
laravel-medialibrary, spatie/image-optimizer, laravel-honeypot) — se detallan
aquí los comandos completos más las librerías nuevas para la animación
insignia.

## 1. Panel de administración

```bash
composer require filament/filament:"^4.0"
php artisan filament:install --panels
php artisan make:filament-user
```

## 2. SEO técnico

```bash
composer require spatie/laravel-sitemap
composer require spatie/laravel-sluggable
composer require ralphjsmit/laravel-seo
composer require spatie/schema-org
```

## 3. Media e imágenes

```bash
composer require spatie/laravel-medialibrary
php artisan vendor:publish --provider="Spatie\MediaLibrary\MediaLibraryServiceProvider" --tag="medialibrary-migrations"
php artisan migrate
composer require spatie/image-optimizer
```

Definir conversiones WebP/AVIF por modelo, igual que en la skill de
Desatascos. Los `custom_properties` (`alt_text`, `source`, `image_credit`) no
requieren migración adicional, son parte del JSON nativo de medialibrary.

## 4. Formularios y anti-spam

```bash
composer require spatie/laravel-honeypot
php artisan vendor:publish --provider="Spatie\Honeypot\HoneypotServiceProvider"
```

## 5. Animaciones de scroll (frontend)

```bash
npm install gsap lenis
```

```js
// resources/js/app.js
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { MotionPathPlugin } from "gsap/MotionPathPlugin";
import { Draggable } from "gsap/Draggable";
import { SplitText } from "gsap/SplitText";
import Lenis from "lenis";

gsap.registerPlugin(ScrollTrigger, MotionPathPlugin, Draggable, SplitText);

const lenis = new Lenis();
lenis.on("scroll", ScrollTrigger.update);
gsap.ticker.add((time) => lenis.raf(time * 1000));
gsap.ticker.lagSmoothing(0);
```

Todos los plugins usados (`MotionPathPlugin`, `Draggable`, `SplitText`) son
100% gratuitos desde 2025 (antes exclusivos de "Club GreenSock"), incluido
uso comercial — no requieren licencia ni clave de acceso.

## 6. Nivel Full de la animación insignia (3D) — nuevo respecto a Desatascos

```bash
npm install @google/model-viewer
```

```html
<!-- Componente web, se registra solo con importarlo -->
<script type="module" src="/node_modules/@google/model-viewer/dist/model-viewer.min.js"></script>

<model-viewer
  id="moto-3d"
  src="/storage/modelos-3d/moto-taller-rpm.glb"
  poster="/storage/modelos-3d/moto-poster.webp"
  loading="lazy"
  camera-controls="false"
  disable-zoom
  style="width:100%;height:100%;">
</model-viewer>
```

- El `.glb` sube desde el panel de administración (campo
  `hero_moto_model_path` en `CompanySetting`, ver
  `06-panel-administracion.md`) — nunca hardcodeado en el HTML/Blade; el
  ejemplo de arriba es solo ilustrativo de la ruta esperada.
- Si el proyecto necesita mover el objeto 3D por la pantalla (no solo la
  cámara), añadir Three.js:

```bash
npm install three
```

  y usar `GLTFLoader` para cargar el mismo `.glb` en un `<canvas>` propio,
  animando `mesh.position`/`mesh.rotation` con GSAP (ver ejemplo técnico en
  `04-guion-animaciones-scroll.md`, apartado 1).

## 7. Compilación de assets

Igual que en la skill de Desatascos: Vite + Tailwind + Alpine.js ya vienen
con Laravel, verificar el enlace en `vite.config.js` y usar `@vite([...])` en
el layout.

## 8. Base de datos y entorno

```bash
php artisan migrate
php artisan db:seed --class=TallerRpmSeeder
```

(Contenido exacto del seeder en `assets/seed-data-taller-rpm.md`.)

## 9. Producción / rendimiento

```bash
php artisan optimize
npm run build
```

Comprobar especialmente, si se activa el Nivel Full 3D:
- El `.glb` pesa lo mínimo posible (comprimir con `gltf-transform` o similar
  antes de subirlo si supera 2-3 MB).
- `loading="lazy"` en `<model-viewer>` y activación solo en escritorio (ver
  guardarraíles de rendimiento en `04-guion-animaciones-scroll.md`).
- Forzar HTTPS y un único dominio canónico (`www` o sin `www`).
