---
name: web-corporativa-taller-motos-laravel
description: >
  Genera desde cero (o completa) una web corporativa en Laravel para un taller
  de reparación de motos (y, en menor medida, otros vehículos como scooters o
  quads), con panel de administración (Filament) totalmente editable y
  "white-label" (marca, textos, colores, servicios, zonas y datos legales
  configurables, con datos de ejemplo de "Taller RPM" precargados por
  defecto), arquitectura completa de páginas para SEO local (home, servicios,
  zonas de servicio, blog, legal, contacto/presupuesto), jerarquía de
  encabezados H1-H6 estrictamente correcta, capa técnica de SEO orientada a
  posicionar en Google para "reparación de motos"/"taller de motos" y
  variantes locales en la zona de El Vendrell y alrededores (Baix Penedès),
  banco de imágenes gratuitas curado por servicio, y animaciones de scroll de
  última generación (GSAP + ScrollTrigger + MotionPath, más un recorrido de
  elemento en 3D/SVG desde el hero hasta la mitad de la siguiente sección para
  identificar el negocio a simple vista) con guion de venta orientado a que el
  visitante llame por teléfono. Usa esta skill siempre que el usuario pida
  crear, planificar, ampliar o auditar una web de taller mecánico de motos,
  motocicletas, scooters, ciclomotores o vehículos en general en Laravel, o
  cuando pida SEO local para ese tipo de negocio, un panel admin editable, un
  banco de imágenes gratuito curado, o animaciones de scroll/3D orientadas a
  conversión telefónica.
---

# Web corporativa de Taller de Motos en Laravel — Skill completa

## 1. Relación con la skill de "Desatascos"

Esta skill es una **adaptación de vertical** de la skill
`web-corporativa-desatascos-laravel`: mismo esqueleto técnico (Laravel +
Filament + GSAP + SEO local), pero para un **taller de reparación de motos y
vehículos**, con sede en **El Vendrell (Baix Penedès, Tarragona)** en vez de
Cunit, y con dos añadidos nuevos que no existían en la skill anterior:

1. Un banco de imágenes gratuitas curado por servicio (`references/05-banco-imagenes-gratuitas.md`).
2. Un guion de animaciones de scroll llevado "al máximo", con una animación
   insignia: el **recorrido de un elemento (moto) desde el hero hasta la mitad
   de la siguiente sección**, en SVG o en 3D real, para que se identifique el
   negocio a simple vista (`references/04-guion-animaciones-scroll.md`).

Si ya tienes montada la skill de Desatascos en el mismo proyecto/agente,
puedes reutilizar literalmente los archivos `06-modelo-datos-laravel.md`,
`08-stack-tecnico-paquetes.md` (salvo la sección 3D nueva) y el patrón de
`09-checklist...` — aquí se repiten completos para que esta skill funcione de
forma 100% autónoma si se usa sin la otra.

## 2. Qué construye esta skill

1. **Panel de administración** (Filament) desde el que se edita el 100% del
   contenido, marca, colores/diseño, servicios, zonas, blog, opiniones, FAQ,
   textos legales, banco de imágenes asociado a cada servicio y los leads
   recibidos. Sale de fábrica con los datos de ejemplo de **"Taller RPM"**,
   pero sirve para cualquier taller de motos/vehículos con solo cambiar esos
   datos.
2. **Arquitectura de páginas orientada a SEO local**: una página por cada
   intención de búsqueda relevante ("reparación de motos [ciudad]", "taller de
   motos", "asistencia en carretera moto", "cambio de aceite moto"...).
3. **Jerarquía de encabezados perfecta** (1 solo `<h1>` por página, H2/H3/H4
   en cascada sin saltos).
4. **Banco de imágenes gratuitas curado**: qué bancos usar, con qué licencia,
   y qué buscar para cada servicio (taller, motor, neumáticos, chapa y
   pintura...), sin depender de fotos de stock genéricas de oficinas.
5. **Animaciones de scroll de última generación**, incluida la animación
   insignia de "recorrido del elemento" (moto) desde el hero hasta media
   sección, con dos niveles de implementación (SVG ligero y 3D real).
6. **Cumplimiento legal**: LSSI-CE, RGPD/LOPDGDD y cookies (idéntico a la
   skill de Desatascos) **más** las obligaciones propias de un taller
   (Registro Industrial, licencia de actividad, gestión de residuos
   peligrosos como aceites usados) como contenido de confianza en
   "Sobre nosotros".
7. **Zona de servicio real de referencia**: **El Vendrell y alrededores**
   (Cunit, Calafell, Segur de Calafell, Coma-ruga, Cubelles, Bellvei,
   Banyeres del Penedès, L'Arboç, Sant Jaume dels Domenys, Santa Oliva,
   Albinyana, Vilanova i la Geltrú, Sitges) — de nuevo, editable: cualquier
   taller puede sustituir estas poblaciones por las suyas.

## 3. Principio rector (idéntico al de la skill de Desatascos)

Cero contenido "hardcodeado": nombre del taller, teléfono, colores, servicios,
poblaciones e imágenes por defecto viven en base de datos/medialibrary y se
editan desde `/admin`. Las vistas Blade son plantillas, nunca contenido fijo.

## 4. Stack técnico (igual que Desatascos + 2 librerías nuevas)

| Capa | Elección | Novedad respecto a la skill de Desatascos |
|---|---|---|
| Backend | Laravel 12/13 (PHP 8.3+) | — |
| Admin | Filament (última v4/v5) | — |
| Frontend | Blade + Tailwind + Alpine.js | — |
| Animaciones scroll | GSAP + ScrollTrigger + Lenis | + **MotionPathPlugin** (gratis desde 2025) para el recorrido del elemento |
| 3D (opcional, nivel avanzado) | **`@google/model-viewer`** (web component, MIT) o Three.js si se necesita control fino del scroll-scrub | Nuevo en esta skill |
| SEO técnico | spatie/laravel-sitemap, sluggable, ralphjsmit/laravel-seo, schema-org | — |
| Media | spatie/laravel-medialibrary + WebP/AVIF | + flujo de curación de imágenes desde bancos gratuitos (ver 05) |
| Formularios | honeypot + reCAPTCHA v3 | — |

## 5. Orden de ejecución recomendado

1. Instala el stack base y monta Filament en `/admin` → `08-stack-tecnico-paquetes.md`
2. Migra el modelo de datos → `07-modelo-datos-laravel.md`
3. Construye los recursos del panel admin (incluido el gestor de imágenes por
   servicio) → `06-panel-administracion.md`
4. Ejecuta el seeder de ejemplo **Taller RPM** → `assets/seed-data-taller-rpm.md`
5. Construye el sitemap de páginas públicas → `01-sitemap-arquitectura.md`
6. Aplica la jerarquía de encabezados obligatoria → `03-estructura-encabezados-hn.md`
7. Cura las imágenes de cada servicio/zona con el banco de imágenes gratuito
   → `05-banco-imagenes-gratuitas.md`
8. Implementa la capa SEO (keywords, metadatos, schema.org, sitemap.xml,
   robots.txt) → `02-seo-estrategia-keywords.md`
9. Maqueta el home con el guion de animaciones de scroll "al máximo",
   incluida la animación insignia del recorrido del elemento
   → `04-guion-animaciones-scroll.md`
10. Redacta e inserta las 3 páginas legales + el bloque de confianza
    sectorial del taller → `09-legal-cumplimiento.md`
11. Pasa el checklist final → `10-checklist-seo-tecnico-lanzamiento.md`

## 6. Reglas de oro (idénticas + 2 nuevas propias de esta skill)

- [ ] 1 solo `<h1>` por página, jerarquía H1→H2→H3→H4 sin saltos.
- [ ] Cero marca/teléfono/color/imagen "quemada" en Blade.
- [ ] Botón de llamada y WhatsApp sticky tras el hero en móvil.
- [ ] Animaciones con `prefers-reduced-motion` respetado y `animations_enabled`
      desactivable desde el admin.
- [ ] Cero reclamos publicitarios absolutos no verificables.
- [ ] `robots.txt`, `sitemap.xml` y las 3 páginas legales desde el primer commit.
- [ ] **Ninguna imagen se sube sin verificar su licencia** (ver
      `05-banco-imagenes-gratuitas.md`) — nunca una foto con copyright de
      terceros o sacada de Google Images sin comprobar el uso permitido.
- [ ] **La animación insignia (recorrido del elemento) tiene siempre una
      versión ligera de respaldo** (imagen estática o SVG simple) para
      dispositivos de gama baja o con `prefers-reduced-motion`, nunca deja la
      página en blanco si el modelo 3D no carga.

## 7. Mapa de archivos de esta skill

| Archivo | Contenido |
|---|---|
| `references/01-sitemap-arquitectura.md` | Páginas, URLs e intención de búsqueda |
| `references/02-seo-estrategia-keywords.md` | Keywords, metadatos, schema.org, SEO local |
| `references/03-estructura-encabezados-hn.md` | Esquema H1-H6 por tipo de página |
| `references/04-guion-animaciones-scroll.md` | Guion "al máximo" + animación insignia del recorrido del elemento (SVG y 3D) |
| `references/05-banco-imagenes-gratuitas.md` | **Nuevo**: bancos de imágenes gratuitas, licencias y búsqueda por servicio |
| `references/06-panel-administracion.md` | Especificación de recursos Filament, incluido el gestor de imágenes |
| `references/07-modelo-datos-laravel.md` | Tablas y relaciones Eloquent |
| `references/08-stack-tecnico-paquetes.md` | Comandos de instalación (incluye 3D) |
| `references/09-legal-cumplimiento.md` | Legal web + obligaciones propias de un taller |
| `references/10-checklist-seo-tecnico-lanzamiento.md` | Checklist final |
| `assets/seed-data-taller-rpm.md` | Datos de ejemplo: empresa, servicios, zonas, testimonios, FAQs, blog |
| `references/11-marketplace-compraventa-piezas-motores.md` | **Nuevo (v3)**: compraventa de vehículos y de piezas/motores |
| `references/12-sistema-subastas-en-vivo.md` | **Nuevo (v3)**: subastas en vivo en tiempo real, sonido, animación, calendario, análisis de competencia |
| `references/13-roles-permisos-areas-privadas.md` | **Nuevo (v3)**: roles, área privada de cada rol, restricción de rutas |
| `references/14-planes-suscripcion-membresias.md` | **Nuevo (v3)**: planes mensuales de acceso a subastas |
| `references/15-servicio-diagnosis-centralitas.md` | **Nuevo (v3)**: servicio de diagnosis/reprogramación de centralitas, con límites legales |
| `references/16-expansion-internacional-paises-legal-fiscal.md` | **Nuevo (v3)**: qué países activar, IVA (REBU), blanqueo de capitales, subastas y derecho de desistimiento |
| `references/17-idiomas-i18n-traducciones.md` | **Nuevo (v3)**: sistema de idiomas y traducciones |
| `references/18-gestion-documental-firma-electronica-poderes.md` | **Nuevo (v3)**: documentos, firma electrónica y generación de poderes |
| `references/19-modelo-datos-ampliado.md` | **Nuevo (v3)**: tablas Eloquent de todo lo anterior |
| `assets/sonidos-gratuitos-subasta.md` | **Nuevo (v3)**: sonidos gratuitos de uso comercial para la subasta, por evento |

## 8. Ampliación v3 — de "web de taller" a plataforma completa

Esto ya no es una web de servicios locales: es un **marketplace + casa de
subastas en vivo + taller + servicio técnico**, operando (potencialmente) en
varios países europeos, con pagos, documentos con validez legal y roles tipo
empresa mediana. Esa es, en la práctica, una plataforma del tamaño de un
Copart/OPENLANE + AutoScout24 + CRM de concesionario — meses de desarrollo de
un equipo, no una tarde de un agente. Aun así, aquí tienes la especificación
más completa posible para construirla de forma progresiva y sin dejarte nada
importante en el tintero.

**Aviso honesto, no una fórmula de cortesía**: los apartados de blanqueo de
capitales, fiscalidad transfronteriza, licencias de subastador y derechos de
los consumidores en subastas (`16-expansion-internacional-paises-legal-fiscal.md`)
tocan materias donde equivocarse tiene consecuencias reales (sanciones,
contratos nulos, responsabilidad penal en el caso de blanqueo). Esta skill te
da el mapa técnico y normativo para construir la plataforma **y para saber
exactamente qué preguntarle a un abogado/asesor fiscal antes de activar cada
país o cada medio de pago** — no sustituye ese asesoramiento en ningún caso.

### Hoja de ruta recomendada (fases, no todo a la vez)

1. **Fase 0 — Base ya construida**: web de taller (secciones 1-7 de este
   documento) ya operativa y posicionando en Google.
2. **Fase 1 — Marketplace + roles + i18n base**: compraventa de vehículos y
   piezas, roles y áreas privadas, documentos básicos, español + catalán +
   inglés. Un solo país activo: **España**.
3. **Fase 2 — Suscripciones + subastas en vivo (beta cerrada)**: sistema de
   subastas con Reverb, sonido y animación, primero solo con compradores
   **profesionales verificados** (concesionarios/gestorías) para evitar de
   entrada la zona gris del derecho de desistimiento en subastas 100% online
   con consumidores particulares (ver `16-...md`, apartado 2).
4. **Fase 3 — Apertura a particulares + países adicionales**: una vez
   resuelto con asesoría legal el tratamiento del derecho de desistimiento,
   abrir a compradores particulares y a los países de la lista "verde" de
   `16-...md`.
5. **Fase 4 — Servicio de centralitas + firma electrónica avanzada/poderes**:
   los módulos más sensibles (por normativa y por riesgo de mal uso), se
   activan los últimos y con más controles internos.

Todo el resto de este documento (secciones 1-7) sigue vigente sin cambios: el
mismo taller de motos es, en este planteamiento, uno de los servicios que
convive dentro de la plataforma más grande.
