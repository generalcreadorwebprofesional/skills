# Sonidos gratuitos para la subasta (uso comercial verificado, 2026)

## 1. Fuentes recomendadas y su licencia exacta

| Fuente | Licencia | Atribución | Formatos | Mejor para |
|---|---|---|---|---|
| **Kenney** (kenney.nl/assets) | CC0 (dominio público) | No | WAV | Clics de interfaz, impactos secos, "pings" de puja — catálogo pensado para videojuegos, ideal para UI de subasta |
| **Mixkit** (mixkit.co) | Mixkit Free License | No | WAV, MP3 | Fanfarrias cortas, ambientes, golpes de martillo/mazo — permite explícitamente broadcast/TV, cobertura muy amplia |
| **Pixabay** (pixabay.com, sección de audio) | Pixabay Content License | No | MP3 | Música de fondo/cierre de sesión, campanadas |
| **Freesound** (freesound.org) | Varía por archivo: CC0, CC-BY o CC-BY-NC | Solo si es CC-BY; **descartar los CC-BY-NC** (no permiten uso comercial) | WAV, MP3, FLAC | Sonidos muy específicos (tictac concreto, golpe de mazo de madera real) — **filtrar siempre por licencia CC0 en la búsqueda** para no tener que revisar cada archivo a mano |
| **Sonniss GDC Bundle** (archivo anual gratuito) | Libre de regalías, sin atribución | No | WAV | Si se necesita un paquete grande y consistente de una sola vez (más de 200 GB de efectos profesionales) |

**A evitar para este proyecto**: BBC Sound Effects (licencia RemArc, **solo
uso no comercial** — no vale para una plataforma que cobra suscripciones),
cualquier archivo de Freesound marcado como CC-BY-NC, y cualquier sonido
sacado de un vídeo de YouTube de terceros sin verificar su licencia real.

## 2. Qué buscar para cada evento (términos de búsqueda sugeridos)

| Evento (ver `12-sistema-subastas-en-vivo.md`, apartado 4) | Búsqueda sugerida (EN suele dar más resultados) |
|---|---|
| Inicio de sesión | "crowd ambience short", "soft fanfare intro", "notification chime rise" |
| Nueva puja | "ui pop", "coin ping", "short click positive" |
| Reserva alcanzada | "bell soft ding", "success chime short" |
| Extensión de tiempo | "alert short beep", "notification urgent soft" |
| Últimos 10 segundos | "clock tick loop", "countdown tick" |
| Lote vendido | "auction gavel hit", "wood hammer knock", "gavel bang" |
| Lote sin venta | "soft negative tone", "neutral notification low" |
| Cierre de sesión | "outro jingle short", "success fanfare end" |

## 3. Flujo de curación y control de licencias

1. Descargar 2-3 candidatas por evento desde las fuentes CC0/sin atribución
   de la tabla (Kenney, Mixkit, Pixabay) — con estas tres, en la práctica no
   debería hacer falta recurrir a Freesound salvo un sonido muy concreto.
2. Si se usa Freesound, **filtrar la búsqueda por licencia CC0** desde la
   propia interfaz del sitio antes de escuchar resultados — evita
   descargar por error un archivo CC-BY-NC.
3. Convertir todos los archivos a un formato ligero y consistente (MP3 o
   OGG comprimido, no WAV sin comprimir) antes de subirlos, para que el
   peso total de los sonidos de una sesión sea mínimo (todos los efectos de
   evento suman idealmente menos de 500 KB en total).
4. Precargar (`preload`) todos los sonidos de una sesión al entrar en la
   página del lote en directo, para que no haya retraso perceptible entre el
   evento (p. ej. "vendido") y el sonido — con archivos tan pequeños esto no
   afecta al tiempo de carga inicial de la página.
5. Guardar en un pequeño registro interno (no público) qué archivo se usó de
   qué fuente y bajo qué licencia, por si en el futuro hay que sustituir
   alguno o demostrar el origen — un simple archivo `CREDITS.md` en el
   repositorio es suficiente para las licencias sin atribución obligatoria.

## 4. Implementación técnica mínima

```js
// Un solo objeto de sonidos, cargado una vez por sesión de subasta
const sonidosSubasta = {
  nuevaPuja: new Audio('/sounds/nueva-puja.mp3'),
  reservaAlcanzada: new Audio('/sounds/reserva-alcanzada.mp3'),
  extensionTiempo: new Audio('/sounds/extension-tiempo.mp3'),
  vendido: new Audio('/sounds/vendido.mp3'),
  sinVenta: new Audio('/sounds/sin-venta.mp3'),
};

let sonidoActivado = false; // false por defecto — el usuario debe activarlo
let ultimoSonidoTimestamp = 0;

function reproducir(nombre) {
  if (!sonidoActivado) return;
  const ahora = Date.now();
  if (ahora - ultimoSonidoTimestamp < 400) return; // anti-spam de sonido
  ultimoSonidoTimestamp = ahora;
  sonidosSubasta[nombre].currentTime = 0;
  sonidosSubasta[nombre].play().catch(() => {}); // nunca romper la UI si el navegador bloquea el audio
}
```

El toggle de "Activar sonido" es responsabilidad del usuario (obligatorio
por las políticas de autoplay de los navegadores, ver
`12-sistema-subastas-en-vivo.md`, apartado 4) — nunca intentar forzar sonido
sin esa interacción previa.
