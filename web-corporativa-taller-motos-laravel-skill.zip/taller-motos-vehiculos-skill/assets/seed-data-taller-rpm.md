# Datos de ejemplo para el seeder — "Taller RPM"

Todos los valores son **de ejemplo/ficticios** (teléfono, CIF, cifras, número
de registro industrial) y deben sustituirse por datos reales antes de
publicar la web con un taller real.

## 1. `CompanySetting` (fila única)

```
site_name: Taller RPM
legal_name: Taller RPM, S.L.
tagline: Tu moto, en las mejores manos
phone_main: 977 100 100
phone_emergency: 600 100 100
whatsapp_number: 34600100100
email: info@tallerrpm.example
address: Carrer del Nord, 5, 43700 El Vendrell (Tarragona)
postal_code: 43700
lat: 41.2201
lng: 1.5347
opening_hours:
  - {day: Lunes,     opens: "09:00", closes: "19:00", is_24h: false}
  - {day: Martes,    opens: "09:00", closes: "19:00", is_24h: false}
  - {day: Miércoles, opens: "09:00", closes: "19:00", is_24h: false}
  - {day: Jueves,    opens: "09:00", closes: "19:00", is_24h: false}
  - {day: Viernes,   opens: "09:00", closes: "19:00", is_24h: false}
  - {day: Sábado,    opens: "09:30", closes: "13:30", is_24h: false}
  - {day: Domingo (asistencia en carretera), opens: "00:00", closes: "23:59", is_24h: true}
cif_nif: B11111111
registro_mercantil: Registro Mercantil de Tarragona, Tomo 0, Folio 0, Hoja T-11111
industrial_registry_number: RI-CAT-000000
color_primary: "#1A1A1A"
color_secondary: "#D62828"
color_accent: "#F4A300"
font_heading: Rajdhani
font_body: Inter
animations_enabled: true
animations_3d_enabled: false
years_experience: 15
jobs_completed: 6200
avg_response_minutes: 40
roadside_assistance_radius_km: 20
brands_worked_with: Honda, Yamaha, Kawasaki, Suzuki, KTM, Vespa
main_service_area_id: → El Vendrell
```

> Nota de diseño: se propone una paleta oscura + rojo/ámbar (temática
> "taller"/velocidad) distinta a la azul de Desatascos EM, precisamente para
> demostrar que el theming vía `color_primary/secondary/accent` (ver
> `06-panel-administracion.md`) cambia de verdad el carácter visual de la web
> sin tocar código.

## 2. Servicios (`services`) — 10 registros

| name | vehicle_type | short_description | is_emergency | is_featured |
|---|---|---|---|---|
| Cambio de aceite y filtros | moto | Mantenimiento básico esencial para alargar la vida del motor. | No | Sí |
| Reparación de motor | moto | Diagnóstico y reparación de averías mecánicas del motor. | No | Sí |
| Diagnosis electrónica | moto | Localizamos fallos eléctricos y electrónicos con equipo especializado. | No | No |
| Frenos (pastillas, discos, líquido) | moto | Revisión y sustitución de los elementos de frenada. | No | Sí |
| Neumáticos y equilibrado | moto | Cambio de neumáticos y equilibrado de ruedas. | No | Sí |
| Cadena y kit de arrastre | moto | Ajuste, engrase o sustitución del kit de transmisión. | No | No |
| Chapa y pintura | moto | Reparación de carenados y pintura a juego con el color original. | No | Sí |
| Preparación pre-ITV | moto | Revisión completa para pasar la inspección técnica a la primera. | No | No |
| Asistencia en carretera | moto | Recogida y traslado de tu moto averiada hasta el taller. | Sí | Sí |
| Reparación de scooters y quads | otros | Mantenimiento y reparación también para scooters y quads. | No | No |

## 3. Zonas de servicio (`service_areas`) — 14 registros

| name | comarca | is_headquarters | is_featured |
|---|---|---|---|
| El Vendrell | Baix Penedès | Sí | Sí |
| Cunit | Baix Penedès | No | Sí |
| Calafell | Baix Penedès | No | Sí |
| Segur de Calafell | Baix Penedès | No | Sí |
| Coma-ruga | Baix Penedès | No | No |
| Cubelles | Garraf | No | Sí |
| Bellvei | Baix Penedès | No | No |
| Banyeres del Penedès | Baix Penedès | No | No |
| L'Arboç | Baix Penedès | No | No |
| Sant Jaume dels Domenys | Baix Penedès | No | No |
| Santa Oliva | Baix Penedès | No | No |
| Albinyana | Baix Penedès | No | No |
| Vilanova i la Geltrú | Garraf | No | Sí |
| Sitges | Garraf | No | No |

> Cada zona lleva su propia `description` redactada a mano (distancia
> aproximada a El Vendrell, comarca, alguna referencia local), igual que en
> la skill de Desatascos, para evitar contenido duplicado entre fichas.

## 4. Testimonios (`testimonials`) — 6 registros de ejemplo

1. **David M. (El Vendrell)** — ★5 — "Le diagnosticaron el problema el mismo
   día y me dieron un presupuesto cerrado antes de tocar nada."
2. **Laia F. (Cunit)** — ★5 — "Vinieron a recogerme la moto averiada en
   carretera en menos de 40 minutos."
3. **Marc T. (Calafell)** — ★4 — "Buen trato y precio justo en el cambio de
   neumáticos."
4. **Sergi P. (Cubelles)** — ★5 — "Dejaron la carena como nueva después de
   una caída, no se nota el arreglo."
5. **Judit R. (Vilanova i la Geltrú)** — ★5 — "Pasé la ITV a la primera
   gracias a la revisión previa que me hicieron."
6. **Àlex G. (Segur de Calafell)** — ★4 — "Muy majos explicando qué le
   pasaba a la moto, sin tecnicismos innecesarios."

## 5. FAQ (`faqs`) — 8 registros de ejemplo

| category | question |
|---|---|
| Precios | ¿Cuánto cuesta una revisión básica? |
| Precios | ¿El presupuesto es gratuito? |
| Averías y asistencia | ¿Recogéis la moto si se avería en carretera? |
| Averías y asistencia | ¿Cuánto tardáis en llegar? |
| Servicio técnico | ¿Usáis piezas originales o equivalentes? |
| Servicio técnico | ¿Dais garantía de las reparaciones? |
| Servicio técnico | ¿Trabajáis también con scooters y quads? |
| Zonas | ¿Venís a buscar la moto aunque no viva en El Vendrell? |

## 6. Ideas de blog (`posts`) — 3 de partida (ampliar con las de `02-seo-estrategia-keywords.md`)

1. "¿Cada cuánto hay que cambiar el aceite de la moto?" (categoría:
   Mantenimiento)
2. "Cómo preparar tu moto para pasar la ITV a la primera" (categoría:
   Consejos)
3. "Qué hacer si tu moto se avería en carretera" (categoría: Averías)
